"""Enhancement item (7) of ENHANCEMENT_ROADMAP.md: next-stage / next-asset
attack prediction.

For every test effective campaign, cut its behaviour sequence at each
position i; rank successor candidates in the correlation graph reachable
from the observed prefix (edges to events after the prefix, scored by edge
association); predict top-k next stages / assets.  Compared against
(a) an empirical stage-transition prior estimated from calibration
campaigns and (b) the MDATA correlation-graph ranking.

Metrics: stage Hit@1/Hit@3, stage MRR, asset Hit@3.

Outputs: results/prediction_S2.json, manuscript/numbers_prediction.tex
"""
from __future__ import annotations

import json
import os
from collections import Counter, defaultdict

import numpy as np

import config as C
import datagen
import evaluate
import pipeline

TOL = 300          # clock-skew tolerance for "after the prefix"
TOPK = 3


def build_edge_index(edges):
    adj = defaultdict(list)
    for i, j, s in edges:
        adj[i].append((j, s))
        adj[j].append((i, s))
    return adj


def rank_successors(prefix_events, prefix_bids, last_mid, adj, events):
    """Successor behaviours ranked by best edge score from the prefix."""
    cand = {}
    for p in prefix_events:
        for (o, s) in adj.get(p, ()):
            eo = events[o]
            if eo.bid in prefix_bids or eo.mid < last_mid - TOL:
                continue
            if s > cand.get(eo.bid, (0.0, None))[0]:
                cand[eo.bid] = (s, o)
    ranked = sorted(cand.items(), key=lambda kv: -kv[1][0])
    return [(bid, s, o) for bid, (s, o) in ranked]


def transition_prior(train_camps):
    counts = defaultdict(Counter)
    for c in train_camps:
        seq = c.stage_seq
        for a, b in zip(seq, seq[1:]):
            counts[a][b] += 1
    return {k: [s for s, _ in v.most_common()] for k, v in counts.items()}


def main(scale="S2"):
    per_seed = []
    for seed in C.MASTER_SEEDS:
        ds = datagen.generate(seed, scale)
        res = pipeline.run_mdata(ds)
        ctx = evaluate.EvalContext(ds)
        adj = build_edge_index(res["edges"])
        beh_of = {b.bid: b for b in ds.behaviors}
        evs_of_bid = defaultdict(list)
        for k, e in enumerate(res["events"]):
            evs_of_bid[e.bid].append(k)
        prior = transition_prior([c for c in ds.campaigns.values()
                                  if c.cid in ctx.train_c])
        n_cuts = 0
        agg = dict(stage_hit1=[], stage_hit3=[], stage_mrr=[], asset_hit3=[],
                   prior_hit1=[], prior_hit3=[])
        for cid, camp in ds.campaigns.items():
            if cid not in ctx.test_c or not camp.is_effective:
                continue
            seq = camp.behaviors
            if len(seq) < 2:
                continue
            for i in range(1, len(seq)):
                prefix = seq[:i]
                true_bid, true_stage = seq[i]
                tb = beh_of.get(true_bid)
                true_asset = tb.asset if tb else None
                prefix_bids = {b for b, _ in prefix}
                pevs = [k for b in prefix_bids for k in evs_of_bid.get(b, ())]
                if not pevs:
                    continue
                last_mid = max(res["events"][k].mid for k in pevs)
                ranked = rank_successors(pevs, prefix_bids, last_mid,
                                         adj, res["events"])
                if not ranked:
                    continue
                # stage ranking from successor ranking
                stages, seen = [], set()
                for bid, s, _ in ranked:
                    st = beh_of[bid].stage
                    if st not in seen:
                        stages.append(st)
                        seen.add(st)
                rr = [stages.index(true_stage) + 1
                      if true_stage in stages else 0]
                # asset ranking
                assets, seen_a = [], set()
                for bid, s, _ in ranked:
                    a = beh_of[bid].asset
                    if a and a not in seen_a:
                        assets.append(a)
                        seen_a.add(a)
                # transition-prior baseline from current stage
                cur_stage = beh_of[prefix[-1][0]].stage
                prior_stages = prior.get(cur_stage, [])
                n_cuts += 1
                agg["stage_hit1"].append(true_stage in stages[:1])
                agg["stage_hit3"].append(true_stage in stages[:TOPK])
                agg["stage_mrr"].append(1.0 / rr[0] if rr[0] else 0.0)
                agg["asset_hit3"].append(true_asset in assets[:TOPK])
                agg["prior_hit1"].append(true_stage in prior_stages[:1])
                agg["prior_hit3"].append(true_stage in prior_stages[:TOPK])
        row = dict(seed=seed, n_cuts=n_cuts,
                   **{k: float(np.mean(v)) for k, v in agg.items()})
        per_seed.append(row)
        print(f"seed {seed}: cuts {n_cuts} stage Hit@1 {row['stage_hit1']:.3f} "
              f"Hit@3 {row['stage_hit3']:.3f} MRR {row['stage_mrr']:.3f} "
              f"asset Hit@3 {row['asset_hit3']:.3f} | prior Hit@3 "
              f"{row['prior_hit3']:.3f}", flush=True)

    keys = [k for k in per_seed[0] if k != "seed"]
    out = dict(scale=scale, agg={k: dict(mean=float(np.mean([r[k] for r in per_seed])),
                                          std=float(np.std([r[k] for r in per_seed])))
                                 for k in keys}, per_seed=per_seed)
    p = os.path.join(C.RESULTS, f"prediction_{scale}.json")
    with open(p, "w") as f:
        json.dump(out, f, indent=1)
    print("saved", p, flush=True)
    a = out["agg"]
    lines = [f"\\newcommand\\nPredHitOne{{{100*a['stage_hit1']['mean']:.1f}}}",
             f"\\newcommand\\nPredHitThree{{{100*a['stage_hit3']['mean']:.1f}}}",
             f"\\newcommand\\nPredMRR{{{a['stage_mrr']['mean']:.3f}}}",
             f"\\newcommand\\nPredAssetHitThree{{{100*a['asset_hit3']['mean']:.1f}}}",
             f"\\newcommand\\nPredPriorHitThree{{{100*a['prior_hit3']['mean']:.1f}}}"]
    p2 = os.path.join(C.BASE, "manuscript", "numbers_prediction.tex")
    with open(p2, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("saved", p2, flush=True)


if __name__ == "__main__":
    main("S2")
