"""Engineering performance (RQ3 of the chapter's validation design):
end-to-end throughput, per-batch P50/P95 latency in a streaming simulation,
peak memory and candidate-expansion ratio across dataset scales S1-S3.

Streaming simulation: atomic events are consumed in 6-hour windows; each
window is processed (candidates + scoring + incremental union-find + beam
search restricted to the window with a 48 h look-back), mirroring the
"streaming triage -> graph correlation -> task output" deployment shape.
"""
from __future__ import annotations

import argparse
import json
import os
import time
from collections import defaultdict

import numpy as np

import config as C
import datagen
import pipeline as P


def streaming_run(ds, theta=None, window_s=6 * 3600, lookback=48 * 3600):
    theta = C.THETA if theta is None else theta
    events = P.normalize(ds)
    n = len(events)
    batches = defaultdict(list)
    for i, e in enumerate(events):
        batches[e.t0 // window_s].append(i)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    scorer = P.Scorer(ds)
    latencies, n_pairs = [], 0
    t_total0 = time.perf_counter()
    for bkey in sorted(batches):
        idx = batches[bkey]
        t_now = (bkey + 1) * window_s
        # events in this window plus look-back for time-window edges
        pool = idx + [j for b2 in range(max(0, bkey - lookback // window_s), bkey)
                      for j in batches.get(b2, [])]
        t0 = time.perf_counter()
        pool_ev = {j: events[j] for j in set(pool)}
        # candidates among pool with hard constraints
        cands = _pool_candidates(pool_ev, events)
        edges = []
        for (i, j) in cands:
            s = scorer.score(events[i], events[j], t_now)
            if s >= 0.05:
                edges.append((i, j, s))
        n_pairs += len(cands)
        for i, j, s in edges:
            if s >= theta:
                parent[find(i)] = find(j)
        seeds = [i for i in idx if events[i].severity >= 0.8]
        if seeds:
            P.beam_search(events, edges, scorer, theta=theta,
                          use_time=True, seeds=seeds)
        latencies.append(time.perf_counter() - t0)
    total = time.perf_counter() - t_total0
    lat = np.array(latencies)
    return dict(n_events=n, total_s=total,
                throughput_ev_s=n / total,
                p50_ms=float(np.percentile(lat, 50) * 1000),
                p95_ms=float(np.percentile(lat, 95) * 1000),
                mean_batch_ms=float(lat.mean() * 1000),
                n_batches=len(lat),
                pairs_per_event=n_pairs / max(1, n))


def _pool_candidates(gidx, events):
    """Reuse the partitioned hard-constraint enumerator on a local pool.

    gen_candidates works on indexable event sequences; _EvList exposes the
    global events under local indices, so yielded pairs are local.
    """
    gi = sorted(gidx)

    class _EvList:
        def __getitem__(self, k):
            return events[gi[k]]

        def __len__(self):
            return len(gi)

    return [(a, b) for (a, b), _ in
            P.gen_candidates(_EvList(), use_asset=True, use_time=True)]


def scale_run(scale, seed=11):
    import tracemalloc
    ds = datagen.generate(seed, scale)
    tracemalloc.start()
    timing = {}
    res = P.run_mdata(ds, timing=timing)
    cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    stream = streaming_run(ds)
    return dict(scale=scale, seed=seed,
                 n_behaviors=len(ds.behaviors), n_records=len(ds.records),
                 n_events=timing["n_events"], n_candidates=timing["n_candidates"],
                 pipeline_s=timing["total"],
                 stage_s={k: round(v, 2) for k, v in timing.items()
                          if isinstance(v, (int, float))},
                 peak_mem_mb=peak / 1e6,
                 stream=stream, timing=res["timing"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--scales", nargs="*", default=["S1", "S2", "S3"])
    args = ap.parse_args()
    out = []
    for sc in args.scales:
        r = scale_run(sc)
        out.append(r)
        print(f"{sc}: {r['n_events']} events, pipeline {r['pipeline_s']:.0f}s, "
              f"throughput {r['stream']['throughput_ev_s']:.0f} ev/s, "
              f"P95 batch {r['stream']['p95_ms']:.0f} ms, "
              f"peak mem {r['peak_mem_mb']:.0f} MB", flush=True)
    with open(os.path.join(C.RESULTS, "engineering.json"), "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=1, default=float)
    print("wrote engineering.json")
