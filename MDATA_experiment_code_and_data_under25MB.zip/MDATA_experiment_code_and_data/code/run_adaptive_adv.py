"""Enhancement item (4) of ENHANCEMENT_ROADMAP.md: adaptive adversary
evaluation.

Threat model: the attacker knows the published feature family and weights
(white-box to the design) and adapts EXECUTION choices -- not log editing.
Actions, applied to a deterministic 50% subset of test effective campaigns:

  slow    -- stretch the campaign timeline (x8, clamped to the operation
             window), attacking the sigma_b-scaled time feature and the
             48 h candidate window
  rotate  -- move every campaign IP to a fresh, TI-clean address and the
             C2 domain to an unseen one, attacking entity consistency and
             intelligence consistency
  lowkey  -- re-target the exploit entry to the least-critical exposed
             asset of the same domain, attacking asset impact and business
  combined -- all three

Reports per setting: attacked-campaign recall and mean max-R for MDATA and
B1 (rule severity, which the slow/rotate actions should barely touch), and
mean per-feature contributions over intra-campaign accepted edges, showing
which evidence dimension each action sacrifices.

Outputs: results/adaptive_S1.json, manuscript/numbers_adaptive.tex
"""
from __future__ import annotations

import hashlib
import itertools
import json
import os
import random
from collections import defaultdict

import numpy as np

import config as C
import datagen
import baselines
import evaluate
import pipeline

SCALE = "S1"
SETTINGS = ["none", "slow", "rotate", "lowkey", "combined"]
SLOW_FACTOR = 8.0
FEATURES = ["time", "entity", "reach", "behavior", "asset", "business",
            "intel"]


def attacked_cids(ds, test_c):
    eff = [cid for cid, c in ds.campaigns.items()
           if cid in test_c and c.is_effective]
    return {cid for cid in eff
            if int(hashlib.md5(("adv" + cid).encode()).hexdigest()[:8], 16)
            % 100 < 50}


def apply_slow(ds, beh_map, cids):
    for cid in cids:
        behs = sorted((beh_map[b] for b, _ in ds.campaigns[cid].behaviors),
                      key=lambda b: b.t0)
        t0 = behs[0].t0
        span = max(1, max(b.t1 for b in behs) - t0)
        f = SLOW_FACTOR
        while t0 + f * span > C.OP_SECONDS - 3600 and f > 1.5:
            f -= 0.5
        if f <= 1.5:
            continue
        for b in behs:
            shift = int(f * (b.t0 - t0)) - (b.t0 - t0)
            if shift:
                b.t0 += shift
                b.t1 = min(C.OP_SECONDS - 1, b.t1 + shift)
                for r in b.records:
                    r["ts"] = min(C.OP_SECONDS - 1, r["ts"] + shift)


def apply_rotate(ds, beh_map, cids, rng):
    grp_domains = {d for g in ds.world.groups.values() for d in g["domains"]}
    for cid in cids:
        behs = [beh_map[b] for b, _ in ds.campaigns[cid].behaviors]
        old_ips = {b.src for b in behs
                   if b.src and "." in b.src and not b.src.startswith("A")}
        mapping = {}
        for ip in old_ips:
            while True:
                new = f"185.199.{rng.randint(0, 255)}.{rng.randint(1, 254)}"
                if new not in ds.world.intel and new not in mapping.values():
                    break
            mapping[ip] = new
        newdom = f"c2-{cid.lower()}.svc-top.xyz"
        for b in behs:
            if b.src in mapping:
                b.src = mapping[b.src]
            if b.actor in mapping:
                b.actor = mapping[b.actor]
            if b.extra.get("domain") in grp_domains:
                b.extra["domain"] = newdom
            for r in b.records:
                if r.get("src") in mapping:
                    r["src"] = mapping[r["src"]]
                if r.get("dst") in mapping:
                    r["dst"] = mapping[r["dst"]]
                if r.get("domain") in grp_domains:
                    r["domain"] = newdom


def apply_lowkey(ds, beh_map, cids):
    w = ds.world
    for cid in cids:
        behs = [beh_map[b] for b, _ in ds.campaigns[cid].behaviors]
        entry = next((b.dst for b in behs
                      if b.kind == "exploit_attempt" and b.dst in w.assets),
                     None)
        if entry is None:
            continue
        alts = [a for a in w.assets.values()
                if a.domain == w.assets[entry].domain and a.exposed
                and a.aid != entry
                and a.criticality < w.assets[entry].criticality]
        if not alts:
            continue
        alt = min(alts, key=lambda a: a.criticality).aid
        for b in behs:
            if b.dst == entry:
                b.dst = alt
            if b.asset == entry:
                b.asset = alt
            for r in b.records:
                if r.get("dst") == entry:
                    r["dst"] = alt
                if r.get("asset") == entry:
                    r["asset"] = alt


def campaign_recall(ctx, scores, thr, cids):
    dets = {b for b, i in ctx.bidx.items() if scores[i] >= thr}
    hits = []
    for cid in cids:
        bids = [b for b, _ in ctx.ds.campaigns[cid].behaviors]
        hits.append(any(b in dets for b in bids))
    return float(sum(hits) / max(1, len(hits))) if hits else None


def max_r(ctx, scores, cids):
    vals = []
    for cid in cids:
        bids = [b for b, _ in ctx.ds.campaigns[cid].behaviors]
        vals.append(max((scores[ctx.bidx[b]] for b in bids if b in ctx.bidx),
                        default=0.0))
    return float(sum(vals) / max(1, len(vals))) if vals else None


def feature_contrib(res, ds, cids):
    """Mean per-feature contribution over accepted intra-campaign edges."""
    edge_set = {(min(i, j), max(i, j)): s for i, j, s in res["edges"]}
    evs_of_bid = defaultdict(list)
    for k, e in enumerate(res["events"]):
        evs_of_bid[e.bid].append(k)
    acc = defaultdict(list)
    for cid in cids:
        bids = [b for b, _ in ds.campaigns[cid].behaviors]
        idxs = [k for b in bids for k in evs_of_bid.get(b, ())]
        for i, j in itertools.combinations(sorted(idxs), 2):
            if (i, j) in edge_set:
                ex = res["scorer"].explain(res["events"][i],
                                           res["events"][j], C.OP_SECONDS)
                for k, v in ex["contribution"].items():
                    acc[k].append(v)
    return {k: float(sum(v) / len(v)) for k, v in acc.items()} if acc else {}


def main():
    per_seed = []
    for seed in C.MASTER_SEEDS:
        base = datagen.generate(seed, SCALE)      # deterministic base
        ctx0 = evaluate.EvalContext(base)
        cids = attacked_cids(base, ctx0.test_c)
        row = dict(seed=seed, n_attacked=len(cids), settings={})
        for setting in SETTINGS:
            ds = datagen.generate(seed, SCALE)    # fresh identical copy
            beh_map = {b.bid: b for b in ds.behaviors}
            if setting in ("slow", "combined"):
                apply_slow(ds, beh_map, cids)
            if setting in ("rotate", "combined"):
                apply_rotate(ds, beh_map, cids, random.Random(seed))
            if setting in ("lowkey", "combined"):
                apply_lowkey(ds, beh_map, cids)
            res = pipeline.run_mdata(ds)
            ctx = evaluate.EvalContext(ds)
            m = ctx.evaluate(res)
            sc = m["_sc"]
            r_mdata = campaign_recall(ctx, sc, m["threshold"], cids)
            mr = max_r(ctx, sc, cids)
            m1 = ctx.evaluate(baselines.run_b1(ds))
            r_b1 = campaign_recall(ctx, m1["_sc"], m1["threshold"], cids)
            row["settings"][setting] = dict(
                f1=float(m["f1"]), recall_attacked=r_mdata, max_r_attacked=mr,
                recall_attacked_b1=r_b1,
                contributions=feature_contrib(res, ds, cids))
            print(f"seed {seed} {setting}: attacked-recall MDATA "
                  f"{r_mdata:.3f} B1 {r_b1:.3f} maxR {mr:.3f} "
                  f"F1 {m['f1']:.3f}", flush=True)
        per_seed.append(row)

    agg = {}
    for setting in SETTINGS:
        part = {}
        for k in ("f1", "recall_attacked", "max_r_attacked", "recall_attacked_b1"):
            vals = [s["settings"][setting][k] for s in per_seed]
            part[k] = dict(mean=float(np.mean(vals)),
                           std=float(np.std(vals)))
        for f in FEATURES:
            vals = [s["settings"][setting]["contributions"].get(f)
                    for s in per_seed]
            vals = [v for v in vals if v is not None]
            if vals:
                part[f"contrib_{f}"] = float(np.mean(vals))
        agg[setting] = part
    out = dict(scale=SCALE, slow_factor=SLOW_FACTOR, settings=SETTINGS,
               agg=agg, per_seed=per_seed)
    p = os.path.join(C.RESULTS, f"adaptive_{SCALE}.json")
    with open(p, "w") as f:
        json.dump(out, f, indent=1)
    print("saved", p, flush=True)
    r0 = agg["none"]["recall_attacked"]["mean"]
    lines = [f"\\newcommand\\nAdvNone{{{100*r0:.1f}}}"]
    for s in ("slow", "rotate", "lowkey", "combined"):
        lines.append(f"\\newcommand\\nAdv{s.capitalize()}"
                     f"{{{100*agg[s]['recall_attacked']['mean']:.1f}}}")
    lines.append(f"\\newcommand\\nAdvBOneNone"
                 f"{{{100*agg['none']['recall_attacked_b1']['mean']:.1f}}}")
    lines.append(f"\\newcommand\\nAdvBOneCombined"
                 f"{{{100*agg['combined']['recall_attacked_b1']['mean']:.1f}}}")
    p2 = os.path.join(C.BASE, "manuscript", "numbers_adaptive.tex")
    with open(p2, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("saved", p2, flush=True)


if __name__ == "__main__":
    main()
