"""Enhancement item (3) of ENHANCEMENT_ROADMAP.md: MDATA-Agent -- an
API-model agent triage layer over MEGA-Bench cases.

Three modes per campaign case (S2, seed 11; effective, recon-only and
failed-exploit campaigns mixed as generated):

  naive     : headline-only single call (simulates naive LLM use);
  grounded  : evidence card + templated fields + explicit prohibition,
              the paper's single-call constraint (same protocol as the
              local-model study in run_llm.py);
  agent     : two-agent verify loop --
              (1) analyst agent drafts a verdict + report from the card;
              (2) verifier agent receives the draft plus the evidence
                  table, lists claims/IOCs not supported by evidence;
              (3) analyst revises into the final report.
              Fabrication is measured on the draft and on the final
              output, so the verifier's catch rate is observable.

Models: any OpenAI-compatible chat API (base URL + key + model list in
llm_api.json).  Metrics reuse run_llm.metrics (fabrication rate,
conclusion overreach, evidence coverage, template compliance) plus
verdict accuracy against ground truth and token accounting.

Outputs: results/agents_S2_11.json, manuscript/numbers_agents.tex
"""
from __future__ import annotations

import argparse
import json
import os
import re
import time
import urllib.request

import numpy as np

import config as C
import datagen
from run_llm import evidence_card, metrics


def case_card(ds, camp):
    """Evidence card with campaign-scoped TI (run_llm.evidence_card
    returns the whole-dataset intel list, which would pollute the
    evidence set; the card lines themselves are campaign-scoped)."""
    card, _ = evidence_card(ds, camp)
    behs = {b.bid: b for b in ds.behaviors}
    ents = set()
    for bid, _ in camp.behaviors:
        b = behs[bid]
        ents.update({b.src, b.dst, b.extra.get("domain")} - {None})
    intel = [f"{e}:{ds.world.intel[e]['verdict']}"
             for e in sorted(str(x) for x in ents)
             if e in ds.world.intel]
    return card, intel

CFG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "llm_api.json")
VERDICT_RE = re.compile(
    r"VERDICT\s*[:=]\s*\**\s*(EFFECTIVE_ATTACK|RECON_TO_VERIFY|"
    r"ATTEMPT_UNCONFIRMED)", re.I)


def load_cfg():
    with open(CFG_PATH, encoding="utf-8") as f:
        return json.load(f)


def chat(cfg, model, messages, max_tokens=1200, temperature=0.0, retries=3):
    url = cfg["base_url"].rstrip("/") + "/chat/completions"
    body = json.dumps(dict(model=model, messages=messages,
                           max_tokens=max_tokens,
                           temperature=temperature)).encode()
    last = None
    for attempt in range(retries):
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + cfg["api_key"]})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                out = json.load(r)
            return (out["choices"][0]["message"]["content"],
                    out.get("usage", {}))
        except Exception as ex:                       # noqa: BLE001
            last = ex
            time.sleep(2 * (attempt + 1))
    print(f"  [api-error] {model}: {last}", flush=True)
    return None, {}


NAIVE_SYS = "You are a SOC analyst assistant. Write an incident report."

GROUNDED_SYS = (
    "You are a SOC analyst assistant. Using ONLY the evidence below, "
    "fill the template. Do NOT invent IPs, domains, rules, assets or "
    "conclusions not present in the evidence. If evidence is "
    "reconnaissance-only, state that no compromise is confirmed.\n"
    "Template: VERDICT: EFFECTIVE_ATTACK | RECON_TO_VERIFY | "
    "ATTEMPT_UNCONFIRMED, then SUMMARY: ... | STAGE: ... | AFFECTED: "
    "... | CONFIDENCE: ... | RECOMMENDED_ACTION: ...")

VERIFIER_SYS = (
    "You are an evidence auditor. Compare the draft report with the "
    "evidence table. List every IP, domain, asset id, rule name or "
    "conclusion in the draft that is NOT supported by the evidence, "
    "one per line prefixed UNSUPPORTED:. If everything is supported "
    "answer only: ALL_SUPPORTED.")

REVISE_SYS = (
    "You are a SOC analyst assistant. Revise the draft report using "
    "ONLY the evidence below. Remove or correct every item the auditor "
    "flagged as unsupported; do not introduce any new indicator. Keep "
    "the template: VERDICT: ... | SUMMARY: ... | STAGE: ... | "
    "AFFECTED: ... | CONFIDENCE: ... | RECOMMENDED_ACTION: ...")


def parse_verdict(text):
    m = VERDICT_RE.search(text or "")
    if not m:
        return None
    v = m.group(1).upper()
    return {"EFFECTIVE_ATTACK": "eff",
            "RECON_TO_VERIFY": "recon",
            "ATTEMPT_UNCONFIRMED": "recon"}[v]


def verdict_correct(v, is_eff):
    if v is None:
        return False
    return (v == "eff") == bool(is_eff)


def run_case(cfg, model, mode, card, intel, headline, is_eff):
    card_t = card[:1400]
    if mode == "naive":
        out, usage = chat(cfg, model, [
            {"role": "system", "content": NAIVE_SYS},
            {"role": "user", "content": f"Headline: {headline}"}])
    elif mode == "grounded":
        out, usage = chat(cfg, model, [
            {"role": "system", "content": GROUNDED_SYS},
            {"role": "user", "content":
             f"Evidence:\n{card_t}\nTI: {intel}\nHeadline: {headline}"}])
    else:                                              # agent loop
        draft, u1 = chat(cfg, model, [
            {"role": "system", "content": GROUNDED_SYS},
            {"role": "user", "content":
             f"Evidence:\n{card_t}\nTI: {intel}\nHeadline: {headline}"}])
        if draft is None:
            return None
        audit, u2 = chat(cfg, model, [
            {"role": "system", "content": VERIFIER_SYS},
            {"role": "user", "content":
             f"Evidence:\n{card_t}\nDraft:\n{draft}"}])
        if audit is None:
            out, usage = draft, u1
        else:
            out, u3 = chat(cfg, model, [
                {"role": "system", "content": REVISE_SYS},
                {"role": "user", "content":
                 f"Evidence:\n{card_t}\nDraft:\n{draft}\nAudit:\n{audit}"}])
            out = out if out is not None else draft
            usage = {k: u1.get(k, 0) + u2.get(k, 0) + u3.get(k, 0)
                     for k in ("prompt_tokens", "completion_tokens")}
    if out is None:
        return None
    m = metrics(out, card, intel, is_eff)
    v = parse_verdict(out)
    m.update(verdict=v, verdict_correct=verdict_correct(v, is_eff))
    return dict(report=out[:2000], usage=usage, **m)


def main(scale="S2", seed=11, n_cases=60):
    cfg = load_cfg()
    if "FILL_ME" in cfg["base_url"]:
        print("llm_api.json base_url not configured -- aborting")
        return
    ds = datagen.generate(seed, scale)
    camps = [c for c in ds.campaigns.values()][:n_cases]
    rows = []
    for model in cfg["models"]:
        for camp in camps:
            card, intel = case_card(ds, camp)
            headline = (f"Suspicious multi-stage activity from a source "
                        f"host in {','.join(camp.domains)}")
            for mode in ("naive", "grounded", "agent"):
                r = run_case(cfg, model, mode, card, intel, headline,
                             camp.is_effective)
                if r is None:
                    continue
                r.update(cid=camp.cid, mode=mode, model=model,
                         is_effective=camp.is_effective,
                         truncation=camp.truncation)
                rows.append(r)
                print(f"{model} {camp.cid} {mode:8s} "
                      f"fab={r['fabrication_rate']:.2f} "
                      f"over={r['conclusion_overreach']} "
                      f"cov={r['evidence_coverage']:.2f} "
                      f"vcorr={int(bool(r['verdict_correct']))}",
                      flush=True)
    path = os.path.join(C.RESULTS, f"agents_{scale}_{seed}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=1, ensure_ascii=False)
    print("saved", path, flush=True)

    # aggregate per (model, mode) and overall per mode
    def agg(sel):
        if not sel:
            return {}
        keys = ("fabrication_rate", "conclusion_overreach",
                "evidence_coverage", "template_compliance")
        out = {k: float(np.mean([r[k] for r in sel])) for k in keys}
        out["verdict_accuracy"] = float(
            np.mean([r["verdict_correct"] for r in sel]))
        out["verdict_answered"] = float(
            np.mean([r["verdict"] is not None for r in sel]))
        out["prompt_tokens"] = int(sum(r["usage"].get("prompt_tokens", 0)
                                       for r in sel))
        out["completion_tokens"] = int(
            sum(r["usage"].get("completion_tokens", 0) for r in sel))
        return out

    summary = {"per_model": {}, "per_mode": {}}
    for model in cfg["models"]:
        for mode in ("naive", "grounded", "agent"):
            sel = [r for r in rows if r["model"] == model
                   and r["mode"] == mode]
            summary["per_model"][f"{model}|{mode}"] = agg(sel)
    for mode in ("naive", "grounded", "agent"):
        sel = [r for r in rows if r["mode"] == mode]
        summary["per_mode"][mode] = agg(sel)
    for k, v in summary["per_mode"].items():
        print(mode_line(k, v), flush=True)
    with open(os.path.join(C.RESULTS, f"agents_{scale}_{seed}_summary.json"),
              "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=1)

    pm = summary["per_mode"]
    lines = [
        f"\\newcommand\\nAgNaiveFab{{{100*pm['naive']['fabrication_rate']:.1f}}}",
        f"\\newcommand\\nAgGroundFab{{{100*pm['grounded']['fabrication_rate']:.1f}}}",
        f"\\newcommand\\nAgAgentFab{{{100*pm['agent']['fabrication_rate']:.1f}}}",
        f"\\newcommand\\nAgNaiveOver{{{100*pm['naive']['conclusion_overreach']:.1f}}}",
        f"\\newcommand\\nAgGroundOver{{{100*pm['grounded']['conclusion_overreach']:.1f}}}",
        f"\\newcommand\\nAgAgentOver{{{100*pm['agent']['conclusion_overreach']:.1f}}}",
        f"\\newcommand\\nAgGroundAcc{{{100*pm['grounded']['verdict_accuracy']:.1f}}}",
        f"\\newcommand\\nAgAgentAcc{{{100*pm['agent']['verdict_accuracy']:.1f}}}",
        f"\\newcommand\\nAgNaiveAcc{{{100*pm['naive']['verdict_accuracy']:.1f}}}",
        f"\\newcommand\\nAgGroundCov{{{100*pm['grounded']['evidence_coverage']:.1f}}}",
        f"\\newcommand\\nAgAgentCov{{{100*pm['agent']['evidence_coverage']:.1f}}}",
    ]
    p2 = os.path.join(C.BASE, "manuscript", "numbers_agents.tex")
    with open(p2, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("saved", p2, flush=True)


def mode_line(mode, v):
    return (f"{mode:9s} fab={v['fabrication_rate']:.3f} "
            f"over={v['conclusion_overreach']:.3f} "
            f"acc={v['verdict_accuracy']:.3f} "
            f"answered={v['verdict_answered']:.2f} "
            f"tok={v['prompt_tokens']}+{v['completion_tokens']}")


def offline_test(n=3):
    """Build case cards without calling the API."""
    ds = datagen.generate(11, "S2")
    camps = [c for c in ds.campaigns.values()][:n]
    for camp in camps:
        card, intel = case_card(ds, camp)
        print(f"--- {camp.cid} eff={camp.is_effective} "
              f"trunc={camp.truncation} card_len={len(card)} "
              f"intel={len(intel)}")
        print(card[:300])
    print("offline case construction OK")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", default="S2")
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--cases", type=int, default=60)
    ap.add_argument("--offline-test", action="store_true")
    a = ap.parse_args()
    if a.offline_test:
        offline_test()
    else:
        main(a.scale, a.seed, a.cases)
