"""Ablation-only companion to run_main.py.

run_main.significance() hard-codes ref='MDATA'; running the ablation
method subset through run_main.py crashes at aggregation and loses the
results.  This wrapper reuses run_main._one_seed unchanged and writes
results/ablations_S2.json without the significance step; merging into
main_S2.json happens in merge_ablations.py.
"""
from __future__ import annotations

import json
import os
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np

import config as C
import run_main as RM

METHODS = ["B3", "A1_no_asset", "A2_no_intel", "A3_no_time",
           "A4_no_evidence"]


def main(scale="S2"):
    tasks = [(s, scale, METHODS) for s in C.MASTER_SEEDS]
    t0 = time.time()
    runs = []
    with ProcessPoolExecutor(max_workers=3) as ex:
        for res in ex.map(RM._one_seed, tasks):
            runs.append(res)
            print(f"seed {res['seed']} done in {res['wall_s']:.0f}s "
                  f"({len(res['methods'])} methods)", flush=True)
    out = dict(scale=scale, seeds=C.MASTER_SEEDS,
               dataset=dict(n_behaviors=float(np.mean(
                   [r["n_behaviors"] for r in runs]))),
               runs=runs, agg=RM.aggregate(runs), sig={},
               wall_s=time.time() - t0)
    path = os.path.join(C.RESULTS, f"ablations_{scale}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, default=float)
    print(f"wrote {path} ({out['wall_s']:.0f}s)", flush=True)
    for m in out["agg"]:
        a = out["agg"][m]
        print(f"{m:14s} F1={a['f1']['mean']:.3f} "
              f"PR-AUC={a['prauc']['mean']:.3f} "
              f"compl={a['completeness']['mean']:.2f}", flush=True)


if __name__ == "__main__":
    main()
