"""Merge results/ablations_S2.json into results/main_S2.json so that
make_tables.py sees the full method set (B1-B5 + A1-A4)."""
from __future__ import annotations

import json
import os

import config as C

MAIN = os.path.join(C.RESULTS, "main_S2.json")
ABL = os.path.join(C.RESULTS, "ablations_S2.json")


def main():
    m = json.load(open(MAIN, encoding="utf-8"))
    a = json.load(open(ABL, encoding="utf-8"))
    abl_seeds = {r["seed"] for r in a["runs"]}
    for r in m["runs"]:
        if r["seed"] not in abl_seeds:
            raise SystemExit(f"seed mismatch: {r['seed']} missing in ablations")
    by_seed = {r["seed"]: r for r in a["runs"]}
    for r in m["runs"]:
        for name, meth in by_seed[r["seed"]]["methods"].items():
            if name not in r["methods"]:
                r["methods"][name] = meth
    m["agg"].update(a["agg"])
    with open(MAIN, "w", encoding="utf-8") as f:
        json.dump(m, f, indent=1, default=float)
    print("merged methods:", sorted(m["agg"]))


if __name__ == "__main__":
    main()
