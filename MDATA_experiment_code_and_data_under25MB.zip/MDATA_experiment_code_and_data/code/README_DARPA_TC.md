# DARPA TC THEIA 外部验证执行说明(⑤)

按 EXTERNAL_VALIDATION_PLAN.md 执行;快速序列:
```bash
git clone https://github.com/ubc-provenance/PIDSMaker.git
cd PIDSMaker && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python pidsmaker/main.py all --dataset THEIA_E3     # 下载+建图,~12GB
# 找到建好的图 CSV 与 Ground_Truth/orthrus/THEIA_E3/*.csv
# 先dump表头发给本地会话对齐列名:
head -3 <graph_csv> > schema_dump.txt
python run_darpatc_external.py --graph <graph_csv> --gt <gt_dir>
```
回传:schema_dump.txt、stdout 输出、以及任何报错栈。
若列名不匹配,把建图 CSV 前几行发回,由本地会话补齐映射后重跑。
