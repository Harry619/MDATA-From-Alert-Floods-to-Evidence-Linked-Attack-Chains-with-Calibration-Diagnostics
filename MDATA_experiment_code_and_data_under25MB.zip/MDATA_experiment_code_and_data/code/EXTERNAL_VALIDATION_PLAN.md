# ⑤ 公开数据集外部验证——云端执行包(2026-11-04)

> 本机只写作不跑重计算(用户既定分工)。以下内容在多卡服务器上执行。

## 数据选择

- **主选: DARPA TC E3 THEIA**(Linux,2 个攻击场景:Firefox 漏洞利用投放
  Drakon 植入体→C2 外连;多阶段、有逐节点真值)。
- 备选: CADETS_E3(FreeBSD,3 攻击,10GB)、OpTC(Windows Sysmon,18攻击日)。
- 通过 **PIDSMaker**(ubc-provenance/PIDSMaker)获取:它把原始 Avro/JSON
  构建成图并配套三套逐节点真值(orthrus/reapr/threatrace,均为
  "uuid,labels,count" 的逐攻击 CSV)。

## 服务器命令序列

```bash
git clone https://github.com/ubc-provenance/PIDSMaker.git
cd PIDSMaker
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# 构建 THEIA 图(自动下载原始数据,~12GB 磁盘)
python pidsmaker/main.py all --dataset THEIA_E3
# 产物: 构建图 + Ground_Truth/orthrus/THEIA_E3/*.csv
```

## 映射设计(CDM 溯源图 → 十元组)

- **行为(behaviour)** = 一个 subject 在滑动窗内对同一 object 的边聚合
  (进程→文件/套接字/进程),类似 pipeline.normalize 的单通道聚合。
- **动作类别** 按边类型+对象类型启发式:
  `EXECUTE/process→新进程`→lateral;`WRITE/→/tmp、可疑路径`→staging;
  `NETWORK/connect 外部IP:443`→c2_beacon;Firefox 崩溃+后续写→exploit。
- **实体键**: src=subject uuid(映射为稳定短id), dst=object uuid,
  /24 网络键取自套接字外连地址。
- **资产台账**: 文件系统关键节点(系统目录/服务二进制) criticality=0.7,
  其余 0.3;intel 置空(A2 消融等价场景,论文中如实说明)。
- **时钟**: 单源审计,skew≈0,clock_conf=1.0。

## 评估协议

- 只评 **攻击链重构**(与论文 RQ2 同口径):node F1 / edge F1 /
  阶段编辑距离 / 完整度(≥50% 覆盖),真值=orthrus 逐攻击 uuid 集
  (reapr 作敏感性检查)。
- 基线:B3(无资产关系)、B2(时间+实体启发式);MDATA 用论文同参数
  (θ=0.35,B=32,L=12),不做任何针对该数据集的调参。
- 预期结论:多源通道缺失、情报为空的退化条件下,时序+行为+资产
  特征仍能重构主链——对应论文"适用边界"的实证。

## 骨架代码

`run_darpatc_external.py`(本目录):加载 PIDSMaker 图 CSV → 伪 Dataset →
复用 pipeline/evaluate。TODO 处需按实际列名补齐(服务器上第一次跑时)。
