"""Enhancement item (1) of ENHANCEMENT_ROADMAP.md: calibration analysis of
the six-dimension threat score R.

Validates (or falsifies) the paper's "calibrated" claim:
  * 10-bin reliability diagram, ECE / MCE / Brier on the test split
  * isotonic (PAVA) recalibration fitted on the calibration split,
    evaluated on the test split (before vs after)
  * risk-band validity under the verification-first policy
    (high band := interval lower bound >= T_HIGH), band-conditional
    empirical effective-attack rates
  * uncertainty-interval [R-kU, R+kU] coverage against bin-estimated
    true probabilities and mean interval width

Outputs: results/calibration_S2.json, figures/fig_calibration.pdf,
manuscript/numbers_calibration.tex (independent file names; no existing
script is touched).
"""
from __future__ import annotations

import json
import os

import numpy as np

import config as C
import datagen
import evaluate
import pipeline

N_BINS = 10


# ------------------------------------------------------------------ PAVA --
def fit_isotonic(x, y):
    """PAVA isotonic regression on (x, y); returns an interpolation model
    (vx, vals) aligned per unique x, usable with np.interp."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    order = np.argsort(x, kind="stable")
    xs, ys = x[order], y[order]
    sv, sw = [], []
    for yi in ys:
        sv.append(float(yi))
        sw.append(1)
        while len(sv) >= 2 and sv[-2] > sv[-1]:
            w2, v2 = sw.pop(), sv.pop()
            tw = sw[-1] + w2
            sv[-1] = (sv[-1] * sw[-1] + v2 * w2) / tw
            sw[-1] = tw
    vals = []
    for v, w in zip(sv, sw):
        vals.extend([v] * w)
    vals = np.array(vals)
    vx, inv = np.unique(xs, return_inverse=True)
    summed = np.bincount(inv, weights=vals, minlength=len(vx))
    counts = np.bincount(inv, minlength=len(vx))
    return vx, summed / counts


def predict_iso(model, x):
    vx, vals = model
    return np.clip(np.interp(x, vx, vals), 0.0, 1.0)


# ---------------------------------------------------------- reliability --
def reliability(scores, labels, n_bins=N_BINS):
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(scores, edges[1:-1]), 0, n_bins - 1)
    rows, ece, mce = [], 0.0, 0.0
    for b in range(n_bins):
        m = idx == b
        n = int(m.sum())
        if n == 0:
            rows.append(dict(bin=b, lo=float(edges[b]), hi=float(edges[b + 1]),
                             n=0, conf=None, rate=None))
            continue
        conf = float(scores[m].mean())
        rate = float(labels[m].mean())
        gap = abs(conf - rate)
        ece += n / len(scores) * gap
        mce = max(mce, gap)
        rows.append(dict(bin=b, lo=float(edges[b]), hi=float(edges[b + 1]),
                         n=n, conf=conf, rate=rate))
    return rows, float(ece), float(mce)


def bin_rates(scores, rows, n_bins=N_BINS):
    """Map each score to the empirical rate of its reliability bin."""
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    idx = np.clip(np.digitize(scores, edges[1:-1]), 0, n_bins - 1)
    rate_of = {r["bin"]: r["rate"] for r in rows if r["n"] > 0}
    return np.array([rate_of.get(i, np.nan) for i in idx])


# ------------------------------------------------------------------ run --
def run(scale="S2"):
    kappa = C.KAPPA
    per_seed, series = [], []
    for seed in C.MASTER_SEEDS:
        ds = datagen.generate(seed, scale)
        res = pipeline.run_mdata(ds)
        ctx = evaluate.EvalContext(ds)
        bids = ctx.bids
        R = np.array([res["scores"].get(b, 0.0) for b in bids])
        U = np.array([res["meta"].get(b, (0.0, 0.0, None))[1] for b in bids])
        lb = ctx.lb.astype(float)
        te = ctx.test_mask
        # calibration-consistent fit set: behaviours of calibration-split
        # campaigns plus calibration-split noise behaviours (no leakage from
        # test campaigns through shared behaviours)
        bid2cid = {bid: cid for cid, c in ds.campaigns.items()
                   for bid, _ in c.behaviors}
        fit_mask = np.array([
            (b in bid2cid and bid2cid[b] in ctx.train_c)
            or (b not in bid2cid and b in ctx.train_b) for b in bids])

        rows_raw, ece_raw, mce_raw = reliability(R[te], lb[te])
        brier_raw = float(np.mean((R[te] - lb[te]) ** 2))
        model = fit_isotonic(R[fit_mask], lb[fit_mask])
        Rp = predict_iso(model, R[te])
        rows_iso, ece_iso, _ = reliability(Rp, lb[te])
        brier_iso = float(np.mean((Rp - lb[te]) ** 2))

        # risk bands by interval lower bound (verification-first policy)
        lo = np.maximum(0.0, R - kappa * U)
        hi = np.minimum(1.0, R + kappa * U)
        band = np.where(lo >= C.T_HIGH, 2, np.where(lo >= C.T_MED, 1, 0))
        band_stats = {}
        for b, name in ((0, "low"), (1, "med"), (2, "high")):
            m = te & (band == b)
            band_stats[name] = dict(
                n=int(m.sum()),
                rate=float(lb[m].mean()) if m.sum() else None)

        # interval coverage: does [lo, hi] contain the bin-estimated true
        # probability of the behaviour?
        truth_est = np.full(len(R), np.nan)
        truth_est[te] = bin_rates(R[te], rows_raw)
        m = te & ~np.isnan(truth_est)
        coverage = float(np.mean((truth_est[m] >= lo[m]) & (truth_est[m] <= hi[m])))
        width = float(np.mean(hi[te] - lo[te]))

        per_seed.append(dict(
            seed=seed,
            ece_raw=ece_raw, mce_raw=mce_raw, brier_raw=brier_raw,
            ece_iso=ece_iso, brier_iso=brier_iso,
            bands=band_stats, coverage=coverage, width=width,
            n_test=int(te.sum()),
            reliability_raw=rows_raw, reliability_iso=rows_iso))
        series.append(dict(ece_raw=ece_raw, ece_iso=ece_iso,
                           brier_raw=brier_raw, brier_iso=brier_iso,
                           coverage=coverage, width=width,
                           **{f"band_{k}_rate": v["rate"]
                              for k, v in band_stats.items()}))
        print(f"seed {seed}: ECE raw {ece_raw:.3f} -> iso {ece_iso:.3f}; "
              f"Brier {brier_raw:.3f} -> {brier_iso:.3f}; "
              f"high-band rate {band_stats['high']['rate']}; "
              f"coverage {coverage:.3f}", flush=True)

    keys = [k for k in series[0] if isinstance(series[0][k], float)]
    agg = {k: dict(mean=float(np.mean([s[k] for s in series])),
                   std=float(np.std([s[k] for s in series]))) for k in keys}
    out = dict(scale=scale, n_bins=N_BINS, kappa=kappa,
               t_high=C.T_HIGH, t_med=C.T_MED, agg=agg, per_seed=per_seed)
    path = os.path.join(C.RESULTS, f"calibration_{scale}.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=1)
    print("saved", path, flush=True)
    make_figure(out, scale)
    make_numbers(out, scale)
    return out


# --------------------------------------------------------------- figure --
def make_figure(out, scale):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib unavailable; figure skipped", flush=True)
        return
    seeds = out["per_seed"]
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.2))

    ax = axes[0]
    for key, color, label in (("reliability_raw", "#1f6fb4", "raw $R$"),
                              ("reliability_iso", "#d1620b", "isotonic")):
        conf = np.array([[r["conf"] for r in s[key]] for s in seeds], float)
        rate = np.array([[r["rate"] for r in s[key]] for s in seeds], float)
        n = np.array([[r["n"] for r in s[key]] for s in seeds], float)
        w = np.nanmean(n, axis=0)
        w = w / max(1.0, np.nansum(w))
        cm = np.nanmean(conf, axis=0)
        rm = np.nanmean(rate, axis=0)
        ax.plot(cm, rm, "o-", color=color, ms=4,
                label=f"{label} (ECE {np.nanmean(np.abs(cm - rm)):.3f})")
        for x, y, ww in zip(cm, rm, w):
            if ww > 0.04:
                ax.annotate(f"{int(ww * 100)}%", (x, y), fontsize=6,
                            xytext=(3, -9), textcoords="offset points",
                            color=color)
    ax.plot([0, 1], [0, 1], "k--", lw=0.8)
    ax.set_xlabel("predicted risk (bin mean)")
    ax.set_ylabel("empirical effective-attack rate")
    ax.set_title("Reliability diagram (test split)")
    ax.legend(fontsize=7, loc="upper left")

    ax = axes[1]
    names = ["low", "med", "high"]
    rates = [out["agg"][f"band_{k}_rate"]["mean"] for k in names]
    stds = [out["agg"][f"band_{k}_rate"]["std"] for k in names]
    xs = np.arange(3)
    ax.bar(xs, rates, yerr=stds, capsize=3,
           color=["#9fc3e6", "#f0b37f", "#c0504d"], edgecolor="k", lw=0.5)
    for x, r, k in zip(xs, rates, names):
        ns = [s["bands"][k]["n"] for s in seeds]
        ax.annotate(f"n={int(np.mean(ns))}", (x, max(r, 0.02)),
                    ha="center", fontsize=7, xytext=(0, 4),
                    textcoords="offset points")
    ax.axhline(out["t_high"], color="k", ls=":", lw=0.8)
    ax.set_xticks(xs)
    ax.set_xticklabels(["low\n(lo<0.5)", "medium\n(lo≥0.5)", "high\n(lo≥0.7)"])
    ax.set_ylabel("empirical effective-attack rate")
    ax.set_title("Risk-band validity (lower-bound policy)")
    ax.set_ylim(0, 1.05)

    fig.tight_layout()
    p = os.path.join(C.BASE, "manuscript", "fig_calibration.pdf")
    fig.savefig(p, bbox_inches="tight")
    print("saved", p, flush=True)


# --------------------------------------------------------------- macros --
def make_numbers(out, scale):
    a = out["agg"]

    def pct(v, d=1):
        return f"{100 * v:.{d}f}"

    lines = [
        f"\\newcommand\\nCalEceRaw{{{a['ece_raw']['mean']:.3f}}}",
        f"\\newcommand\\nCalEceIso{{{a['ece_iso']['mean']:.3f}}}",
        f"\\newcommand\\nCalMceRaw{{{out['per_seed'][0]['mce_raw']:.3f}}}",
        f"\\newcommand\\nCalBrierRaw{{{a['brier_raw']['mean']:.3f}}}",
        f"\\newcommand\\nCalBrierIso{{{a['brier_iso']['mean']:.3f}}}",
        f"\\newcommand\\nCalBandLowRate{{{pct(a['band_low_rate']['mean'])}}}",
        f"\\newcommand\\nCalBandMedRate{{{pct(a['band_med_rate']['mean'])}}}",
        f"\\newcommand\\nCalBandHiRate{{{pct(a['band_high_rate']['mean'])}}}",
        f"\\newcommand\\nCalCoverage{{{pct(a['coverage']['mean'])}}}",
        f"\\newcommand\\nCalWidth{{{a['width']['mean']:.3f}}}",
    ]
    p = os.path.join(C.BASE, "manuscript", "numbers_calibration.tex")
    with open(p, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("saved", p, flush=True)


if __name__ == "__main__":
    run("S2")
