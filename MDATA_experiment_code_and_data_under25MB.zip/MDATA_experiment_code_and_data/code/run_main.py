"""RQ1-RQ3: main comparison (B1-B4 vs MDATA), ablations, and per-campaign
significance tests.  Runs `--seeds` dataset replicas at `--scale` in
parallel processes and writes results/main_<scale>.json.
"""
from __future__ import annotations

import argparse
import json
import os
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np

import config as C
import datagen
import baselines
import evaluate


METHODS = {
    "B1": baselines.run_b1,
    "B2": baselines.run_b2,
    "B3": baselines.run_b3,
    "B4": baselines.run_b4,
    "MDATA": baselines.run_mdata_full,
}

ABLATIONS = {
    "A1_no_asset": dict(use_asset=False),
    "A2_no_intel": dict(use_intel=False),
    "A3_no_time": dict(use_time=False),
    "A4_no_evidence": dict(use_evidence=False),
}


def _one_seed(args):
    seed, scale, methods = args
    t0 = time.time()
    ds = datagen.generate(seed, scale)
    ctx = evaluate.EvalContext(ds)
    out = dict(seed=seed, scale=scale, n_behaviors=len(ds.behaviors),
               n_records=len(ds.records),
               n_campaigns=len(ds.campaigns),
               n_eff=sum(1 for c in ds.campaigns.values() if c.is_effective),
               timing={}, methods={})
    for name in methods:
        if name == "A1_no_asset" and "B3" in methods:
            continue                      # A1 is identical to B3; reuse
        t1 = time.time()
        if name in METHODS:
            res = METHODS[name](ds)
        else:
            res = baselines.run_mdata_full(ds, **ABLATIONS[name])
            res["name"] = name
        m = ctx.evaluate(res)
        m.pop("_sc", None)
        m.pop("dets", None)
        if "_correct_test" in m:
            m["correct_test"] = [int(x) for x in m.pop("_correct_test")]
        m["runtime_s"] = time.time() - t1
        if name == "B3" and "A1_no_asset" in methods:
            a1 = dict(m)
            a1["name"] = "A1_no_asset"
            out["methods"]["A1_no_asset"] = a1
        if "timing" in res and "total" in (res.get("timing") or {}):
            m["pipeline_s"] = res["timing"]["total"]
            m["stage_timing"] = {k: v for k, v in res["timing"].items()
                                 if isinstance(v, (int, float))}
        out["methods"][name] = m
    out["wall_s"] = time.time() - t0
    return out


def aggregate(runs):
    """Mean +- std across seeds; CIs already per-seed bootstrapped."""
    keys = [k for k in runs[0]["methods"].values()][0].keys()
    methods = sorted(runs[0]["methods"])
    agg = {}
    for mname in methods:
        agg[mname] = {}
        for k in keys:
            if k in ("name", "threshold", "per_campaign_recall"):
                continue
            vals = [r["methods"][mname][k] for r in runs
                    if isinstance(r["methods"][mname].get(k), (int, float))]
            if not vals:
                continue
            agg[mname][k] = dict(mean=float(np.mean(vals)),
                                 std=float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
                                 values=vals)
    return agg


def significance(runs, ref="MDATA"):
    """McNemar test on pooled behaviour-level correctness (all seeds)."""
    out = {}
    if "correct_test" not in runs[0]["methods"][ref]:
        return out
    ref_c = np.concatenate([r["methods"][ref]["correct_test"] for r in runs])
    for mname in runs[0]["methods"]:
        if mname == ref or "correct_test" not in runs[0]["methods"].get(mname, {}):
            continue
        mc = np.concatenate([r["methods"][mname]["correct_test"] for r in runs])
        p, b01, b10 = evaluate.mcnemar_p(ref_c.astype(bool), mc.astype(bool))
        out[mname] = dict(p=p, wins=b01, losses=b10)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", default=C.MAIN_SCALE)
    ap.add_argument("--seeds", type=int, nargs="*", default=C.MASTER_SEEDS)
    ap.add_argument("--methods", nargs="*", default=list(METHODS))
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    tasks = [(s, args.scale, args.methods) for s in args.seeds]
    t0 = time.time()
    runs = []
    with ProcessPoolExecutor(max_workers=args.jobs) as ex:
        for res in ex.map(_one_seed, tasks):
            runs.append(res)
            print(f"seed {res['seed']} done in {res['wall_s']:.0f}s "
                  f"({len(res['methods'])} methods)", flush=True)
    out = dict(scale=args.scale, seeds=args.seeds,
               dataset=dict(n_behaviors=np.mean([r["n_behaviors"] for r in runs]),
                            n_records=np.mean([r["n_records"] for r in runs]),
                            n_campaigns=runs[0]["n_campaigns"],
                            n_eff=runs[0]["n_eff"]),
               runs=runs, agg=aggregate(runs), sig=significance(runs),
               wall_s=time.time() - t0)
    path = args.out or os.path.join(C.RESULTS, f"main_{args.scale}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, default=float)
    print(f"wrote {path} ({out['wall_s']:.0f}s)")
    # console summary
    for m in out["agg"]:
        a = out["agg"][m]
        print(f"{m:14s} F1={a['f1']['mean']:.3f}+-{a['f1']['std']:.3f} "
              f"P={a['precision']['mean']:.3f} R={a['recall']['mean']:.3f} "
              f"PR-AUC={a['prauc']['mean']:.3f} "
              f"NDCG={a['ndcg@50']['mean']:.3f} "
              f"nodeF1={a['node_f1']['mean']:.3f} "
              f"edgeF1={a['edge_f1']['mean']:.3f} "
              f"compl={a['completeness']['mean']:.2f}")


if __name__ == "__main__":
    main()
