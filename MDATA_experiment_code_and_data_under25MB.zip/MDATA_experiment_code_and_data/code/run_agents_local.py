"""Local-model counterpart of run_agents.py for the AutoDL 3090 box.

Same 60 cases x 4 modes (naive / grounded / agent / agent-strict) as the
API study, but generation runs on a local Qwen2.5 instruct model through
transformers, so the paper gains a local-vs-API tier comparison and the
tab_llm local study is rerun with the fixed evidence card.

Usage (AutoDL, 3090 24GB):
  pip install -U transformers accelerate bitsandbytes
  export HF_ENDPOINT=https://hf-mirror.com
  python run_agents_local.py --model qwen7b            # bf16 ~15GB
  python run_agents_local.py --model qwen14b --4bit    # ~10GB
  python run_llm.py --cases 30                          # tab_llm rerun (fixed)

Results: results/agents_local_S2_11.json (+ numbers_agents_local.tex)
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np

import config as C
import datagen
import run_agents as RA
import run_agents_strict as RAS

MODELS = {
    "qwen7b": "Qwen/Qwen2.5-7B-Instruct",
    "qwen14b": "Qwen/Qwen2.5-14B-Instruct",
    "qwen3b": "Qwen/Qwen2.5-3B-Instruct",
    "qwen32b": "Qwen/Qwen2.5-32B-Instruct",
}


def load_gen(model_id, four_bit):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    kw = dict(torch_dtype=torch.bfloat16, device_map="auto")
    if four_bit:
        from transformers import BitsAndBytesConfig
        kw["quantization_config"] = BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16)
    model = AutoModelForCausalLM.from_pretrained(model_id, **kw)
    model.eval()
    tok = AutoTokenizer.from_pretrained(model_id)
    return model, tok


class LocalBackend:
    """Same interface as RA.chat (content, usage).

    Uses explicit chat-template generation: transformers pipelines with
    return_text=True on chat input return junk (observed: repo source
    code), so we apply the chat template and generate directly."""

    def __init__(self, gen):
        import torch
        self.model, self.tok = gen
        self.torch = torch

    def chat(self, cfg, model, messages, max_tokens=1200,
             temperature=0.0, retries=3):
        text = self.tok.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tok(text, return_tensors="pt").to(self.model.device)
        with self.torch.no_grad():
            out = self.model.generate(
                **inputs, max_new_tokens=700, do_sample=False,
                pad_token_id=self.tok.eos_token_id)
        resp = self.tok.decode(
            out[0][inputs["input_ids"].shape[1]:],
            skip_special_tokens=True)
        return resp, {}


def main(model_key="qwen7b", four_bit=False, n_cases=60):
    gen = load_gen(MODELS[model_key], four_bit)
    backend = LocalBackend(gen)
    orig_chat = RA.chat
    RA.chat = backend.chat                 # route all modes through local
    cfg = dict(models=[MODELS[model_key]])
    ds = datagen.generate(11, "S2")
    camps = [c for c in ds.campaigns.values()][:n_cases]
    rows = []
    for camp in camps:
        card, intel = RA.case_card(ds, camp)
        headline = (f"Suspicious multi-stage activity from a source "
                    f"host in {','.join(camp.domains)}")
        for mode in ("naive", "grounded", "agent"):
            r = RA.run_case(cfg, MODELS[model_key], mode, card, intel,
                            headline, camp.is_effective)
            if r is None:
                continue
            r.update(cid=camp.cid, mode=mode, model=model_key,
                     is_effective=camp.is_effective,
                     truncation=camp.truncation)
            rows.append(r)
            print(f"{model_key} {camp.cid} {mode:8s} "
                  f"fab={r['fabrication_rate']:.2f} "
                  f"over={r['conclusion_overreach']} "
                  f"vcorr={int(bool(r['verdict_correct']))}", flush=True)
    # agent-strict pass reuses run_agents_strict prompts via local chat
    strict_rows = []
    for camp in camps:
        card, intel = RA.case_card(ds, camp)
        headline = (f"Suspicious multi-stage activity from a source "
                    f"host in {','.join(camp.domains)}")
        draft, _ = RA.chat(cfg, MODELS[model_key], [
            {"role": "system", "content": RA.GROUNDED_SYS},
            {"role": "user", "content":
             f"Evidence:\n{card[:1400]}\nTI: {intel}\nHeadline: {headline}"}])
        if draft is None:
            continue
        audit, _ = RA.chat(cfg, MODELS[model_key], [
            {"role": "system", "content": RA.VERIFIER_SYS},
            {"role": "user", "content":
             f"Evidence:\n{card[:1400]}\nDraft:\n{draft}"}])
        out, _ = RA.chat(cfg, MODELS[model_key], [
            {"role": "system", "content": RAS.REVISE_STRICT_SYS},
            {"role": "user", "content":
             f"Evidence:\n{card[:1400]}\nDraft:\n{draft}\nAudit:\n{audit}"}]) \
            if audit is not None else (draft, {})
        if out is None:
            out = draft
        m = RA.metrics(out, card, intel, camp.is_effective)
        v = RA.parse_verdict(out)
        m.update(verdict=v,
                 verdict_correct=RA.verdict_correct(v, camp.is_effective),
                 report=out[:2000], usage={})
        m.update(cid=camp.cid, mode="agent_strict", model=model_key,
                 is_effective=camp.is_effective,
                 truncation=camp.truncation)
        strict_rows.append(m)
        print(f"{model_key} {camp.cid} strict  "
              f"fab={m['fabrication_rate']:.2f} "
              f"vcorr={int(bool(m['verdict_correct']))}", flush=True)
    rows += strict_rows
    RA.chat = orig_chat
    path = os.path.join(C.RESULTS, f"agents_local_S2_11.json")
    old = []
    if os.path.exists(path):
        old = json.load(open(path, encoding="utf-8"))
        old = [r for r in old if r["model"] != model_key]
    with open(path, "w", encoding="utf-8") as f:
        json.dump(old + rows, f, indent=1, ensure_ascii=False)
    print("saved", path, flush=True)
    for mode in ("naive", "grounded", "agent", "agent_strict"):
        sub = [r for r in rows if r["mode"] == mode]
        if sub:
            print(f"{mode:13s} fab={np.mean([r['fabrication_rate'] for r in sub]):.3f} "
                  f"over={np.mean([r['conclusion_overreach'] for r in sub]):.3f} "
                  f"acc={np.mean([r['verdict_correct'] for r in sub]):.3f} "
                  f"ans={np.mean([r['verdict'] is not None for r in sub]):.2f}",
                  flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="qwen7b",
                    choices=sorted(MODELS))
    ap.add_argument("--fourbit", action="store_true")
    ap.add_argument("--cases", type=int, default=60)
    a = ap.parse_args()
    main(a.model, a.fourbit, a.cases)
