"""Companion analysis for the analyst user study (item 8).

Reads user_study/response_sheet.csv filled by the proctor and compares
conditions A (timeline only) vs B (+ system assessment output):
verdict accuracy, time-to-verdict, confidence calibration, and
 paired significance (Wilcoxon signed-rank on per-case time,
McNemar on correctness).  Ground truth comes from the case-id suffix
(Cxxxx campaign id) resolved against MEGA-Bench seed 11.
"""
from __future__ import annotations

import csv
import os
import re

import numpy as np

import config as C
import datagen
import evaluate

STUDY = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "user_study")
VERDICT_MAP = {"A": "eff", "B": "recon", "C": "attempt", "D": "benign"}


def load_truth():
    ds = datagen.generate(11, "S2")
    truth = {}
    for c in ds.campaigns.values():
        v = {"full": "eff", "recon_only": "recon",
             "exploit_fail": "attempt"}[c.truncation]
        for i in range(20):
            truth[f"CASE_{i:02d}_{c.cid}"] = v
    return truth


def main():
    truth = load_truth()
    rows = list(csv.DictReader(open(os.path.join(STUDY, "response_sheet.csv"),
                                    encoding="utf-8")))
    by_cond = {"A": [], "B": []}
    for r in rows:
        if not r.get("verdict"):
            continue
        cid = r["case_id"]
        if cid not in truth:
            continue
        correct = VERDICT_MAP.get(r["verdict"].strip().upper()) == truth[cid]
        t0, t1 = r.get("start_time", ""), r.get("end_time", "")
        try:
            mins = (float(t1) - float(t0)) / 60.0
        except ValueError:
            mins = float("nan")
        by_cond[r["condition"]].append(
            dict(cid=cid, correct=correct, minutes=mins,
                 confidence=r.get("confidence", ""),
                 analyst=r.get("analyst_id", "")))
    from scipy.stats import wilcoxon
    for cond, rs in by_cond.items():
        if rs:
            print(f"cond {cond}: n={len(rs)} "
                  f"acc={np.mean([r['correct'] for r in rs]):.3f} "
                  f"median_time={np.nanmedian([r['minutes'] for r in rs]):.1f}min")
    # paired time test on common case ids
    common = {r["cid"] for r in by_cond["A"]} & {r["cid"] for r in by_cond["B"]}
    if len(common) >= 6:
        ta = {r["cid"]: r["minutes"] for r in by_cond["A"] if r["cid"] in common}
        tb = {r["cid"]: r["minutes"] for r in by_cond["B"] if r["cid"] in common}
        diffs = [ta[c] - tb[c] for c in common
                 if not np.isnan(ta[c]) and not np.isnan(tb[c])]
        if len(diffs) >= 6:
            stat, p = wilcoxon(diffs)
            print(f"time A-B: mean diff {np.mean(diffs):.1f} min, p={p:.3f}")


if __name__ == "__main__":
    main()
