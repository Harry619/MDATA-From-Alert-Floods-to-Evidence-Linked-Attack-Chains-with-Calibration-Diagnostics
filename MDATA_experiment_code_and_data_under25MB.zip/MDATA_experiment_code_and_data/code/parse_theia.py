"""Enhancement item (5): DARPA TC E3 THEIA external validation.

Parses the public TA1 CDM18 JSON streams (no PIDSMaker/PostgreSQL
dependency), maps provenance subjects/objects into the MDATA ten-tuple
through a pseudo-Dataset, runs the unchanged MDATA pipeline (no
re-tuning), and scores attack-chain reconstruction against the orthrus
per-node ground truth (reapr as sensitivity check).

Usage:
  python parse_theia.py --json <file.json>... --gt <E3-THEIA gt dir> \
      [--gt2 <reapr dir>] --out results/theia_eval.json
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import re
import sys
from collections import defaultdict
from types import SimpleNamespace

import config as C
import pipeline

KEEP = {"EVENT_EXECUTE", "EVENT_CLONE", "EVENT_CONNECT", "EVENT_SENDTO",
        "EVENT_RECVFROM", "EVENT_WRITE", "EVENT_UNLINK"}
DATASET_SPECIFIC = ("/etc/firefox", "drakon", "payload", "firefox")
GENERIC_SUSPICIOUS = ("/tmp", "/dev/shm", "/var/tmp", "./")
SUSPICIOUS = GENERIC_SUSPICIOUS + DATASET_SPECIFIC[:3]
NET_EXTERNAL = re.compile(r"^\d+\.\d+\.\d+\.\d+$")


def shorten(u, table):
    return table.setdefault(u, f"U{len(table):07d}")


def _parse_one(path):
    subjects, files_o, flows = {}, {}, {}
    events = []
    with open(path, encoding="utf-8", errors="ignore") as f:
        for line in f:
            p = line.find('"datum"')
            if p < 0:
                continue
            try:
                obj = json.loads(line)
            except Exception:                          # noqa: BLE001
                continue
            d = obj.get("datum", {})
            for k, v in d.items():
                t = k.split(".")[-1]
                if t == "Subject":
                    subjects[v["uuid"]] = str(
                        v.get("cmdLine") or "")[:120]
                elif t == "FileObject":
                    path_ = v.get("url") or v.get("path") or ""
                    if isinstance(path_, dict):
                        path_ = path_.get("string", "")
                    files_o[v["uuid"]] = str(path_)[:160]
                elif t == "NetFlowObject":
                    ra = v.get("remoteAddress")
                    if isinstance(ra, dict):
                        ra = ra.get("string", "")
                    flows[v["uuid"]] = str(ra or "")
                elif t == "Event" and v.get("type") in KEEP:
                    s = v.get("subject") or {}
                    po = v.get("predicateObject") or {}
                    events.append((
                        int(v.get("timestampNanos", 0)) // 10**9,
                        v["type"],
                        s.get("com.bbn.tc.schema.avro.cdm18.UUID"),
                        po.get("com.bbn.tc.schema.avro.cdm18.UUID")))
    return path, subjects, files_o, flows, events


def parse(files, workers=None):
    from concurrent.futures import ProcessPoolExecutor
    workers = workers or min(14, len(files))
    subjects, files_o, flows = {}, {}, {}
    events = []
    with ProcessPoolExecutor(max_workers=workers) as ex:
        for path, s, fo, fl, ev in ex.map(_parse_one, files):
            print(f"parsed {os.path.basename(path)}: {len(ev)} events, "
                  f"{len(s)} subjects", flush=True)
            subjects.update(s)
            files_o.update(fo)
            flows.update(fl)
            events.extend(ev)
    events.sort(key=lambda e: e[0])
    return subjects, files_o, flows, events, {}


def act_of(etype, subj_cmd, obj_path, flow_addr, generic_adapter=False):
    suspicious = GENERIC_SUSPICIOUS if generic_adapter else SUSPICIOUS
    if etype in ("EVENT_EXECUTE", "EVENT_CLONE"):
        sus = any(s in (subj_cmd or "").lower() for s in suspicious)
        return ("susp_proc", "lateral", 0.85 if sus else 0.5)
    if etype in ("EVENT_CONNECT", "EVENT_SENDTO", "EVENT_RECVFROM"):
        if flow_addr and NET_EXTERNAL.match(flow_addr) and not \
                flow_addr.startswith(("10.", "192.168.", "127.")):
            return ("c2_beacon", "c2", 0.8)
        return ("dns_query", "ops", 0.3)
    if not generic_adapter and "firefox" in (subj_cmd or "").lower():
        return ("exploit_attempt", "exploit", 0.85)
    sus = any(s in (obj_path or "").lower() for s in suspicious)
    if sus:
        return ("archive_staged", "exfil", 0.7)
    return ("config_err", "ops", 0.35)


def build_ds(subjects, files_o, flows, events, generic_adapter=False):
    idmap = {}
    by_sub = defaultdict(list)
    for i, (ts, et, s, po) in enumerate(events):
        if s is None:
            continue
        obj_path = files_o.get(po, "")
        act, stage, sev = act_of(et, subjects.get(s, ""), obj_path,
                                 flows.get(po, ""), generic_adapter)
        by_sub[(s, act)].append((ts, et, po, act, stage, sev))
    behs, records = [], []
    bid_n = 0
    for (s, act), evs in by_sub.items():
        evs.sort()
        # split long-running (subject, act) streams at 1h gaps
        runs, cur = [], [evs[0]]
        for e in evs[1:]:
            if e[0] - cur[-1][0] > 3600:
                runs.append(cur)
                cur = [e]
            else:
                cur.append(e)
        runs.append(cur)
        for evs in runs:
            t0, t1 = evs[0][0], evs[-1][0]
            sev = max(e[5] for e in evs)
            # noise filter: drop low-severity one-hit wonders
            if len(evs) < 2 and sev < 0.5:
                continue
            bid_n += 1
            bid = f"X{bid_n:06d}"
            sub = shorten(s, idmap)
            stage = evs[0][4]
            objs = {shorten(po, idmap) for _, _, po, _, _, _ in evs if po}
            behs.append(SimpleNamespace(
                bid=bid, channel="edr", stage=stage, cid=None, actor=sub,
                kind=act, t0=t0, t1=t1, src=sub,
                dst=next(iter(objs), None),
                asset=next(iter(objs), None), domain="DOM-EXT", extra={},
                records=[dict(channel="edr", ts=ts, bid=bid, src=sub,
                              dst=shorten(po, idmap) if po else None,
                              rule=et, severity=sev, user="-",
                              clock_conf=1.0)
                         for ts, et, po, _, _, _ in evs]))
            records.extend(behs[-1].records)
    assets, zone_of = {}, {}
    for path_u, path in files_o.items():
        a = shorten(path_u, idmap)
        crit = 0.6 if path.startswith(("/usr", "/etc", "/bin")) else 0.35
        assets[a] = SimpleNamespace(aid=a, domain="DOM-EXT", zone="intranet",
                                    role="host", criticality=crit,
                                    exposed=False, vuln=None, deps=[])
        zone_of[a] = "intranet"
    world = SimpleNamespace(assets=assets, zone_of=zone_of, intel={},
                            groups={}, ext_ips={})
    ds = SimpleNamespace(records=records,
                         behaviors=sorted(behs, key=lambda b: b.t0),
                         campaigns={}, world=world, seed=0, scale="THEIA")
    return ds, idmap


def load_gt(gt_dir):
    gt = {}
    for fn in glob.glob(os.path.join(gt_dir, "*.csv")):
        name = os.path.basename(fn)[5:-4]
        uuids = set()
        with open(fn, newline="", encoding="utf-8", errors="ignore") as f:
            for row in csv.reader(f):
                if row:
                    uuids.add(row[0])
        gt[name] = uuids
    return gt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", nargs="+", required=True)
    ap.add_argument("--gt", required=True)
    ap.add_argument("--gt2", default=None)
    ap.add_argument("--ds-cache", default=None)
    ap.add_argument("--generic-adapter", action="store_true",
                    help="remove Firefox/Drakon/payload-specific mapping rules")
    ap.add_argument("--out", default=os.path.join(C.RESULTS,
                                                  "theia_eval.json"))
    a = ap.parse_args()
    if a.generic_adapter and a.ds_cache:
        ap.error("--generic-adapter cannot reuse or create a default --ds-cache")
    import pickle
    if a.ds_cache and os.path.exists(a.ds_cache):
        print("loading ds cache", a.ds_cache, flush=True)
        with open(a.ds_cache, "rb") as f:
            ds, idmap = pickle.load(f)
    else:
        subjects, files_o, flows, events, _ = parse(a.json)
        print(f"events kept {len(events)}; subjects {len(subjects)}; "
              f"files {len(files_o)}; flows {len(flows)}", flush=True)
        ds, idmap = build_ds(subjects, files_o, flows, events,
                             generic_adapter=a.generic_adapter)
        if a.ds_cache:
            with open(a.ds_cache, "wb") as f:
                pickle.dump((ds, idmap), f, protocol=4)
            print("cached ds ->", a.ds_cache, flush=True)
    print(f"behaviours {len(ds.behaviors)}", flush=True)
    res = pipeline.run_mdata(ds)
    print(f"chains {len(res['chains'])}", flush=True)

    gt_sets = load_gt(a.gt)
    # behaviour touches an attack if its subject or any object uuid is GT
    sub_of = {b.bid: b.src for b in ds.behaviors}
    touch = defaultdict(set)                  # bid -> attack names
    inv_idmap = {v: k for k, v in idmap.items()}
    for b in ds.behaviors:
        su = inv_idmap.get(b.src)
        objs = {inv_idmap.get(r.get("dst")) for r in b.records} - {None}
        for name, uu in gt_sets.items():
            if su in uu or (objs & uu):
                touch[b.bid].add(name)

    out = {"n_behaviours": len(ds.behaviors),
           "n_chains": len(res["chains"]),
           "adapter": "generic" if a.generic_adapter else "original",
           "removed_markers": list(DATASET_SPECIFIC) if a.generic_adapter else [],
           "attacks": {}}
    for name, uu in gt_sets.items():
        gt_bids = {b for b, names in touch.items() if name in names}
        pred_bids = set()
        for ch in res["chains_by_bid"]:
            if {b for b in ch} & gt_bids:
                pred_bids.update(ch)
        prec = len(pred_bids & gt_bids) / max(1, len(pred_bids))
        rec = len(pred_bids & gt_bids) / max(1, len(gt_bids))
        f1 = 2 * prec * rec / max(1e-9, prec + rec)
        out["attacks"][name] = dict(
            gt_behaviours=len(gt_bids), pred=len(pred_bids),
            precision=round(prec, 3), recall=round(rec, 3),
            f1=round(f1, 3),
            complete=rec >= 0.5)
        print(f"[{name}] GT-b {len(gt_bids)} pred {len(pred_bids)} "
              f"P={prec:.2f} R={rec:.2f} F1={f1:.2f}", flush=True)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w") as f:
        json.dump(out, f, indent=1)
    print("saved", a.out, flush=True)


if __name__ == "__main__":
    sys.exit(main())
