"""Print compact, reproducible summaries of the THEIA PR diagnostics."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "results"
ATTACKS = (
    "Browser_Extension_Drakon_Dropper",
    "Firefox_Backdoor_Drakon_In_Memory",
)

gnn = json.loads((ROOT / "gnn_theia_pr.json").read_text(encoding="utf-8"))
assert len(gnn["all"]) == 8
print("GraphSAGE: hidden/dropout/lr; fixed F1; AP; target-domain oracle max-F1")
for row in gnn["all"]:
    fields = [f"h={row['hidden']}", f"drop={row['dropout']}", f"lr={row['lr']}"]
    for attack in ATTACKS:
        result = row["attacks"][attack]
        rank = result["ranking"]
        fields.extend((f"F1={result['f1']:.3f}", f"AP={rank['average_precision']:.6f}",
                       f"oracle={rank['oracle_max_f1']:.6f}"))
    print(" ".join(fields))

base = json.loads((ROOT / "baselines_theia_pr.json").read_text(encoding="utf-8"))
print("\nB1/B2: fixed F1; AP; target-domain oracle max-F1 at threshold")
for method, protocols in base["results"].items():
    for protocol, attacks in protocols.items():
        for attack in ATTACKS:
            result = attacks[attack]
            rank = result["ranking"]
            print(method, protocol, attack,
                  f"F1={result['f1']:.3f}",
                  f"AP={rank['average_precision']:.6f}",
                  f"oracle={rank['oracle_max_f1']:.6f}",
                  f"threshold={rank['oracle_threshold']:.6f}")
