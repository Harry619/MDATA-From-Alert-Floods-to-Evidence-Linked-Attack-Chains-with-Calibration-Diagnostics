"""B5-style supervised GraphSAGE baseline on DARPA TC E3 THEIA.

Answers the reviewer question "no learned baseline on the public
dataset": same 2-layer SAGE link-prediction recipe as run_gnn.py
(B5), trained on labelled candidate pairs over the THEIA behaviour
graph (orthrus per-node GT mapped through the parse_theia touch
rule), evaluated with the same behaviour-level P/R/F1 protocol as
theia_eval.json.  Supervised upper-bound comparison for §6.10.

Usage: python run_gnn_theia.py --ds-cache .../theia_ds.pkl \
    --gt .../orthrus/E3-THEIA --out results/gnn_theia.json
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import pickle
from collections import defaultdict

import numpy as np

import config as C
import pipeline as P


def load_gt(gt_dir):
    gt = {}
    for fn in glob.glob(os.path.join(gt_dir, "*.csv")):
        name = os.path.basename(fn)[5:-4]
        uuids = set()
        with open(fn, newline="", encoding="utf-8", errors="ignore") as f:
            for row in csv.reader(f):
                if row:
                    uuids.add(row[0])
        gt[name] = uuids
    return gt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds-cache", required=True)
    ap.add_argument("--gt", required=True)
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--device", default="cuda")
    a = ap.parse_args()

    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch_geometric.nn import SAGEConv
    device = a.device if torch.cuda.is_available() else "cpu"
    torch.manual_seed(a.seed)

    with open(a.ds_cache, "rb") as f:
        ds, idmap = pickle.load(f)
    print(f"behaviours {len(ds.behaviors)}", flush=True)
    events = P.normalize(ds)
    print(f"events {len(events)}", flush=True)

    gt_sets = load_gt(a.gt)
    inv = {v: k for k, v in idmap.items()}
    touch = defaultdict(set)
    for b in ds.behaviors:
        su = inv.get(b.src)
        objs = {inv.get(r.get("dst")) for r in b.records} - {None}
        for name, uu in gt_sets.items():
            if su in uu or (objs & uu):
                touch[b.bid].add(name)

    cands = [p for p, _ in P.gen_candidates(events)]
    print(f"candidates {len(cands)}", flush=True)
    bid_of = [e.bid for e in events]
    is_atk = {b for b, names in touch.items() if names}

    # simple per-behaviour features
    kinds = sorted({e.kind for e in events})
    ki = {k: i for i, k in enumerate(kinds)}
    deg = defaultdict(int)
    for e in events:
        deg[e.src] += 1
        if e.dst:
            deg[e.dst] += 1
    X = torch.tensor(np.stack([
        np.array([ki.get(e.kind, 0),
                  e.severity if e.severity else 0.0,
                  1.0 if e.src and str(e.src).startswith("U") else 0.0,
                  np.log1p(deg[e.src])], dtype=np.float32)
        for e in events]), device=device)

    # labelled split: 70% of attack behaviours + matched negatives train
    rng = np.random.default_rng(a.seed)
    atk_ev = [i for i, b in enumerate(bid_of) if b in is_atk]
    rng.shuffle(atk_ev)
    n_tr = int(0.7 * len(atk_ev))
    train_bids = {bid_of[i] for i in atk_ev[:n_tr]}

    def ok_train(i, j):
        return bid_of[i] in train_bids and bid_of[j] in train_bids

    pos = [(i, j) for (i, j) in cands
           if ok_train(i, j) and bid_of[i] in is_atk and bid_of[j] in is_atk]
    cand_set = set(cands)
    # negatives: random pairs from the FULL behaviour pool (noise
    # included), excluding candidates and pairs where both endpoints
    # are GT-attack; sampling only among attack behaviours (the first
    # version) starved the model of normal-behaviour signal
    neg = []
    guard = 0
    atk_set = set(atk_ev)
    while len(neg) < len(pos) and guard < 50 * len(pos) + 1000:
        guard += 1
        i, j = rng.integers(len(events), size=2)
        i, j = int(i), int(j)
        if i == j or (i, j) in cand_set or (j, i) in cand_set:
            continue
        if i in atk_set and j in atk_set:
            continue
        neg.append((i, j))
    print(f"pos {len(pos)} neg {len(neg)}", flush=True)
    ei = torch.tensor([p[0] for p in pos + neg], device=device)
    ej = torch.tensor([p[1] for p in pos + neg], device=device)
    y = torch.tensor([1.0] * len(pos) + [0.0] * len(neg), device=device)
    edge_index = torch.stack([ei, ej], dim=0)

    class SAGE(nn.Module):
        def __init__(self, din, dh):
            super().__init__()
            self.c1 = SAGEConv(din, dh)
            self.c2 = SAGEConv(dh, dh)

        def forward(self, x, ei_):
            return self.c2(F.relu(self.c1(x, ei_)), ei_)

    results = []
    for dh in (64, 128):
        for drop in (0.0, 0.3):
            for lr in (1e-3, 5e-4):
                model = SAGE(X.shape[1], dh).to(device)
                opt = torch.optim.Adam(model.parameters(), lr=lr)
                for ep in range(30):
                    model.train()
                    z = model(X, edge_index)
                    F.dropout(z, drop, training=True)
                    sc = (z[ei] * z[ej]).sum(-1)
                    loss = F.binary_cross_entropy_with_logits(sc, y)
                    opt.zero_grad(); loss.backward(); opt.step()
                model.eval()
                scores = {}
                with torch.no_grad():
                    z = model(X, edge_index)
                    # chunked scoring: THEIA yields O(10^8) candidate
                    # pairs; scoring them at once needs >100GB VRAM
                    CH = 500_000
                    for s0 in range(0, len(cands), CH):
                        chunk = cands[s0:s0 + CH]
                        ci = torch.tensor([i for i, _ in chunk],
                                          device=device)
                        cj = torch.tensor([j for _, j in chunk],
                                          device=device)
                        sc_chunk = torch.sigmoid(
                            (z[ci] * z[cj]).sum(-1)).cpu().numpy()
                        for (i, j), sv in zip(chunk, sc_chunk):
                            for b in (bid_of[i], bid_of[j]):
                                scores[b] = max(scores.get(b, 0.0),
                                                float(sv))
                # behaviour-level P/R/F1 at the natural 0.5 operating
                # point over ALL behaviours, same GT as theia_eval.json
                pred = {b for b, s in scores.items() if s >= 0.5}
                res = dict(hidden=dh, dropout=drop, lr=lr,
                           params=sum(p.numl() if False else
                                      p.numel() for p in model.parameters()))
                per_attack = {}
                for name in gt_sets:
                    gt_b = {b for b, ns in touch.items() if name in ns}
                    inter = len(pred & gt_b)
                    prec = inter / max(1, len(pred))
                    rec = inter / max(1, len(gt_b))
                    f1 = 2 * prec * rec / max(1e-9, prec + rec)
                    per_attack[name] = dict(precision=round(prec, 3),
                                            recall=round(rec, 3),
                                            f1=round(f1, 3))
                res["attacks"] = per_attack
                results.append(res)
                print(f"h={dh} drop={drop} lr={lr}: " +
                      " ".join(f"{k[:12]} F1={v['f1']}"
                               for k, v in per_attack.items()), flush=True)
    best = max(results, key=lambda r: np.mean(
        [v["f1"] for v in r["attacks"].values()]))
    out = dict(all=results, best=best, device=device,
               protocol="supervised SAGE link prediction; "
                        "behaviour score=max incident edge; P/R/F1 at "
                        "sigmoid 0.5 vs orthrus touch GT (same as "
                        "theia_eval.json)")
    os.makedirs(C.RESULTS, exist_ok=True)
    path = os.path.join(C.RESULTS, "gnn_theia.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, default=float)
    print("saved", path, flush=True)


if __name__ == "__main__":
    main()
