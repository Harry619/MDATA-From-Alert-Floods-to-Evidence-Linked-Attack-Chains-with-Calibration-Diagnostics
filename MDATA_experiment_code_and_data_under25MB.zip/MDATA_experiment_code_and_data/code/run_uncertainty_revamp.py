"""Enhancement items U-revamp + hybrid alpha of ENHANCEMENT_ROADMAP.md.

U-revamp: the original kappa*U interval is vacuous (coverage 0.1%) because
U collapses to ~0.  This script rebuilds the threat score with an extended
uncertainty U2 that aggregates four observable sources (field missingness,
clock unreliability, stale/conflicting intelligence, evidence sparsity),
then empirically calibrates kappa on the calibration split to reach a
target bin-rate coverage of 80%, and reports test-split coverage, interval
width and risk-band validity before/after.

Hybrid alpha: shrinkage between expert and behaviour-learned threat
weights, tau chosen on the calibration split, evaluated on test.

Outputs: results/uncertainty_S2.json, manuscript/numbers_uncertainty.tex
"""
from __future__ import annotations

import json
import math
import os
from collections import defaultdict

import numpy as np

import config as C
import datagen
import evaluate
import pipeline
from run_calibration_analysis import N_BINS, reliability
from run_learned_weights import TDIMS, behaviour_dims, train_alpha

U2_W = dict(miss=0.35, clock=0.20, intel=0.25, sparse=0.20)
KAPPA_GRID = [round(0.05 * k, 2) for k in range(1, 31)]
TAU_GRID = [0.0, 0.25, 0.5, 0.75, 1.0]
TARGET_COV = 0.80


def threat_v2(ds, events, clusters, chains, weights, kappa):
    """threat_scores with extended uncertainty U2 (dims identical)."""
    aw = dict(weights)
    beh = {b.bid: b for b in ds.behaviors}
    chain_members = {i for p in chains for i in p}

    def dims_for(eids):
        evs = [events[i] for i in eids]
        stages = {e.stage for e in evs}
        acts = {e.act for e in evs}
        assets = {e.obj for e in evs if e.obj and e.obj in ds.world.assets}
        authorized = any(e.extra.get("authorized") for e in evs)
        post = bool(stages & {"c2", "lateral", "priv_esc", "exfil"})
        if authorized:
            M = 0.15
        elif "exploit" in acts and post:
            M = 0.95
        elif "exploit" in acts:
            M = 0.55
        elif post:
            M = 0.85
        else:
            M = max((e.severity for e in evs), default=0.2) * 0.5
        ext = any(e.src and not str(e.src).startswith("A") and "." in str(e.src)
                  and e.src not in ds.world.assets for e in evs)
        internal = any(e.zone in ("intranet", "cloud") for e in evs)
        A = 1.0 if (ext and internal) else (0.7 if internal else (0.6 if ext else 0.3))
        I = max((ds.world.assets[a].criticality for a in assets), default=0.2)
        Cc = 0.2
        best = 0.0
        for e in evs:
            for ent in (e.src, e.extra.get("domain")):
                if not ent:
                    continue
                rec = ds.world.intel.get(ent)
                if rec and rec["verdict"] == "malicious" and rec["expiry"] >= (e.mid or 0):
                    best = max(best, rec["confidence"] * rec["src_w"])
        Cc = best if best > 0 else 0.2
        t_last = max((e.t1 for e in evs), default=0)
        F = math.exp(-max(0, C.OP_SECONDS - t_last) / (72 * 3600))
        chs = len({e.channel for e in evs})
        provenance = all(e.records for e in evs)
        miss = 1 - sum(e.missing for e in evs) / max(1, len(evs))
        E = min(1.0, chs / 3.0) * (0.5 + 0.5 * miss) * (1.0 if provenance else 0.5)
        d = dict(M=M, A=A, I=I, C=Cc, F=F, E=E)
        # ---- extended uncertainty U2 -----------------------------------
        miss_u = sum(e.missing for e in evs) / max(1, len(evs))
        clock_u = 1 - min(e.clock_conf for e in evs)
        intel_bad = 0
        for e in evs:
            for ent in (e.src, e.extra.get("domain")):
                if not ent:
                    continue
                rec = ds.world.intel.get(ent)
                if rec and rec["expiry"] < (e.mid or 0):
                    intel_bad += 1
                    break
        intel_u = intel_bad / max(1, len(evs))
        sparse_u = 1 - min(1.0, chs / 3.0)
        U2 = min(1.0, U2_W["miss"] * miss_u + U2_W["clock"] * clock_u +
                 U2_W["intel"] * intel_u + U2_W["sparse"] * sparse_u)
        R = sum(aw[k] * v for k, v in d.items())
        return R, U2, d

    scores, meta = defaultdict(float), {}
    for cl in clusters:
        R, U2, d = dims_for(cl)
        if any(i in chain_members for i in cl):
            R = min(1.0, R + 0.05)
        for i in cl:
            b = events[i].bid
            if R > scores[b]:
                scores[b] = R
                meta[b] = (R, U2, d)
    for i, e in enumerate(events):
        if e.bid not in scores:
            R, U2, d = dims_for([i])
            scores[e.bid] = R
            meta[e.bid] = (R, U2, d)
    return dict(scores=scores, meta=meta)


def bin_rate_lookup(scores, labels):
    edges = np.linspace(0, 1, N_BINS + 1)
    idx = np.clip(np.digitize(scores, edges[1:-1]), 0, N_BINS - 1)
    rate = {}
    for b in range(N_BINS):
        m = idx == b
        if m.sum():
            rate[b] = float(labels[m].mean())
    return idx, rate


def main(scale="S2"):
    per_seed = []
    for seed in C.MASTER_SEEDS:
        ds = datagen.generate(seed, scale)
        res = pipeline.run_mdata(ds)
        ctx = evaluate.EvalContext(ds)
        bids = ctx.bids
        lb = ctx.lb.astype(float)
        bid2cid = {bid: cid for cid, c in ds.campaigns.items()
                   for bid, _ in c.behaviors}
        fit_mask = np.array([
            (b in bid2cid and bid2cid[b] in ctx.train_c)
            or (b not in bid2cid and b in ctx.train_b) for b in bids])
        te = ctx.test_mask
        a0 = np.array([C.THREAT_WEIGHTS[k] for k in TDIMS])

        # baseline (expert alpha, old U, kappa=0.2) coverage on test
        R0 = np.array([res["scores"].get(b, 0.0) for b in bids])
        U0 = np.array([res["meta"].get(b, (0, 0, None))[1] for b in bids])

        # v2 with expert alpha: extended U
        v2 = threat_v2(ds, res["events"], res["clusters"], res["chains"],
                       {k: float(v) for k, v in zip(TDIMS, a0)}, kappa=None)
        R2 = np.array([v2["scores"].get(b, 0.0) for b in bids])
        U2 = np.array([v2["meta"].get(b, (0, 0, None))[1] for b in bids])

        # kappa calibration on the fit split (bin-rate coverage target)
        idx_f, rate_f = bin_rate_lookup(R2[fit_mask], lb[fit_mask])
        truth_f = np.array([rate_f[i] for i in idx_f])
        kappa_star = None
        for kap in KAPPA_GRID:
            lo = np.maximum(0, R2[fit_mask] - kap * U2[fit_mask])
            hi = np.minimum(1, R2[fit_mask] + kap * U2[fit_mask])
            cov = float(np.mean((truth_f >= lo) & (truth_f <= hi)))
            if cov >= TARGET_COV:
                kappa_star = kap
                break
        if kappa_star is None:
            kappa_star = KAPPA_GRID[-1]

        # test coverage old vs new
        idx_t, rate_t = bin_rate_lookup(R2[te], lb[te])
        truth_t = np.array([rate_t[i] for i in idx_t])

        def cov_of(R, U, kap):
            lo = np.maximum(0, R[te] - kap * U[te])
            hi = np.minimum(1, R[te] + kap * U[te])
            return float(np.mean((truth_t >= lo) & (truth_t <= hi)))

        cov_old = cov_of(R0, U0, C.KAPPA)
        cov_new = cov_of(R2, U2, kappa_star)
        width_old = float(np.mean(2 * C.KAPPA * U0[te]))
        width_new = float(np.mean(2 * kappa_star * U2[te]))
        lo_n = np.maximum(0, R2 - kappa_star * U2)
        band = np.where(lo_n >= C.T_HIGH, 2, np.where(lo_n >= C.T_MED, 1, 0))
        band_hi_rate = float(lb[te & (band == 2)].mean()
                             if (te & (band == 2)).sum() else None)

        # hybrid alpha: tau chosen on fit split by F1, evaluated on test
        X = behaviour_dims(ds, res, bids)
        a_le = train_alpha(X, lb, fit_mask, a0)
        fit_bids = [b for b, m in zip(bids, fit_mask) if m]
        best_tau, best_f1 = 0.0, -1.0
        for tau in TAU_GRID:
            a_t = (1 - tau) * a0 + tau * a_le
            v = threat_v2(ds, res["events"], res["clusters"], res["chains"],
                          {k: float(x) for k, x in zip(TDIMS, a_t)}, kappa=None)
            thr = evaluate.calibrate(v["scores"], ctx.labels, fit_bids)
            sc = np.array([v["scores"].get(b, 0.0) for b in bids])
            det = sc >= thr
            m = fit_mask
            tp = np.sum(det[m] & (lb[m] == 1))
            fp = np.sum(det[m] & (lb[m] == 0))
            fn = np.sum(~det[m] & (lb[m] == 1))
            p = tp / max(1, tp + fp)
            r = tp / max(1, tp + fn)
            f1 = 2 * p * r / max(1e-9, p + r)
            if f1 > best_f1:
                best_f1, best_tau = f1, tau
        a_h = (1 - best_tau) * a0 + best_tau * a_le
        vh = threat_v2(ds, res["events"], res["clusters"], res["chains"],
                       {k: float(x) for k, x in zip(TDIMS, a_h)}, kappa=None)
        m_h = ctx.evaluate(dict(scores=vh["scores"],
                                chains_by_bid=res["chains_by_bid"]))
        Rh = np.array([vh["scores"].get(b, 0.0) for b in bids])
        _, ece_h, _ = reliability(Rh[te], lb[te])
        m_e = ctx.evaluate(res)
        _, ece_e, _ = reliability(R0[te], lb[te])

        per_seed.append(dict(
            seed=seed, kappa_star=kappa_star, cov_old=cov_old, cov_new=cov_new,
            width_old=width_old, width_new=width_new,
            band_hi_rate=band_hi_rate,
            mean_U_old=float(U0[te].mean()), mean_U2=float(U2[te].mean()),
            tau_star=best_tau, hybrid_alpha=dict(zip(TDIMS, a_h.round(4).tolist())),
            f1_expert=float(m_e["f1"]), f1_hybrid=float(m_h["f1"]),
            prauc_expert=float(m_e["prauc"]), prauc_hybrid=float(m_h["prauc"]),
            ece_expert=float(ece_e), ece_hybrid=float(ece_h)))
        print(f"seed {seed}: kappa* {kappa_star} cov {cov_old:.3f}->"
              f"{cov_new:.3f} width {width_old:.3f}->{width_new:.3f}; "
              f"tau* {best_tau}; F1 {m_e['f1']:.3f}->{m_h['f1']:.3f}; "
              f"PRAUC {m_e['prauc']:.3f}->{m_h['prauc']:.3f}", flush=True)

    keys = [k for k in per_seed[0] if isinstance(per_seed[0][k], float)]
    agg = {k: dict(mean=float(np.mean([s[k] for s in per_seed])),
                   std=float(np.std([s[k] for s in per_seed]))) for k in keys}
    out = dict(scale=scale, u2_weights=U2_W, target_cov=TARGET_COV,
               agg=agg, per_seed=per_seed)
    p = os.path.join(C.RESULTS, f"uncertainty_{scale}.json")
    with open(p, "w") as f:
        json.dump(out, f, indent=1)
    print("saved", p, flush=True)
    lines = [
        f"\\newcommand\\nUKappa{{{agg['kappa_star']['mean']:.2f}}}",
        f"\\newcommand\\nUCovOld{{{100*agg['cov_old']['mean']:.1f}}}",
        f"\\newcommand\\nUCovNew{{{100*agg['cov_new']['mean']:.1f}}}",
        f"\\newcommand\\nUWidthOld{{{agg['width_old']['mean']:.3f}}}",
        f"\\newcommand\\nUWidthNew{{{agg['width_new']['mean']:.3f}}}",
        f"\\newcommand\\nUTau{{{agg['tau_star']['mean']:.2f}}}",
        f"\\newcommand\\nUHybridF{{{100*agg['f1_hybrid']['mean']:.1f}}}",
        f"\\newcommand\\nUHybridPRAUC{{{100*agg['prauc_hybrid']['mean']:.1f}}}",
        f"\\newcommand\\nUExpertF{{{100*agg['f1_expert']['mean']:.1f}}}",
        f"\\newcommand\\nUExpertPRAUC{{{100*agg['prauc_expert']['mean']:.1f}}}",
    ]
    p2 = os.path.join(C.BASE, "manuscript", "numbers_uncertainty.tex")
    with open(p2, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("saved", p2, flush=True)


if __name__ == "__main__":
    main("S2")
