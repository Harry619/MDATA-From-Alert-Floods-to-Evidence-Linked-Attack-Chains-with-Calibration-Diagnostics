"""Larger-scale engineering stress tests, with incremental result saving.

S4 targets roughly one million normalised events and runs the full reference
pipeline plus streaming simulation. S10 targets roughly ten million events and
runs only the streaming simulation to avoid an expensive duplicate full batch
run. These are single-seed reference measurements, not optimised deployment
claims.
"""
from __future__ import annotations

import argparse
import json
import os
import time

import config as C
import datagen
from run_engineering import scale_run, streaming_run

C.SCALES["S4"] = dict(n_ext=32_000, n_campaigns=480, noise_factor=8.0)
C.SCALES["S10"] = dict(n_ext=100_000, n_campaigns=1_500, noise_factor=25.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scales", nargs="*", default=["S4", "S10"])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    results = []
    for scale in args.scales:
        start = time.perf_counter()
        if scale == "S10":
            ds = datagen.generate(11, scale)
            stream = streaming_run(ds)
            result = dict(scale=scale, seed=11, mode="stream-only",
                          n_behaviors=len(ds.behaviors),
                          n_records=len(ds.records), stream=stream)
        else:
            result = scale_run(scale, seed=11)
            result["mode"] = "full-plus-stream"
        result["wall_s"] = time.perf_counter() - start
        results.append(result)
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as handle:
            json.dump(results, handle, indent=1, default=float)
        print(scale, result["mode"], result["stream"], flush=True)
        print("incrementally saved", args.out, flush=True)


if __name__ == "__main__":
    main()
