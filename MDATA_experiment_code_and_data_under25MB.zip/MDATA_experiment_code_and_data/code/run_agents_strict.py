"""Agent-mode rerun with a template-enforcing revision prompt.

The first agent run showed that free-form revision drops the VERDICT
field (answered 0.00-0.53 depending on model), collapsing verdict
accuracy even though fabrication stays at zero.  This rerun keeps the
same analyst/verifier agents but forces the revision to start with the
VERDICT line, separating "the verify loop hurts" from "the revision
prompt was under-specified".

Merges results into results/agents_S2_11.json (mode 'agent_strict'),
regenerates the summary and numbers_agents.tex.
"""
from __future__ import annotations

import json
import os

import numpy as np

import config as C
import datagen
import run_agents as RA

REVISE_STRICT_SYS = (
    "You are a SOC analyst assistant. Revise the draft report using "
    "ONLY the evidence below. Remove or correct every item the auditor "
    "flagged as unsupported; never introduce any new indicator. Your "
    "reply MUST start with the line 'VERDICT: EFFECTIVE_ATTACK' or "
    "'VERDICT: RECON_TO_VERIFY' or 'VERDICT: ATTEMPT_UNCONFIRMED' "
    "(copy the draft verdict unless the evidence contradicts it), then "
    "continue with SUMMARY: ... | STAGE: ... | AFFECTED: ... | "
    "CONFIDENCE: ... | RECOMMENDED_ACTION: ...")


def run_strict(scale="S2", seed=11, n_cases=60):
    cfg = RA.load_cfg()
    ds = datagen.generate(seed, scale)
    camps = [c for c in ds.campaigns.values()][:n_cases]
    rows = []
    for model in cfg["models"]:
        for camp in camps:
            card, intel = RA.case_card(ds, camp)
            headline = (f"Suspicious multi-stage activity from a source "
                        f"host in {','.join(camp.domains)}")
            draft, _ = RA.chat(cfg, model, [
                {"role": "system", "content": RA.GROUNDED_SYS},
                {"role": "user", "content":
                 f"Evidence:\n{card[:1400]}\nTI: {intel}\nHeadline: {headline}"}])
            if draft is None:
                continue
            audit, _ = RA.chat(cfg, model, [
                {"role": "system", "content": RA.VERIFIER_SYS},
                {"role": "user", "content":
                 f"Evidence:\n{card[:1400]}\nDraft:\n{draft}"}])
            out, _ = RA.chat(cfg, model, [
                {"role": "system", "content": REVISE_STRICT_SYS},
                {"role": "user", "content":
                 f"Evidence:\n{card[:1400]}\nDraft:\n{draft}\nAudit:\n{audit}"}]) \
                if audit is not None else (draft, {})
            if out is None:
                out = draft
            m = RA.metrics(out, card, intel, camp.is_effective)
            v = RA.parse_verdict(out)
            m.update(verdict=v,
                     verdict_correct=RA.verdict_correct(v, camp.is_effective),
                     report=out[:2000], usage={})
            m.update(cid=camp.cid, mode="agent_strict", model=model,
                     is_effective=camp.is_effective,
                     truncation=camp.truncation)
            rows.append(m)
            print(f"{model} {camp.cid} strict fab={m['fabrication_rate']:.2f} "
                  f"over={m['conclusion_overreach']} "
                  f"vcorr={int(bool(m['verdict_correct']))} "
                  f"v={v}", flush=True)
    # merge + re-summary
    base = os.path.join(C.RESULTS, f"agents_{scale}_{seed}.json")
    old = json.load(open(base, encoding="utf-8"))
    old = [r for r in old if r["mode"] != "agent_strict"]
    merged = old + rows
    with open(base, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=1, ensure_ascii=False)
    RA_resummary(merged, scale, seed, cfg)
    return merged


def RA_resummary(rows, scale, seed, cfg):
    def agg(sel):
        if not sel:
            return {}
        out = {k: float(np.mean([r[k] for r in sel])) for k in
               ("fabrication_rate", "conclusion_overreach",
                "evidence_coverage", "template_compliance")}
        out["verdict_accuracy"] = float(
            np.mean([r["verdict_correct"] for r in sel]))
        out["verdict_answered"] = float(
            np.mean([r["verdict"] is not None for r in sel]))
        return out

    summary = {"per_model": {}, "per_mode": {}}
    modes = ("naive", "grounded", "agent", "agent_strict")
    for mo in sorted({r["model"] for r in rows}):
        for mode in modes:
            sel = [r for r in rows if r["model"] == mo and r["mode"] == mode]
            if sel:
                summary["per_model"][f"{mo}|{mode}"] = agg(sel)
    for mode in modes:
        sel = [r for r in rows if r["mode"] == mode]
        if sel:
            summary["per_mode"][mode] = agg(sel)
    with open(os.path.join(C.RESULTS, f"agents_{scale}_{seed}_summary.json"),
              "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=1)
    pm = summary["per_mode"]
    pp = summary["per_model"]

    def M(k, f):
        return pp.get(k, {}).get(f, float("nan"))

    lines = [
        f"\\newcommand\\nAgNaiveFab{{{100*pm['naive']['fabrication_rate']:.1f}}}",
        f"\\newcommand\\nAgGroundFab{{{100*pm['grounded']['fabrication_rate']:.1f}}}",
        f"\\newcommand\\nAgAgentFab{{{100*pm['agent']['fabrication_rate']:.1f}}}",
        f"\\newcommand\\nAgNaiveOver{{{100*pm['naive']['conclusion_overreach']:.1f}}}",
        f"\\newcommand\\nAgGroundOver{{{100*pm['grounded']['conclusion_overreach']:.1f}}}",
        f"\\newcommand\\nAgAgentOver{{{100*pm['agent']['conclusion_overreach']:.1f}}}",
        f"\\newcommand\\nAgDSProNaiveFab{{{100*M('DeepSeek-V4-Pro-0813|naive','fabrication_rate'):.1f}}}",
        f"\\newcommand\\nAgDSProNaiveOver{{{100*M('DeepSeek-V4-Pro-0813|naive','conclusion_overreach'):.1f}}}",
        f"\\newcommand\\nAgDSProGroundAcc{{{100*M('DeepSeek-V4-Pro-0813|grounded','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgGPTGroundAcc{{{100*M('GPT-5.2|grounded','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgFlashGroundAcc{{{100*M('DeepSeek-V4.1-Flash|grounded','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgDSProAgentAcc{{{100*M('DeepSeek-V4-Pro-0813|agent','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgGPTAgentAcc{{{100*M('GPT-5.2|agent','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgFlashAgentAcc{{{100*M('DeepSeek-V4.1-Flash|agent','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgAgentAnswered{{{100*pm['agent']['verdict_answered']:.1f}}}",
        f"\\newcommand\\nAgFlashAgentAnswered{{{100*M('DeepSeek-V4.1-Flash|agent','verdict_answered'):.1f}}}",
        f"\\newcommand\\nAgStrictFab{{{100*pm['agent_strict']['fabrication_rate']:.1f}}}",
        f"\\newcommand\\nAgStrictOver{{{100*pm['agent_strict']['conclusion_overreach']:.1f}}}",
        f"\\newcommand\\nAgStrictAcc{{{100*pm['agent_strict']['verdict_accuracy']:.1f}}}",
        f"\\newcommand\\nAgStrictAnswered{{{100*pm['agent_strict']['verdict_answered']:.1f}}}",
        f"\\newcommand\\nAgGPTStrictAcc{{{100*M('GPT-5.2|agent_strict','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgDSProStrictAcc{{{100*M('DeepSeek-V4-Pro-0813|agent_strict','verdict_accuracy'):.1f}}}",
        f"\\newcommand\\nAgFlashStrictAcc{{{100*M('DeepSeek-V4.1-Flash|agent_strict','verdict_accuracy'):.1f}}}",
    ]
    with open(os.path.join(C.BASE, "manuscript", "numbers_agents.tex"),
              "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("summary + macros regenerated", flush=True)


if __name__ == "__main__":
    run_strict()
