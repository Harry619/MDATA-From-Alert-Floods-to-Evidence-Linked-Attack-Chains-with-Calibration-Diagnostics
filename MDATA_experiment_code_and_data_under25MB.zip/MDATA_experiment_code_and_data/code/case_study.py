"""Case study extraction: one cross-domain effective campaign with full
evidence chain and score contributions; one recon-only campaign output as
"high-risk reconnaissance -- to be verified"; one authorised pentest
excused by the ticket channel.  Writes results/case_study.json.
"""
from __future__ import annotations

import json
import os

import config as C
import datagen
import baselines
import evaluate
import pipeline as P


def main(seed=11, scale="S2"):
    ds = datagen.generate(seed, scale)
    res = baselines.run_mdata_full(ds)
    labels, eff_c = evaluate.labels_of(ds)
    thr = evaluate.calibrate(res["scores"], labels,
                             {b for b in evaluate.make_split(ds)[2]})
    behs = {b.bid: b for b in ds.behaviors}
    events = res["events"]
    ev_by_bid = {}
    for e in events:
        ev_by_bid.setdefault(e.bid, []).append(e)

    def chain_for(cid):
        camp = ds.campaigns[cid]
        want = {bid for bid, _ in camp.behaviors}
        best, best_ov = None, 0
        for ch in res["chains_by_bid"]:
            ov = len(set(ch) & want)
            if ov > best_ov:
                best, best_ov = ch, ov
        return best, best_ov / max(1, len(want))

    out = dict(seed=seed, scale=scale, threshold=thr, cases=[])

    # ---- case 1: cross-domain effective campaign -----------------------
    scored = []
    for cand in ds.campaigns.values():
        if not cand.is_effective:
            continue
        ch_, cov_ = chain_for(cand.cid)
        detected = max((res["scores"].get(b, 0.0)
                        for b, _ in cand.behaviors), default=0.0) >= thr
        scored.append((cov_, len(cand.domains) > 1, detected,
                       len(cand.behaviors), cand, ch_))
    # prefer a DETECTED well-recovered cross-domain case, then any detected
    # well-recovered campaign, then the best-recovered overall
    for pred in (lambda s: s[1] and s[2] and s[0] >= 0.5,
                 lambda s: s[2] and s[0] >= 0.5,
                 lambda s: True):
        pool = [s for s in scored if pred(s)]
        if pool:
            break
    _, is_cross, _, _, c1, ch = max(pool, key=lambda s: (s[0], s[3]))
    cov = len(set(ch or []) & {b for b, _ in c1.behaviors}) / max(
        1, len(c1.behaviors))
    edges = []
    scorer = res["scorer"]
    for a, b in zip(ch, ch[1:]):
        ea = ev_by_bid[a][0]
        eb = ev_by_bid[b][0]
        edges.append(dict(a=a, b=b,
                          **scorer.explain(ea, eb, C.OP_SECONDS)))
    meta = res["meta"].get(ch[0]) if ch else None
    out["cases"].append(dict(
        type="effective_case", cross_domain=is_cross,
        cid=c1.cid, group=c1.group,
        domains=c1.domains, coverage=round(cov, 2),
        gt=[dict(bid=bid, stage=st, kind=behs[bid].kind, t0=behs[bid].t0,
                 asset=behs[bid].asset, domain=behs[bid].domain,
                 channels=sorted({r["channel"] for r in behs[bid].records}))
            for bid, st in c1.behaviors],
        pred_chain=[dict(bid=b, stage=behs[b].stage, kind=behs[b].kind,
                         t=behs[b].t0, score=round(res["scores"].get(b, 0), 3))
                    for b in (ch or [])],
        edge_explanations=edges,
        threat=dict(R=round(meta[0], 3) if meta else None,
                    U=round(meta[1], 3) if meta else None,
                    dims=meta[2] if meta else None,
                    interval=[round(max(0, meta[0] - C.KAPPA * meta[1]), 3),
                              round(min(1, meta[0] + C.KAPPA * meta[1]), 3)]
                    if meta else None,
                    high_risk=bool(meta and meta[0] - C.KAPPA * meta[1] >= C.T_HIGH))))

    # ---- case 2: recon-only -> verification -----------------------------
    rec_only = [c for c in ds.campaigns.values()
                if c.truncation == "recon_only"]
    c2 = max(rec_only, key=lambda c: max(res["scores"].get(b, 0)
                                         for b, _ in c.behaviors))
    s2 = max(res["scores"].get(b, 0) for b, _ in c2.behaviors)
    out["cases"].append(dict(
        type="recon_only_to_verify", cid=c2.cid, group=c2.group,
        domains=c2.domains,
        behaviors=[dict(bid=bid, stage=st, kind=behs[bid].kind,
                        score=round(res["scores"].get(bid, 0), 3))
                   for bid, st in c2.behaviors],
        max_score=round(s2, 3),
        detected_as_effective=bool(s2 >= thr),
        verdict="high-risk reconnaissance, to be verified"
        if s2 < thr else "unexpectedly above threshold"))

    # ---- case 3: authorised pentest excused ----------------------------
    pt = [b for b in ds.behaviors if b.kind == "auth_ticket"]
    if pt:
        bid = pt[0].bid
        out["cases"].append(dict(
            type="authorised_pentest", bid=bid, src=pt[0].src,
            score=round(res["scores"].get(bid, 0), 3),
            excused=res["scores"].get(bid, 0) < thr,
            related=[dict(bid=b.bid, kind=b.kind,
                          score=round(res["scores"].get(b.bid, 0), 3))
                     for b in ds.behaviors if b.src == pt[0].src
                     and b.kind != "auth_ticket"]))

    with open(os.path.join(C.RESULTS, "case_study.json"), "w",
              encoding="utf-8") as f:
        json.dump(out, f, indent=1, default=float)
    print("wrote case_study.json")
    for case in out["cases"]:
        print(case["type"], "->", {k: case[k] for k in case
                                    if k in ("coverage", "verdict",
                                             "max_score", "excused")})


if __name__ == "__main__":
    main()
