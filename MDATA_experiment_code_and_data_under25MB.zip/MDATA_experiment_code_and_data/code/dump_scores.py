"""Dump per-behaviour scores + labels at S2 (seed 11) for the PR figure."""
import os
import numpy as np

import config as C
import datagen
import baselines
import evaluate


def main(seed=11, scale="S2"):
    ds = datagen.generate(seed, scale)
    ctx = evaluate.EvalContext(ds)
    out = {}
    for name, fn in [("B1", baselines.run_b1), ("B2", baselines.run_b2),
                     ("B3", baselines.run_b3), ("B4", baselines.run_b4),
                     ("MDATA", baselines.run_mdata_full)]:
        res = fn(ds)
        m = ctx.evaluate(res)
        out[f"{name}_sc"] = m["_sc"][ctx.test_mask]
        out[f"{name}_lb"] = ctx.lb[ctx.test_mask]
        print(name, "dumped", flush=True)
    np.savez_compressed(os.path.join(C.RESULTS, f"scores_{scale}.npz"), **out)


if __name__ == "__main__":
    main()
