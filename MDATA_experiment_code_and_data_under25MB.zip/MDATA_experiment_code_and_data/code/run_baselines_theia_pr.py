"""Threshold sensitivity and PR curves for score-only THEIA B1/B2.

The original score>=0.5 results are retained alongside threshold-free average
precision and target-domain oracle max-F1 diagnostics. B3 is chain-based and
is therefore outside this score-threshold experiment.
"""
from __future__ import annotations

import argparse
import json
import os
import pickle

import baselines as B
import config as C
from ranking_eval import ranking_metrics
from run_baselines_theia import evaluate, touch_map
from run_gnn_theia import load_gt


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds-cache", required=True)
    ap.add_argument("--gt-orthrus", required=True)
    ap.add_argument("--gt-reapr", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    with open(args.ds_cache, "rb") as handle:
        ds, idmap = pickle.load(handle)
    print(f"behaviours {len(ds.behaviors)}", flush=True)
    all_bids = [b.bid for b in ds.behaviors]
    final = {}
    for method, fn in (("B1", B.run_b1), ("B2", B.run_b2)):
        print(f"running {method}", flush=True)
        result = fn(ds)
        method_out = {}
        for protocol, gt_dir in (("orthrus", args.gt_orthrus),
                                 ("reapr", args.gt_reapr)):
            gt_sets = load_gt(gt_dir)
            touch = touch_map(ds, idmap, gt_sets)
            attacks = evaluate(result, touch, gt_sets, chain_based=False)
            for name, gt_uuids in gt_sets.items():
                gt_bids = {b for b, names in touch.items() if name in names}
                attacks[name]["ranking"] = ranking_metrics(
                    result["scores"], gt_bids, all_bids)
                print(method, protocol, name,
                      "AP", attacks[name]["ranking"]["average_precision"],
                      "oracle F1", attacks[name]["ranking"]["oracle_max_f1"],
                      flush=True)
            method_out[protocol] = attacks
        final[method] = method_out
    out = {
        "protocol": "B1/B2 all-behaviour ranking; zero score for missing behaviours; "
                    "ties evaluated together; original 0.5 point retained; "
                    "oracle max-F1 is target-domain diagnostic only",
        "results": final,
    }
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as handle:
        json.dump(out, handle, indent=1)
    print("saved", args.out, flush=True)


if __name__ == "__main__":
    main()
