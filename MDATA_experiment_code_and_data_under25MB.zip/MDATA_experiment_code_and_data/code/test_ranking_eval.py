from ranking_eval import ranking_metrics

perfect = ranking_metrics({1: 0.9, 2: 0.8, 3: 0.1, 4: 0.0}, {1, 2}, [1, 2, 3, 4])
assert perfect["average_precision"] == 1.0
assert perfect["oracle_max_f1"] == 1.0
assert perfect["oracle_threshold"] == 0.8
assert len(perfect["pr_curve_101"]) == 101

tied = ranking_metrics({}, {1, 2}, [1, 2, 3, 4])
assert tied["average_precision"] == 0.5
assert tied["oracle_max_f1"] == round(2 * 0.5 / 1.5, 6)
assert tied["oracle_threshold"] == 0.0

partial = ranking_metrics({1: 0.7}, {1}, [1, 2])
assert partial["n_behaviours"] == 2
assert partial["n_positive"] == 1
assert partial["average_precision"] == 1.0
print("ranking metrics tests OK")
