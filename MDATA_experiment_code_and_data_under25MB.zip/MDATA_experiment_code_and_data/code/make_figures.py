"""Generate all paper figures from results JSONs.

Colour-blind-safe palette, PDF output, embedded fonts (Type 42),
consistent styling across all figures.
"""
from __future__ import annotations

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import config as C

plt.rcParams.update({
    "font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5,
    "legend.fontsize": 7.5, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.alpha": 0.25, "grid.linewidth": 0.5,
    "lines.linewidth": 1.6, "figure.dpi": 200,
})
PAL = {"B1": "#999999", "B2": "#E69F00", "B3": "#56B4E9",
       "B4": "#009E73", "MDATA": "#D55E00", "A1": "#56B4E9",
       "A2": "#CC79A7", "A3": "#009E73", "A4": "#E69F00"}
LBL = {"B1": "B1 rule ranking", "B2": "B2 time+IP heuristic",
       "B3": "B3 graph w/o asset", "B4": "B4 reduced MDATA",
       "MDATA": "MDATA (ours)"}


def load(name):
    with open(os.path.join(C.RESULTS, name), encoding="utf-8") as f:
        return json.load(f)


# ---------------------------------------------------------------- fig PR --
def fig_pr(npz_path):
    d = np.load(npz_path)
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    order = ["B1", "B2", "B3", "B4", "MDATA"]
    for m in order:
        sc, lb = d[f"{m}_sc"], d[f"{m}_lb"]
        o = np.lexsort((np.arange(len(sc)), -sc))
        y = lb[o]
        tp = np.cumsum(y)
        prec = tp / np.arange(1, len(y) + 1)
        rec = tp / max(1, y.sum())
        ax.plot(rec, prec, color=PAL[m], label=LBL[m])
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.legend(frameon=False, loc="lower left")
    fig.tight_layout()
    fig.savefig(os.path.join(C.FIGURES, "fig_pr.pdf"))
    plt.close(fig)


# ------------------------------------------------------------- fig robust --
def fig_robust():
    d = load("robustness_S1.json")
    modes = [("mask", "Field masking ratio", [0.1, 0.3, 0.5]),
             ("jitter", "Timestamp jitter $\\sigma$ (s)", [300, 900, 3600]),
             ("stale_intel", "Stale-TI fraction", [0.2, 0.4, 0.6]),
             ("infra_rotation", "Infra rotation rate", [0.3, 0.6, 1.0])]
    fig, axes = plt.subplots(1, 4, figsize=(7.0, 1.9))
    for ax, (mode, xl, levels) in zip(axes, modes):
        for m in ("B1", "B2", "MDATA"):
            xs, mu, sd = [], [], []
            for lv in levels:
                vals = [r["methods"][m]["f1"] for r in d["results"]
                        if r["mode"] == mode and r["level"] == lv]
                if vals:
                    xs.append(lv)
                    mu.append(np.mean(vals))
                    sd.append(np.std(vals))
            ax.errorbar(xs, mu, yerr=sd, color=PAL[m], marker="o",
                        markersize=3, capsize=2, label=LBL[m])
        ax.set_title(xl.replace(" (s)", ""), fontsize=8)
        ax.set_xlabel(xl)
        ax.set_ylim(0, 1)
        if mode == "mask":
            ax.set_ylabel("F1")
    axes[0].legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(C.FIGURES, "fig_robust.pdf"))
    plt.close(fig)


# ---------------------------------------------------------- fig sensitivity --
def fig_sens():
    d = load("sensitivity_S1.json")
    grid = [("theta", r"correlation threshold $\theta$",
             [0.25, 0.30, 0.35, 0.40, 0.45]),
            ("beam", r"beam width $B$", [16, 32, 64]),
            ("max_len", r"max path length $L$", [6, 8, 12]),
            ("time_tol", r"clock tolerance $\delta$ (s)", [600, 1800, 3600])]
    fig, axes = plt.subplots(1, 4, figsize=(7.0, 1.9))
    for ax, (p, xl, vals) in zip(axes, grid):
        xs, f1, f1e, cm, cme, rt = [], [], [], [], [], []
        for v in vals:
            rows = [r for r in d["results"] if r["param"] == p
                    and r["value"] == v]
            if not rows:
                continue
            xs.append(v)
            f1.append(np.mean([r["f1"] for r in rows]))
            f1e.append(np.std([r["f1"] for r in rows]))
            cm.append(np.mean([r["completeness"] for r in rows]))
            cme.append(np.std([r["completeness"] for r in rows]))
            rt.append(np.mean([r["runtime_s"] for r in rows]))
        ax.errorbar(xs, f1, yerr=f1e, color="#D55E00", marker="o",
                    markersize=3, capsize=2, label="F1")
        ax2 = ax.twinx()
        ax2.errorbar(xs, cm, yerr=cme, color="#0072B2", marker="s",
                     markersize=3, capsize=2, linestyle="--",
                     label="completeness")
        ax2.spines["top"].set_visible(False)
        ax2.grid(False)
        ax.set_xlabel(xl)
        if p == "theta":
            ax.set_ylabel("F1", color="#D55E00")
            ax2.set_ylabel("Path completeness", color="#0072B2")
        if p == "beam":
            h1, l1 = ax.get_legend_handles_labels()
            h2, l2 = ax2.get_legend_handles_labels()
            ax.legend(h1 + h2, l1 + l2, frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(os.path.join(C.FIGURES, "fig_sens.pdf"))
    plt.close(fig)


# ------------------------------------------------------------ fig workload --
def fig_workload():
    d = load("main_S2.json")
    fig, ax = plt.subplots(figsize=(3.4, 2.4))
    names = ["B1", "B2", "B3", "B4", "MDATA"]
    wl = [100 * d["agg"][m]["workload"]["mean"] for m in names]
    rc = [d["agg"][m]["recall"]["mean"] for m in names]
    x = np.arange(len(names))
    ax2 = ax.twinx()
    ax2.spines["top"].set_visible(False)
    ax2.grid(False)
    b = ax.bar(x - 0.18, wl, 0.36, color=[PAL[m] for m in names],
               alpha=0.85, label="analyst workload (%)")
    ax2.plot(x + 0.18, rc, "o-", color="black", markersize=4,
             label="recall")
    for xi, wi in zip(x - 0.18, wl):
        ax.text(xi, wi + 0.3, f"{wi:.1f}", ha="center", fontsize=7)
    ax.set_xticks(x)
    ax.set_xticklabels(names)
    ax.set_ylabel("Alert workload (%)")
    ax2.set_ylabel("Recall")
    ax.set_ylim(0, max(wl) * 1.35 + 2)
    ax2.set_ylim(0, 1.05)
    fig.tight_layout()
    fig.savefig(os.path.join(C.FIGURES, "fig_workload.pdf"))
    plt.close(fig)


# --------------------------------------------------------------- fig bench --
def fig_bench():
    """Benchmark characterisation: daily volume + stage mix + TI coverage."""
    import datagen
    import collections
    ds = datagen.generate(11, "S2")
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 1.8))
    # (a) daily atomic-event volume by channel
    daily = collections.defaultdict(collections.Counter)
    for b in ds.behaviors:
        for r in b.records:
            day = r["ts"] // 86400
            daily[day][r["channel"]] += 1
    days = sorted(daily)
    chans = ["flow", "ids", "dns", "honeypot", "edr"]
    cols = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00"]
    bottom = np.zeros(len(days))
    for ch, col in zip(chans, cols):
        vals = np.array([daily[d][ch] for d in days], dtype=float)
        axes[0].bar(days, vals, bottom=bottom, color=col, width=1.0,
                    label=ch, alpha=0.9)
        bottom += vals
    axes[0].set_xlabel("Operation day")
    axes[0].set_ylabel("Raw records / day")
    axes[0].legend(frameon=False, ncol=2, fontsize=6)
    # (b) behaviour mix (log scale)
    kinds = collections.Counter(b.kind for b in ds.behaviors)
    top = kinds.most_common(10)
    axes[1].barh([k for k, _ in top][::-1],
                 [v for _, v in top][::-1], color="#0072B2")
    axes[1].set_xscale("log")
    axes[1].set_xlabel("Behaviours (log)")
    # (c) TI verdict coverage of external IPs
    verdicts = collections.Counter(v["verdict"] for v in
                                   ds.world.intel.values())
    axes[2].pie([verdicts.get("malicious", 0), verdicts.get("benign", 0),
                 verdicts.get("unknown", 0)],
                labels=["malicious", "benign", "unknown"],
                colors=["#D55E00", "#009E73", "#BBBBBB"],
                autopct="%1.0f%%", textprops={"fontsize": 7},
                startangle=90)
    fig.tight_layout()
    fig.savefig(os.path.join(C.FIGURES, "fig_bench.pdf"))
    plt.close(fig)


# ------------------------------------------------------------------ fig case --
def fig_case():
    d = load("case_study.json")
    case = d["cases"][0]
    gt = case["gt"]
    pred = case["pred_chain"]
    # minimal readable canvas: stage axis + domain-coloured dots + chain
    # path; the colour key lives in the LaTeX caption, not the figure
    fig, ax = plt.subplots(figsize=(3.2, 1.3))
    stages = ["recon", "exploit", "c2", "lateral", "priv_esc", "exfil"]
    ypos = {s: i for i, s in enumerate(stages)}
    for i, g in enumerate(gt):
        y = ypos[g["stage"]]
        col = "#D55E00" if g["domain"] == "DOM-A" else (
            "#0072B2" if g["domain"] == "DOM-B" else "#7B2D8E")
        ax.plot([g["t0"] / 86400], [y], "o", color=col, markersize=5,
                zorder=3)
    # predicted chain path
    pts = [(p["t"] / 86400, ypos[p["stage"]])
           for p in pred if p.get("stage") in stages]
    if len(pts) >= 2:
        xs, ys = zip(*pts)
        ax.plot(xs, ys, "-", color="black", alpha=0.5, linewidth=1.4,
                zorder=2)
    for s, y in ypos.items():
        ax.axhline(y, color="#EEEEEE", zorder=0, linewidth=0.8)
    ax.set_yticks(list(ypos.values()))
    ax.set_yticklabels(stages, fontsize=7.5)
    ax.tick_params(axis="x", labelsize=7.5)
    ax.set_xlabel("Operation day", fontsize=8)
    ax.set_ylim(-0.7, len(stages) - 0.1)
    fig.tight_layout(pad=0.4)
    fig.savefig(os.path.join(C.FIGURES, "fig_case.pdf"),
                bbox_inches="tight")
    plt.close(fig)


# ------------------------------------------------------------------- fig scale --
def fig_scale():
    d = load("engineering.json")
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 1.9))
    sc = [r["scale"] for r in d]
    ev = [r["n_events"] for r in d]
    axes[0].bar(sc, ev, color="#0072B2")
    for i, v in enumerate(ev):
        axes[0].text(i, v, f"{v/1000:.0f}k", ha="center", va="bottom",
                     fontsize=7)
    axes[0].set_ylabel("Atomic events")
    th = [r["stream"]["throughput_ev_s"] for r in d]
    axes[1].bar(sc, th, color="#D55E00")
    for i, v in enumerate(th):
        axes[1].text(i, v, f"{v:.0f}", ha="center", va="bottom", fontsize=7)
    axes[1].set_ylabel("Throughput (ev/s)")
    p50 = [r["stream"]["p50_ms"] for r in d]
    p95 = [r["stream"]["p95_ms"] for r in d]
    x = np.arange(len(sc))
    axes[2].bar(x - 0.18, p50, 0.36, label="P50", color="#009E73")
    axes[2].bar(x + 0.18, p95, 0.36, label="P95", color="#E69F00")
    axes[2].set_xticks(x)
    axes[2].set_xticklabels(sc)
    axes[2].set_ylabel("Batch latency (ms)")
    axes[2].legend(frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(C.FIGURES, "fig_scale.pdf"))
    plt.close(fig)


if __name__ == "__main__":
    import sys
    which = sys.argv[1:] or ["all"]
    if "all" in which or "pr" in which:
        fig_pr(os.path.join(C.RESULTS, "scores_S2.npz"))
    if "all" in which or "rob" in which:
        fig_robust()
    if "all" in which or "sens" in which:
        fig_sens()
    if "all" in which or "wl" in which:
        fig_workload()
    if "all" in which or "bench" in which:
        fig_bench()
    if "all" in which or "case" in which:
        fig_case()
    if "all" in which or "scale" in which:
        fig_scale()
    print("figures written to", C.FIGURES)
