"""Auto-generate LaTeX tables (complete tabular environments) and number
macros from results JSONs -- no manual numbers in the manuscript."""
from __future__ import annotations

import glob
import json
import os

import numpy as np

import config as C

NL = chr(10)
BS = chr(92)
D = BS + BS                     # row separator \\


def load(name):
    with open(os.path.join(C.RESULTS, name), encoding="utf-8") as f:
        return json.load(f)


def wrap(colspec, header, body):
    out = [BS + "begin{tabular}{@{}" + colspec + "@{}}",
           BS + "toprule", header, BS + "midrule", body.rstrip(),
           BS + "bottomrule", BS + "end{tabular}"]
    return NL.join(out) + NL


def put(path, text):
    with open(path, "w", encoding="utf-8", newline=NL) as f:
        f.write(text)
    print("wrote", path)


def fmt(mu, sd=None, prec=1):
    v = 100 * mu
    if sd is None:
        return f"{v:.{prec}f}"
    return f"{v:.{prec}f}" + BS + "," + BS + "scriptsize$" + BS + "pm$" + f"{100*sd:.{prec}f}"


def ci_str(a, key):
    if key not in a:
        return "--"
    lo = np.mean([v[0] for v in a[key]["values"]])
    hi = np.mean([v[1] for v in a[key]["values"]])
    return BS + "scriptsize[" + f"{100*lo:.0f},{100*hi:.0f}" + "]"


NAMES = {
    "B1": "B1: rule-severity ranking",
    "B2": "B2: time$+$IP heuristic",
    "B3": "B3: graph w/o asset rel.",
    "B4": "B4: reduced MDATA",
    "MDATA": BS + "textbf{MDATA (full)}",
    "B5": "B5: GraphSAGE (sup.)",
}



def _gnn_best():
    """Per-seed best supervised GNN configuration (test metrics)."""
    best = []
    for path in sorted(glob.glob(os.path.join(C.RESULTS,
                                              "gnn_S2_seed*.json"))):
        with open(path, encoding="utf-8") as f:
            best.append(json.load(f)["best"])
    return best


def _colour_column(cells, values, smaller=False):
    """Red = best cell, blue = second best."""
    if not values or len(cells) != len(values) or len(cells) < 2:
        return cells
    order = sorted(range(len(values)),
                   key=lambda i: values[i] if smaller else -values[i])
    out = list(cells)
    out[order[0]] = BS + "textcolor{red}{" + out[order[0]] + "}"
    out[order[1]] = BS + "textcolor{blue}{" + out[order[1]] + "}"
    return out


def main_table():
    d = load("main_S2.json")
    agg = d["agg"]
    gb = _gnn_best()
    methods = ["B1", "B2", "B3", "B4", "MDATA"] + (["B5"] if gb else [])
    stats = {}
    for m in methods:
        if m == "B5":
            stats[m] = {k: dict(mean=float(np.mean([b[k] for b in gb])),
                                std=float(np.std([b[k] for b in gb])))
                        for k in ("precision", "recall", "f1", "prauc",
                                  "ndcg@50", "topk@100", "workload")}
        else:
            stats[m] = agg[m]
    cols = ["precision", "recall", "f1", "prauc", "ndcg@50",
            "workload"]
    smaller_cols = {"workload"}
    cells = {m: [] for m in methods}
    for k in cols:
        for m in methods:
            a = stats[m][k]
            cells[m].append(fmt(a["mean"], a["std"]))
        col = _colour_column([cells[m][-1] for m in methods],
                             [stats[m][k]["mean"] for m in methods],
                             smaller=k in smaller_cols)
        for m, cx in zip(methods, col):
            cells[m][-1] = cx
    rows = [NAMES[m] + " & " + " & ".join(cells[m]) + " " + D
            for m in methods]
    header = ("Method & Precision & Recall & F1 & PR-AUC & NDCG@50 &"
              " Workload " + D)
    put(os.path.join(C.FIGURES, "tab_main.tex"),
        wrap("lcccccc", header, NL.join(rows)))


def chain_table():
    d = load("main_S2.json")
    agg = d["agg"]
    methods = ["B1", "B2", "B3", "B4", "MDATA"]
    keys = ["node_f1", "edge_f1", "stage_edit", "completeness"]
    smaller_cols = {"stage_edit"}
    cells = {m: [] for m in methods}
    for k in keys:
        for m in methods:
            a = agg[m][k]
            if k == "stage_edit":
                cells[m].append(f"{a['mean']:.2f}" + BS +
                                ",\\scriptsize$\\pm$" + f"{a['std']:.2f}")
            else:
                cells[m].append(fmt(a["mean"], a["std"]))
        col = _colour_column([cells[m][-1] for m in methods],
                             [agg[m][k]["mean"] for m in methods],
                             smaller=k in smaller_cols)
        for m, cx in zip(methods, col):
            cells[m][-1] = cx
    rows = []
    for m in methods:
        nm = BS + "textbf{MDATA}" if m == "MDATA" else m
        rows.append(nm + " & " + " & ".join(cells[m]) + " " + D)
    header = ("Method & Node F1 & Edge F1 & Stage edit $" + BS +
              "downarrow$ & Compl. " + D)
    put(os.path.join(C.FIGURES, "tab_chain.tex"),
        wrap("lcccc", header, NL.join(rows)))


def ablation_table():
    d = load("main_S2.json")
    agg = d["agg"]
    base = agg["MDATA"]
    rows = [BS + "textbf{MDATA (full)} & " + " & ".join([
        fmt(base["f1"]["mean"], base["f1"]["std"]),
        fmt(base["prauc"]["mean"], base["prauc"]["std"]),
        fmt(base["node_f1"]["mean"], base["node_f1"]["std"]),
        fmt(base["completeness"]["mean"], base["completeness"]["std"]),
        fmt(base["ndcg@50"]["mean"], base["ndcg@50"]["std"]),
    ]) + " " + D]
    for a, lbl in [("A1_no_asset", "A1: $-$asset " + BS + "& business rel."),
                   ("A2_no_intel", "A2: $-$TI " + BS + "& honeypot evid."),
                   ("A3_no_time", "A3: $-$temporal constraints"),
                   ("A4_no_evidence",
                    "A4: $-$evidence suffic. " + BS + "& $u$")]:
        x = agg[a]
        cells = []
        for k in ("f1", "prauc", "node_f1", "completeness", "ndcg@50"):
            delta = 100 * (x[k]["mean"] - base[k]["mean"])
            col = "blue" if delta >= 0 else "red"
            cells.append(fmt(x[k]["mean"], x[k]["std"]) + " " +
                         BS + "scriptsize(" + BS +
                         f"textcolor{{{col}}}{{{delta:+.1f}}}" + ")")
        rows.append(lbl + " & " + " & ".join(cells) + " " + D)
    header = "Variant & F1 & PR-AUC & Node F1 & Compl. & NDCG@50 " + D
    put(os.path.join(C.FIGURES, "tab_ablation.tex"),
        wrap("lccccc", header, NL.join(rows)))


def bench_table():
    import collections
    import datagen
    ds = datagen.generate(11, "S2")
    n_beh, n_rec = len(ds.behaviors), len(ds.records)
    eff = sum(1 for c in ds.campaigns.values() if c.is_effective)
    atk_b = sum(len(c.behaviors) for c in ds.campaigns.values())
    ch = collections.Counter(r["channel"] for r in ds.records)
    intel = collections.Counter(v["verdict"] for v in ds.world.intel.values())
    cross = sum(1 for c in ds.campaigns.values() if len(c.domains) > 1)
    tot = max(1, sum(intel.values()))
    rows = [
        f"Assurance window & {C.OP_DAYS} days (3 domains) {D}",
        f"Raw channel records & {n_rec:,} (flow {ch['flow']:,} / ids "
        f"{ch['ids']:,} / dns {ch['dns']:,} / honeypot {ch['honeypot']:,} /"
        f" edr {ch['edr']:,} / ticket {ch['ticket']}) {D}",
        f"Atomic behaviours & {n_beh:,} {D}",
        f"Attack campaigns & {len(ds.campaigns)} ({eff} effective, "
        f"{cross} cross-domain) {D}",
        f"Attack behaviour share & {100*atk_b/n_beh:.1f}" + BS + "% " + D,
        "TI verdicts (ext.\\ IPs) & "
        f"{100*intel['malicious']/tot:.1f}" + BS + "% malicious / "
        f"{100*intel['benign']/tot:.1f}" + BS + "% benign / "
        f"{100*intel['unknown']/tot:.1f}" + BS + "% unknown " + D,
    ]
    header = "Property & Value " + D
    put(os.path.join(C.FIGURES, "tab_bench.tex"),
        wrap("p{2.35cm}p{5.0cm}", header, NL.join(rows)))


def engineering_table():
    d = load("engineering.json")
    rows = []
    for r in d:
        s = r["stream"]
        rows.append(f"{r['scale']} & {r['n_events']:,} & "
                    f"{r['n_candidates']/r['n_events']:.1f} & "
                    f"{s['throughput_ev_s']:.0f} & {s['p50_ms']:.0f} & "
                    f"{s['p95_ms']:.0f} & {r['peak_mem_mb']:.0f} " + D)
    header = ("Scale & Events & Pairs/ev & Thr.(ev/s) & P50(ms) & P95(ms) &"
              " Mem(MB) " + D)
    put(os.path.join(C.FIGURES, "tab_eng.tex"),
        wrap("lcccccc", header, NL.join(rows)))


def sig_table():
    d = load("main_S2.json")
    pretty = dict(NAMES)
    pretty.update({"A1_no_asset": "A1 (=B3): $-$asset rel.",
                   "A2_no_intel": "A2: $-$TI evid.",
                   "A3_no_time": "A3: $-$temporal",
                   "A4_no_evidence": "A4: $-$evidence suffic."})
    rows = []
    order = ["B1", "B2", "B3", "B4", "A1_no_asset", "A2_no_intel",
             "A3_no_time", "A4_no_evidence"]
    for m in order:
        v = d.get("sig", {}).get(m)
        if v is None:
            continue
        rows.append("MDATA vs. " + pretty.get(m, m.replace("_", " ")) + " & " +
                    f"{v.get('wins', 0):,} & {v.get('losses', 0):,} & " +
                    f"{v['p']:.2g} " + D)
    header = "Comparison & Wins & Losses & $p$ (McNemar) " + D
    put(os.path.join(C.FIGURES, "tab_sig.tex"),
        wrap("lcccc", header, NL.join(rows)))


def stage_table():
    d = load("main_S2.json")
    best = min(d["runs"], key=lambda r: abs(
        r["methods"]["MDATA"].get("runtime_s", 1e9)))
    t = best["methods"]["MDATA"].get("stage_timing", {})
    cand_score = t.get("candidates", float("nan")) + t.get("scoring", 0.0)
    vals = [t.get("normalize", float("nan")), cand_score,
            t.get("cluster_search", float("nan")),
            t.get("threat", float("nan")), t.get("total", float("nan"))]
    row = "Seconds & " + " & ".join(f"{v:.1f}" for v in vals) + " " + D
    header = "Stage & Norm. & Cand.+score & Clus.+search & Threat & Total " + D
    put(os.path.join(C.FIGURES, "tab_stage.tex"),
        wrap("lccccc", header, row))


def gnn_table():
    rows, best = [], []
    by_cfg = {}
    for path in sorted(glob.glob(os.path.join(C.RESULTS,
                                              "gnn_S2_seed*.json"))):
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        for r in d["all"]:
            by_cfg.setdefault((r["hidden"], r["dropout"], r["lr"]),
                              []).append(r)
        best.append(d["best"])
    for (h, dr, lr), rs in sorted(by_cfg.items()):
        f1 = np.mean([r["f1"] for r in rs])
        pa = np.mean([r["prauc"] for r in rs])
        rows.append(f"{h} & {dr} & {lr:g} & {rs[0]['params']:,} & "
                    f"{100*f1:.1f} & {100*pa:.1f} " + D)
    if rows:
        header = "hidden & dropout & lr & params & F1 & PR-AUC " + D
        put(os.path.join(C.FIGURES, "tab_gnn.tex"),
            wrap("lccccc", header, NL.join(rows)))
    return best


def agents_local_table():
    """tab_agents.tex: API tier (agents_S2_11_summary.json) plus the local
    Qwen tier (agents_local_S2_11.json, whenever it exists).  Also writes
    numbers_agents_local.tex macros for the local rows."""
    api = load("agents_S2_11_summary.json")["per_model"]
    API_ROWS = [("DS-V4.1-Flash", "DeepSeek-V4.1-Flash"),
                ("DS-V4-Pro", "DeepSeek-V4-Pro-0813"),
                ("GPT-5.2", "GPT-5.2")]
    LOCAL_ROWS = [("Qwen2.5-7B", "qwen7b"), ("Qwen2.5-14B", "qwen14b"),
                  ("Qwen2.5-32B", "qwen32b")]
    loc = {}
    p = os.path.join(C.RESULTS, "agents_local_S2_11.json")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            for r in json.load(f):
                loc.setdefault(r["model"], {}).setdefault(
                    r["mode"], []).append(r)
    L, body = [], []

    def m(rows, key):
        return 100 * float(np.mean([r[key] for r in rows]))

    for disp, key in API_ROWS + [(d, k) for d, k in LOCAL_ROWS
                                 if k in loc]:
        if key in loc:                              # local tier
            g = loc[key]
            n_fab = m(g["naive"], "fabrication_rate")
            n_over = m(g["naive"], "conclusion_overreach")
            naive_cell = f"{n_fab:.0f}/{n_over:.0f}"
            if n_fab >= 40:
                naive_cell = (BS + "textcolor{red}{" + BS +
                              "textbf{" + naive_cell + "}}")
            gfab = f"{m(g['grounded'], 'fabrication_rate'):.0f}"
            if float(gfab) == 0:
                gfab = BS + "textcolor{blue}{" + BS + "textbf{0}}"
            cells = [naive_cell, gfab]
            for mode in ("grounded", "agent", "agent_strict"):
                cells.append(f"{m(g[mode], 'verdict_correct'):.0f}")
            tier = "local"
        else:                                       # API tier
            n = api[f"{key}|naive"]
            naive_cell = (f"{100*n['fabrication_rate']:.0f}/"
                          f"{100*n['conclusion_overreach']:.0f}")
            if n['fabrication_rate'] >= 0.40:
                naive_cell = (BS + "textcolor{red}{" + BS +
                              "textbf{" + naive_cell + "}}")
            cells = [naive_cell,
                     BS + "textcolor{blue}{" + BS + "textbf{0}}"]
            for mode in ("grounded", "agent", "agent_strict"):
                cells.append(f"{100*api[f'{key}|{mode}']['verdict_accuracy']:.0f}")
            tier = "api"
        body.append(f"{disp} & " + " & ".join(cells) + " " + D)
        if key in loc:
            g = loc[key]
            word = {"7b": "Seven", "14b": "Fourteen",
                    "32b": "Thirtytwo"}[key[4:]]
            for name, v in [
                (f"nAgLoc{word}NaiveFab",
                 m(g["naive"], "fabrication_rate")),
                (f"nAgLoc{word}GroundAcc",
                 m(g["grounded"], "verdict_correct")),
                (f"nAgLoc{word}AgentAcc",
                 m(g["agent"], "verdict_correct")),
                (f"nAgLoc{word}StrictAcc",
                 m(g["agent_strict"], "verdict_correct")),
            ]:
                L.append(BS + "newcommand" + BS + name +
                         "{" + f"{v:.1f}" + "}")
    def _fancy_agents(rows_):
        try:
            rows = [r.split(" & ") for r in rows_]
            for ci in (3, 4, 5):
                vals = []
                for c in rows:
                    num = ""
                    for ch in c[ci]:
                        if ch.isdigit() or ch == ".":
                            num += ch
                        else:
                            break
                    vals.append(float(num))
                order = sorted(range(len(vals)), key=lambda k: -vals[k])
                for rank, idx in enumerate(order[:2]):
                    col = "red" if rank == 0 else "blue"
                    c = rows[idx][ci]
                    tail = ""
                    if c.rstrip().endswith(BS + BS):
                        k2 = c.rfind(BS + BS)
                        tail, c = c[k2:], c[:k2]
                    if "textcolor" not in c:
                        rows[idx][ci] = (BS + "textcolor{" + col + "}{"
                                         + BS + "textbf{" + c + "}}" + tail)
            return [" & ".join(r) for r in rows]
        except Exception:
            return rows_

    body = _fancy_agents(body)
    header = ("& " + BS + "multicolumn{2}{c}{Naive} & Grounded & Agent & "
              "Agent-strict " + BS + BS + BS + "cmidrule(lr){2-3} " +
              "Model & fab/over (" + BS + "%) & fab (" + BS + "%) & acc (" +
              BS + "%) & acc (" + BS + "%) & acc (" + BS + "%) " + D)
    put(os.path.join(C.FIGURES, "tab_agents.tex"),
        wrap("lccccc", header, NL.join(body)))
    if L:
        put(os.path.join(os.path.dirname(C.FIGURES), "manuscript",
                         "numbers_agents_local.tex"), NL.join(L) + NL)


def theia_numbers():
    """Macros for the DARPA TC E3 THEIA external validation."""
    p = os.path.join(C.RESULTS, "theia_eval.json")
    if not os.path.exists(p):
        return
    with open(p, encoding="utf-8") as f:
        d = json.load(f)
    at = d["attacks"]
    dr = at.get("Browser_Extension_Drakon_Dropper", {})
    bk = at.get("Firefox_Backdoor_Drakon_In_Memory", {})
    L = [BS + "newcommand" + BS + "nTheiaBehs{" + f"{d['n_behaviours']:,}" + "}",
         BS + "newcommand" + BS + "nTheiaChains{" + f"{d['n_chains']:,}" + "}"]
    if dr:
        L += [BS + "newcommand" + BS + "nTheiaDropperPrec{" +
              f"{100*dr['precision']:.0f}" + "}",
              BS + "newcommand" + BS + "nTheiaDropperRec{" +
              f"{100*dr['recall']:.0f}" + "}",
              BS + "newcommand" + BS + "nTheiaDropperFone{" +
              f"{100*dr['f1']:.0f}" + "}"]
    if bk:
        L += [BS + "newcommand" + BS + "nTheiaBackPrec{" +
              f"{100*bk['precision']:.0f}" + "}",
              BS + "newcommand" + BS + "nTheiaBackGt{" +
              f"{bk['gt_behaviours']:,}" + "}"]
    rp = os.path.join(C.RESULTS, "theia_eval_reapr.json")
    if os.path.exists(rp):
        with open(rp, encoding="utf-8") as f:
            d2 = json.load(f)["attacks"]
        dr2 = d2.get("Browser_Extension_Drakon_Dropper", {})
        bk2 = d2.get("Firefox_Backdoor_Drakon_In_Memory", {})
        if dr2:
            L += [BS + "newcommand" + BS + "nTheiaRaprDropFone{" +
                  f"{100*dr2['f1']:.0f}" + "}"]
        if bk2:
            L += [BS + "newcommand" + BS + "nTheiaRaprBackFone{" +
                  f"{100*bk2['f1']:.0f}" + "}",
                  BS + "newcommand" + BS + "nTheiaRaprBackPrec{" +
                  f"{100*bk2['precision']:.0f}" + "}",
                  BS + "newcommand" + BS + "nTheiaRaprBackRec{" +
                  f"{100*bk2['recall']:.0f}" + "}"]
    put(os.path.join(os.path.dirname(C.FIGURES), "manuscript",
                     "numbers_theia.tex"), NL.join(L) + NL)


def llm_table():
    """Dual-model evidence-grounding table: Qwen2.5-3B (headline model,
    llm_fabrication.json) and Qwen2.5-7B (llm_fabrication_7b.json when
    present), each constrained vs unconstrained."""
    sources = [("Qwen2.5-3B", "llm_fabrication.json"),
               ("Qwen2.5-7B", "llm_fabrication_7b.json"),
               ("Qwen2.5-14B", "llm_fabrication_14b.json")]
    out, stats = [], {}
    for model, fn in sources:
        path = os.path.join(C.RESULTS, fn)
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as f:
            rows = json.load(f)
        for mode, lbl in [("constrained", "Constrained"),
                          ("unconstrained", "Unconstrained")]:
            sub = [r for r in rows if r["mode"] == mode]
            if not sub:
                continue
            st = dict(fab=np.mean([r["fabrication_rate"] for r in sub]),
                      over=np.mean([r["conclusion_overreach"] for r in sub]),
                      cov=np.mean([r["evidence_coverage"] for r in sub]),
                      tpl=np.mean([r["template_compliance"] for r in sub]))
            stats[f"{model}|{mode}"] = st
            cells = []
            for k in ("fab", "over", "cov", "tpl"):
                v = 100 * st[k]
                cx = f"{v:.1f}"
                if k == "fab":
                    if v == 0:
                        cx = BS+"textcolor{blue}{"+BS+"textbf{"+cx+"}}"
                    elif v >= 40:
                        cx = BS+"textcolor{red}{"+BS+"textbf{"+cx+"}}"
                elif k == "over" and v > 0:
                    cx = BS+"textcolor{red}{"+cx+"}"
                cells.append(cx)
            out.append(f"{model} & {lbl} & " + " & ".join(cells)
                + " " + D)
    header = ("Model & Prompt mode & Fabr. (" + BS + "%) & Overreach (" +
              BS + "%) & Coverage (" + BS + "%) & Template (" + BS +
              "%) " + D)
    put(os.path.join(C.FIGURES, "tab_llm.tex"),
        wrap("llcccc", header, NL.join(out)))
    return stats


def numbers():
    d = load("main_S2.json")
    a = d["agg"]

    def g(m, k):
        return a[m][k]["mean"]

    L = []

    def P(n, v, f="{:.1f}"):
        L.append(BS + "newcommand" + BS + n + "{" + f.format(v) + "}")

    P("nMdataFone", 100 * g("MDATA", "f1"))
    P("nMdataPRAUC", 100 * g("MDATA", "prauc"))
    P("nMdataWL", 100 * g("MDATA", "workload"))
    P("nMdataWLc", 100 * g("MDATA", "workload_constrained"))
    P("nMdataCompl", 100 * g("MDATA", "completeness"))
    P("nMdataNodeF", 100 * g("MDATA", "node_f1"))
    P("nMdataEdgeF", 100 * g("MDATA", "edge_f1"))
    P("nMdataEdit", g("MDATA", "stage_edit"), "{:.2f}")
    P("nBoneFone", 100 * g("B1", "f1"))
    P("nBoneWLc", 100 * g("B1", "workload_constrained"), "{:.0f}")
    P("nBtwoPrec", 100 * g("B2", "precision"))
    P("nBtwoRecall", 100 * g("B2", "recall"))
    P("nBtwoWLc", 100 * g("B2", "workload_constrained"), "{:.0f}")
    P("nBtwoEdgeF", 100 * g("B2", "edge_f1"))
    P("nBthreeCompl", 100 * g("B3", "completeness"))
    P("nBthreeNodeF", 100 * g("B3", "node_f1"))
    P("nBfourPRAUC", 100 * g("B4", "prauc"))
    P("nFoneGainPP", 100 * (g("MDATA", "f1") - g("B1", "f1")))
    P("nAoneDelta", 100 * (g("A1_no_asset", "f1") - g("MDATA", "f1")))
    P("nAoneDeltaCompl", 100 * (g("A1_no_asset", "completeness") -
                                g("MDATA", "completeness")))
    P("nAtwoDelta", 100 * (g("A2_no_intel", "f1") - g("MDATA", "f1")))
    P("nAthreeDelta", 100 * (g("A3_no_time", "f1") - g("MDATA", "f1")))
    P("nAfourDelta", 100 * (g("A4_no_evidence", "f1") - g("MDATA", "f1")))
    P("nEventsStwo", d["dataset"]["n_behaviors"], "{:,.0f}")
    try:
        import datagen as _dg
        _ds = _dg.generate(11, "S2")
        _atk = sum(len(c.behaviors) for c in _ds.campaigns.values())
        P("nAtkShare", 100 * _atk / max(1, len(_ds.behaviors)))
        del _ds
    except Exception as ex:
        print("atkshare pending:", ex)
    try:
        e = load("engineering.json")
        s3 = [r for r in e if r["scale"] == "S3"][0]
        P("nEventsSthree", s3["n_events"], "{:,.0f}")
        P("nThroughputSthree", s3["stream"]["throughput_ev_s"], "{:.0f}")
        P("nPfifty", s3["stream"]["p50_ms"], "{:.0f}")
        P("nPninetyfive", s3["stream"]["p95_ms"], "{:.0f}")
        P("nMemSthree", s3["peak_mem_mb"], "{:.0f}")
        P("nPairsPerEvent", s3["n_candidates"] / s3["n_events"], "{:.1f}")
    except Exception as ex:
        print("engineering numbers pending:", ex)
    try:
        s = load("sensitivity_S1.json")
        f1s = [r["f1"] for r in s["results"] if r["param"] == "theta"
               and 0.30 <= r["value"] <= 0.40]
        if f1s:
            P("nSensThetaRange", 100 * (max(f1s) - min(f1s)))
    except Exception as ex:
        print("sens numbers pending:", ex)
    try:
        rb = load("robustness_S1.json")
        base = [r for r in rb["results"] if r["mode"] == "mask"
                and r["level"] == 0.3]
        if base:
            P("nRobMaskThirty", 100 * (
                np.mean([r["methods"]["MDATA"]["f1"] for r in base]) -
                np.mean([r["methods"]["B1"]["f1"] for r in base])), "{:.0f}")
        rot = [r for r in rb["results"] if r["mode"] == "infra_rotation"
               and r["level"] == 1.0]
        rot0 = [r for r in rb["results"] if r["mode"] == "infra_rotation"
                and r["level"] == 0.3]
        if rot and rot0:
            P("nRobRotCompl", 100 * (
                np.mean([r["methods"]["MDATA"]["completeness"] for r in rot0])
                - np.mean([r["methods"]["MDATA"]["completeness"]
                           for r in rot])), "{:.0f}")
    except Exception as ex:
        print("robustness numbers pending:", ex)
    try:
        cs = load("case_study.json")
        c0 = cs["cases"][0]
        R = c0["threat"]["R"]
        L.append(BS + "newcommand" + BS + "caseGroup{" + c0["group"] + "}")
        L.append(BS + "newcommand" + BS + "caseDomA{" + c0["domains"][0] + "}")
        L.append(BS + "newcommand" + BS + "caseDomB{" +
                 c0["domains"][-1] + "}")
        L.append(BS + "newcommand" + BS + "caseCov{" +
                 f"{100*c0['coverage']:.0f}" + BS + "%}")
        L.append(BS + "newcommand" + BS + "caseR{" + f"{R:.2f}" + "}")
        iv = c0["threat"]["interval"]
        L.append(BS + "newcommand" + BS + "caseInterval{[" +
                 f"{iv[0]:.2f}," + f"{iv[1]:.2f}" + "]}")
        L.append(BS + "newcommand" + BS + "caseRecR{" +
                 f"{cs['cases'][1]['max_score']:.2f}" + "}")
    except Exception as ex:
        print("case numbers pending:", ex)
    put(os.path.join(os.path.dirname(C.FIGURES), "manuscript", "numbers.tex"),
        NL.join(L) + NL)


def extra_numbers(gnn_best=None, llm_stats=None):
    L = []
    if gnn_best:
        L.append(BS + "newcommand" + BS + "nBfiveFone{" +
                 f"{100*np.mean([b['f1'] for b in gnn_best]):.1f}" + "}")
        L.append(BS + "newcommand" + BS + "nBfivePRAUC{" +
                 f"{100*np.mean([b['prauc'] for b in gnn_best]):.1f}" + "}")
    if llm_stats:
        c = llm_stats.get("Qwen2.5-3B|constrained")
        u = llm_stats.get("Qwen2.5-3B|unconstrained")
        if c and u:
            for n, v in [("llmConFab", c["fab"]), ("llmConOver", c["over"]),
                         ("llmUncFab", u["fab"]), ("llmUncOver", u["over"]),
                         ("llmConCov", c["cov"]), ("llmConTpl", c["tpl"]),
                         ("llmUncCov", u["cov"]), ("llmUncTpl", u["tpl"])]:
                L.append(BS + "newcommand" + BS + n + "{" +
                         f"{100*v:.1f}" + BS + "%}")
        c7 = llm_stats.get("Qwen2.5-7B|constrained")
        u7 = llm_stats.get("Qwen2.5-7B|unconstrained")
        if c7 and u7:
            for n, v in [("llmSevenConFab", c7["fab"]),
                         ("llmSevenConCov", c7["cov"]),
                         ("llmSevenConTpl", c7["tpl"]),
                         ("llmSevenUncOver", u7["over"]),
                         ("llmSevenUncCov", u7["cov"]),
                         ("llmSevenUncTpl", u7["tpl"])]:
                L.append(BS + "newcommand" + BS + n + "{" +
                         f"{100*v:.1f}" + BS + "%}")
        c14 = llm_stats.get("Qwen2.5-14B|constrained")
        u14 = llm_stats.get("Qwen2.5-14B|unconstrained")
        if c14 and u14:
            for n, v in [("llmFourteenConCov", c14["cov"]),
                         ("llmFourteenConTpl", c14["tpl"]),
                         ("llmFourteenUncOver", u14["over"])]:
                L.append(BS + "newcommand" + BS + n + "{" +
                         f"{100*v:.1f}" + BS + "%}")
    put(os.path.join(os.path.dirname(C.FIGURES), "manuscript",
                     "numbers_extra.tex"), NL.join(L) + NL)



def calibration_table():
    """High-risk-band comparison (MDATA vs A4 vs B1, clean vs 30% masking)."""
    try:
        clean = load("calibration.json")
        mask = load("calibration_mask30.json")
    except FileNotFoundError:
        print("calibration table pending")
        return

    def agg_by(rows):
        out = {}
        for meth in ("MDATA", "A4_no_evidence", "B1"):
            sel = [r for r in rows if r["method"] == meth]
            if not sel:
                continue
            out[meth] = dict(
                prec=float(np.mean([r["high_precision"] for r in sel])),
                cov=float(np.mean([r["high_coverage"] for r in sel])),
                false=float(np.mean([r["false_claim_rate"] for r in sel])))
        return out

    c, mk = agg_by(clean), agg_by(mask)
    if not c or not mk or "MDATA" not in c or "MDATA" not in mk:
        print("calibration table pending")
        return
    label = {"MDATA": BS + "textbf{MDATA}",
             "A4_no_evidence": "A4 (no evid." + BS + " suffic.)",
             "B1": "B1 (rule severity)"}
    rows = []
    for meth in ("MDATA", "A4_no_evidence", "B1"):
        for cond, srcc in (("clean", c), ("mask 30" + BS + "%", mk)):
            a = srcc[meth]
            rows.append(f"{label[meth]} & {cond} & {100*a['prec']:.1f} & "
                        f"{100*a['cov']:.1f} & {100*a['false']:.1f} " + D)
    header = ("Method & Condition & Prec. (" + BS + "%) & Cov. (" + BS +
              "%) & False cl. (" + BS + "%) " + D)
    put(os.path.join(C.FIGURES, "tab_calibration.tex"),
        wrap("llccc", header, NL.join(rows)))
    L = [BS + "newcommand" + BS + "nCalHighClean{" +
         f"{100*c['MDATA']['prec']:.1f}" + "}",
         BS + "newcommand" + BS + "nCalHighMask{" +
         f"{100*mk['MDATA']['prec']:.1f}" + "}",
         BS + "newcommand" + BS + "nCalAfourMask{" +
         f"{100*mk['A4_no_evidence']['prec']:.1f}" + "}",
         BS + "newcommand" + BS + "nCalBoneHigh{" +
         f"{100*c['B1']['prec']:.1f}" + "}"]
    put(os.path.join(os.path.dirname(C.FIGURES), "manuscript",
                     "numbers_case_calib.tex"), NL.join(L) + NL)


if __name__ == "__main__":
    main_table()
    chain_table()
    ablation_table()
    bench_table()
    engineering_table()
    sig_table()
    stage_table()
    calibration_table()
    numbers()
    gb = gnn_table()
    agents_local_table()
    theia_numbers()
    ls = llm_table()
    extra_numbers(gb, ls)
