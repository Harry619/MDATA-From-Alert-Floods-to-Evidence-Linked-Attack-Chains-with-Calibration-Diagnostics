"""Behaviour-level ranking diagnostics shared by THEIA baseline reruns."""
from __future__ import annotations

import numpy as np


def ranking_metrics(scores, positive_bids, all_bids):
    """Return exact average precision, oracle max-F1 and a 101-point PR curve.

    Every behaviour receives a score, with zero for behaviours absent from the
    candidate graph. Tied scores are evaluated together. Oracle max-F1 is a
    target-domain diagnostic, not a calibrated operating point.
    """
    bids = list(all_bids)
    values = np.asarray([scores.get(b, 0.0) for b in bids], dtype=np.float64)
    labels = np.asarray([b in positive_bids for b in bids], dtype=np.int64)
    order = np.argsort(-values, kind="mergesort")
    values, labels = values[order], labels[order]
    ends = np.r_[np.flatnonzero(np.diff(values)), len(values) - 1]
    tp = np.cumsum(labels)[ends].astype(np.float64)
    fp = (ends + 1).astype(np.float64) - tp
    n_pos = float(labels.sum())
    recall = tp / max(1.0, n_pos)
    precision = tp / np.maximum(1.0, tp + fp)
    ap = float(np.sum(np.diff(np.r_[0.0, recall]) * precision))
    f1 = 2 * precision * recall / np.maximum(1e-12, precision + recall)
    best = int(np.argmax(f1)) if len(f1) else 0
    curve = []
    for threshold in np.linspace(0.0, 1.0, 101):
        pred = values >= threshold
        n_pred = int(pred.sum())
        true = int(labels[pred].sum())
        p = true / max(1, n_pred)
        r = true / max(1.0, n_pos)
        curve.append({
            "threshold": round(float(threshold), 2),
            "precision": round(p, 6),
            "recall": round(r, 6),
            "f1": round(2 * p * r / max(1e-12, p + r), 6),
        })
    return {
        "n_behaviours": len(bids),
        "n_positive": int(n_pos),
        "average_precision": round(ap, 6),
        "oracle_max_f1": round(float(f1[best]), 6) if len(f1) else 0.0,
        "oracle_threshold": round(float(values[ends[best]]), 6) if len(f1) else 0.0,
        "pr_curve_101": curve,
    }
