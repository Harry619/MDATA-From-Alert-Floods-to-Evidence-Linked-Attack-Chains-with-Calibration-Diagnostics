"""Equivalence checks for memory-packed THEIA edge processing."""
import random
from types import SimpleNamespace

import pipeline as P
import run_theia_compact as R


def toy_events(rng, n=9):
    stages = ["recon", "exploit", "c2", "lateral", "priv", "exfil", "ops"]
    return [SimpleNamespace(
        stage=stages[rng.randrange(len(stages))],
        severity=rng.random(),
        mid=i * 60 + rng.randrange(20),
    ) for i in range(n)]


def main():
    rng = random.Random(20261122)
    for case in range(30):
        events = toy_events(rng)
        raw = []
        for i in range(len(events)):
            for j in range(i + 1, len(events)):
                if rng.random() < 0.32:
                    raw.append((i, j, 0.4 + 0.6 * rng.random()))
        packed = R.PackedEdges()
        for edge in raw:
            packed.append(edge)
        assert list(packed) == raw
        assert P.clusters_from_edges(len(events), raw, 0.35) == \
               P.clusters_from_edges(len(events), packed, 0.35)
        seeds = list(range(0, len(events), 3))
        for beam in (2, 8):
            expected = P.beam_search(events, raw, None, theta=0.35,
                                     beam=beam, max_len=6, seeds=seeds)
            actual = R.beam_search_packed(events, packed, None, theta=0.35,
                                          beam=beam, max_len=6, seeds=seeds)
            assert actual == expected, (case, beam, expected, actual)
    print("packed edge iteration: OK")
    print("cluster equivalence over 30 seeded graphs: OK")
    print("beam-search equivalence over 30 seeded graphs at two beam widths: OK")


if __name__ == "__main__":
    main()
