"""Semi-synthetic major-event cybersecurity assurance benchmark generator.

The benchmark ("MEGA-Bench") simulates one 76-day multi-domain assurance
operation.  Aggregate calibration anchors (channel mix, noise dominance,
TI coverage ~33.6% malicious / ~11.6% confirmed-benign, first-seen ratio
~41.7%, cross-domain IP overlap, attacker infrastructure reuse) follow the
anonymised statistics of a real operation; individual records are fully
synthetic and reproducible from a seed.

Ground truth is defined at the *behaviour* level: one behaviour is one
semantic action of an attacker campaign or of a background/noise actor,
observed by 1..k sensor channels.  Raw channel records carry a reversible
link to their behaviour, mirroring the provenance requirement of the
unified event model.
"""
from __future__ import annotations

import hashlib
import random
import zlib
from dataclasses import dataclass, field

import config as C

# ----------------------------------------------------------------------- --
#  Vocabularies
# ----------------------------------------------------------------------- --
ZONES = ["dmz", "intranet", "cloud", "thirdparty", "iot"]
# network reachability between zones (bidirectional pairs unless noted)
ZONE_REACH = {
    "dmz": {"intranet", "cloud", "dmz", "iot"},
    "intranet": {"intranet", "dmz", "cloud", "thirdparty", "iot"},
    "cloud": {"intranet", "dmz", "cloud"},
    "thirdparty": {"intranet"},
    "iot": {"dmz", "intranet"},
}

CHANNELS = ["flow", "ids", "dns", "edr", "honeypot", "ticket"]
# per-channel clock skew bound (seconds) -- "time asynchrony"
CLOCK_SKEW = {"flow": 5, "ids": 20, "dns": 10, "edr": 60, "honeypot": 120, "ticket": 0}
# per-channel field-dropout rate -- "semantic heterogeneity / missing data"
DROPOUT = {"flow": 0.05, "ids": 0.08, "dns": 0.05, "edr": 0.12, "honeypot": 0.10, "ticket": 0.0}

STAGES = ["recon", "exploit", "c2", "lateral", "priv_esc", "exfil"]
# ATT&CK-style precedence: allowed forward transitions
STAGE_NEXT = {
    "recon": {"exploit"},
    "exploit": {"c2", "lateral", "priv_esc"},
    "c2": {"lateral", "priv_esc", "exfil"},
    "lateral": {"priv_esc", "exfil", "lateral"},
    "priv_esc": {"exfil", "lateral"},
    "exfil": set(),
}

EXPLOIT_RULES = [  # rule names echo the real operation's generated rules
    ("CGI-CMD-INJ", 0.9), ("WEBLOGIC-DESER", 0.95), ("ES-RCE", 0.9),
    ("LOG4SHELL-JNDI", 0.95), ("SQLI-UNION", 0.8), ("FILE-UPLOAD-WEB", 0.8),
]
SCAN_RULES = [("PORT-SCAN", 0.3), ("SERVICE-PROBE", 0.35), ("WEB-CRAWL", 0.25)]
CONFIG_RULES = [("CERT-EXPIRY-WARN", 0.2), ("BACKUP-FAILED", 0.2),
                ("LOGIN-LOCKOUT", 0.3), ("FW-POLICY-DENY", 0.2)]

STAGE_SEVERITY = {"recon": 0.3, "exploit": 0.85, "c2": 0.8,
                  "lateral": 0.9, "priv_esc": 0.85, "exfil": 1.0}


def _ip(rng, prefix="203.0.113"):
    octs = prefix.split(".")[:3]
    while len(octs) < 3:
        octs.append(str(rng.randint(1, 254)))
    octs.append(str(rng.randint(1, 254)))
    return ".".join(octs)


def _sess(rng):
    return hashlib.md5(str(rng.random()).encode()).hexdigest()[:12]


# ----------------------------------------------------------------------- --
#  World: assets, intel, actors
# ----------------------------------------------------------------------- --
@dataclass
class Asset:
    aid: str
    domain: str
    zone: str
    role: str            # web / app / db / office / gateway / cloud-vm
    criticality: float
    exposed: bool
    vuln: tuple | None   # (rule, severity) or None
    deps: list = field(default_factory=list)


@dataclass
class Campaign:
    cid: str
    group: str
    domains: list
    is_effective: bool
    truncation: str                 # full / recon_only / exploit_fail
    behaviors: list = field(default_factory=list)   # ordered (bid, stage)
    attacker_ips: list = field(default_factory=list)
    c2_domains: list = field(default_factory=list)

    @property
    def stage_seq(self):
        out, seen = [], set()
        for _, st in self.behaviors:
            if st not in seen:
                out.append(st)
                seen.add(st)
        return out


@dataclass
class Behavior:
    bid: str
    channel: str | None
    stage: str | None
    cid: str | None
    actor: str                    # external ip / account / device
    kind: str                     # semantic action type
    t0: int
    t1: int
    src: str | None
    dst: str | None
    asset: str | None
    domain: str | None
    extra: dict = field(default_factory=dict)
    # raw channel records emitted for this behaviour
    records: list = field(default_factory=list)

    def add_record(self, channel, ts, fields, clock_conf=1.0):
        fields = dict(fields)
        fields.update(dict(channel=channel, ts=ts, bid=self.bid, clock_conf=clock_conf,
                           stage=self.stage, cid=self.cid, kind=self.kind))
        self.records.append(fields)


class World:
    """Assets, business dependencies, external actors and the TI feed."""

    def __init__(self, rng: random.Random, n_ext: int):
        self.rng = rng
        self.assets: dict[str, Asset] = {}
        self._build_assets()
        self._build_actors(n_ext)
        self._build_intel()

    # ------------------------------------------------------------------ #
    def _build_assets(self):
        rng = self.rng
        aid = 0
        for dom in C.DOMAINS:
            # business systems: web -> app -> db, plus cloud & third-party hops
            for sys_i in range(rng.randint(3, 5)):
                roles = [("web", "dmz", True), ("app", "intranet", False),
                         ("db", "intranet", False)]
                if rng.random() < 0.5:                       # cloud-hosted system
                    roles.append(("app2", "cloud", False))
                if rng.random() < 0.35:                       # third-party supplier
                    roles.append(("supp", "thirdparty", False))
                prev = None
                for role, zone, exposed in roles:
                    aid += 1
                    a = Asset(f"A{aid:04d}", dom, zone, role,
                              criticality=round(rng.uniform(0.4, 1.0), 2)
                              if zone != "dmz" else round(rng.uniform(0.3, 0.7), 2),
                              exposed=exposed and role == "web",
                              vuln=None)
                    if a.exposed and rng.random() < 0.6:      # exposed & vulnerable
                        rule, sev = rng.choice(EXPLOIT_RULES)
                        a.vuln = (rule, sev)
                    if prev is not None:
                        a.deps.append(prev)
                        self.assets[prev].deps.append(a.aid)
                    self.assets[a.aid] = a
                    prev = a.aid
            # office terminals + iot gateways (lateral targets)
            for k in range(rng.randint(4, 8)):
                aid += 1
                self.assets[f"A{aid:04d}"] = Asset(
                    f"A{aid:04d}", dom, "intranet" if k % 2 else "iot", "office",
                    criticality=round(rng.uniform(0.2, 0.6), 2), exposed=False, vuln=None)
        self.zone_of = {a.aid: a.zone for a in self.assets.values()}
        self.dom_of = {a.aid: a.domain for a in self.assets.values()}

    # ------------------------------------------------------------------ #
    def _build_actors(self, n_ext):
        rng = self.rng
        # attacker groups (LAG-like): infrastructure pools, partially shared
        self.groups = {}
        for g in range(18):
            self.groups[f"LAG-{500+g}"] = dict(
                ips=set(), domains=set(),
                capability=rng.uniform(0.4, 1.0),
                dwell=rng.choice(["short", "long"]),
            )
        all_group_ips = []
        for gi, (gname, g) in enumerate(self.groups.items()):
            for _ in range(rng.randint(4, 10)):
                ip = _ip(rng, f"198.51.{gi % 20}")
                g["ips"].add(ip)
                all_group_ips.append(ip)
                if rng.random() < 0.25:                    # infrastructure reuse
                    self.groups[f"LAG-{500+rng.randrange(18)}"]["ips"].add(ip)
            for _ in range(2):
                g["domains"].add(f"cd{rng.randint(1000,9999)}.{rng.choice(['xyz','top','icu'])}.exe")

        self.ext_ips = dict()          # ip -> actor descriptor
        n_att = int(n_ext * 0.10)
        n_cdn = int(n_ext * C.TI_BENIGN_RATE * 1.6)
        n_scan = n_ext - n_att - n_cdn
        # attackers: mostly inside group pools, some first-seen fresh IPs
        pool_ips = list({ip for g in self.groups.values() for ip in g["ips"]})
        rng.shuffle(pool_ips)
        for i in range(n_att):
            ip = pool_ips[i % len(pool_ips)] if rng.random() < 0.7 else _ip(rng, "45.33")
            self.ext_ips[ip] = dict(kind="attacker", first_seen=rng.random() < 0.35)
        for _ in range(n_cdn):
            self.ext_ips[_ip(rng, "185.199")] = dict(kind="cdn", first_seen=False)
        for _ in range(n_scan):
            self.ext_ips[_ip(rng, "91.214")] = dict(
                kind="scanner", first_seen=rng.random() < C.FIRST_SEEN_RATE)
        # authorised penetration test (hard negative, ticket-backed)
        self.pentest_ips = set()
        for _ in range(max(3, n_ext // 1500)):
            ip = _ip(rng, "192.0.2")
            self.ext_ips[ip] = dict(kind="pentest", first_seen=False)
            self.pentest_ips.add(ip)

    # ------------------------------------------------------------------ #
    def _build_intel(self):
        """TI feed with coverage, confidence, source weights and expiry."""
        rng = self.rng
        self.intel = {}
        for ip, desc in self.ext_ips.items():
            r = rng.random()
            if desc["kind"] == "attacker":
                verdict = "malicious" if r < 0.62 else "unknown"   # partial coverage
                conf = rng.uniform(0.6, 0.95)
            elif desc["kind"] == "cdn":
                verdict = "benign" if r < 0.7 else "unknown"
                conf = rng.uniform(0.5, 0.9)
            else:  # scanners: mostly unknown; 33.6%-anchored malicious share
                verdict = "malicious" if r < C.TI_MALICIOUS_RATE else "unknown"
                conf = rng.uniform(0.4, 0.8)
            expiry = int(rng.uniform(0.3, 1.6) * C.OP_SECONDS) if rng.random() < 0.3 else C.OP_SECONDS * 2
            self.intel[ip] = dict(verdict=verdict, confidence=round(conf, 2),
                                  src_w=rng.choice([0.6, 0.8, 1.0]),
                                  ts_seen=int(rng.uniform(0, C.OP_SECONDS * 0.5)),
                                  expiry=expiry)
        for gname, g in self.groups.items():
            for d in g["domains"]:
                self.intel[d] = dict(verdict="malicious", confidence=rng.uniform(0.5, 0.9),
                                     src_w=0.8, ts_seen=0,
                                     expiry=C.OP_SECONDS * 2)

    # ------------------------------------------------------------------ #
    def group_of(self, ip):
        for gname, g in self.groups.items():
            if ip in g["ips"]:
                return gname
        return None

    def reachable(self, a1, a2):
        z1, z2 = self.zone_of[a1], self.zone_of[a2]
        return z2 in ZONE_REACH.get(z1, set())


# ----------------------------------------------------------------------- --
#  Behaviour emission helpers
# ----------------------------------------------------------------------- --
class Emitter:
    def __init__(self, world: World, rng: random.Random):
        self.w = world
        self.rng = rng
        self.behaviors: list[Behavior] = []
        self._n = 0

    def beh(self, *, stage=None, cid=None, kind=None, t0=0, t1=None, src=None,
            dst=None, asset=None, domain=None, actor=None, extra=None) -> Behavior:
        self._n += 1
        b = Behavior(f"B{self._n:06d}", None, stage, cid, actor or src or "-",
                     kind, t0, t1 if t1 is not None else t0, src, dst, asset,
                     domain, extra or {})
        self.behaviors.append(b)
        return b

    # -- observation model: which channels see which behaviour -------------
    def observe(self, b: Behavior, channel_probs: dict[str, float]):
        rng = self.rng
        for ch, p in channel_probs.items():
            if rng.random() > p:
                continue
            skew = int(rng.gauss(0, CLOCK_SKEW[ch]))
            ts = max(0, min(C.OP_SECONDS - 1, int(rng.uniform(b.t0, b.t1)) + skew))
            f = {}
            if ch == "flow":
                f = dict(src=b.src, dst=b.dst, port=b.extra.get("port", 443),
                         proto=b.extra.get("proto", "tcp"),
                         bytes_=b.extra.get("bytes", rng.randint(200, 5000)),
                         dur=b.extra.get("dur", rng.uniform(0.1, 5)))
                if rng.random() < DROPOUT[ch]:
                    f["src"] = None
            elif ch == "ids":
                f = dict(src=b.src, dst=b.dst, rule=b.extra.get("rule", "GENERIC"),
                         severity=b.extra.get("severity", 0.3),
                         sig_id=abs(zlib.crc32((b.bid + ch).encode()) % 90000))
                if rng.random() < DROPOUT[ch]:
                    f["dst"] = None
            elif ch == "dns":
                f = dict(src=b.src, domain=b.extra.get("domain", "-"),
                         resp=b.dst, qtype="A")
            elif ch == "edr":
                f = dict(asset=b.asset, proc=b.extra.get("proc", "-"),
                         user=b.extra.get("user", "-"), cmdline=b.extra.get("cmdline", ""),
                         action=b.extra.get("action", "proc"))
                if rng.random() < DROPOUT[ch]:
                    f["asset"] = None
            elif ch == "honeypot":
                f = dict(src=b.src, decoy=b.extra.get("decoy", f"H{self.rng.randint(1,40)}"),
                         sensor=b.extra.get("sensor", "web"),
                         payload=b.extra.get("payload", "GET /"),
                         rule=b.extra.get("rule", "DECOY-HIT"),
                         severity=b.extra.get("severity", 0.3))
            elif ch == "ticket":
                f = dict(src=b.src, ticket=b.extra.get("ticket", "-"),
                         authorized=b.extra.get("authorized", True),
                         analyst=b.extra.get("analyst", "soc"))
            b.add_record(ch, ts, f, clock_conf=round(rng.uniform(0.6, 1.0), 2))


# ----------------------------------------------------------------------- --
#  Campaign construction
# ----------------------------------------------------------------------- --
def _campaign_path(w: World, rng) -> list[str]:
    """Choose an attack entry asset and a lateral path."""
    dom = rng.choice(C.DOMAINS)
    entries = [a for a in w.assets.values()
               if a.domain == dom and a.exposed and a.vuln]
    if not entries:
        entries = [a for a in w.assets.values() if a.exposed]
    entry = rng.choice(entries).aid
    # walk dependency / reachability edges to build a 2-4 hop lateral path
    path, cur = [entry], entry
    for _ in range(rng.randint(1, 3)):
        nxt = [d for d in w.assets[cur].deps if w.zone_of[d] in
               ZONE_REACH[w.zone_of[cur]]]
        if not nxt:
            break
        cur = rng.choice(nxt)
        if cur in path:
            break
        path.append(cur)
    # 25%: cross-domain continuation through cloud / third-party hop
    if rng.random() < 0.25:
        other = rng.choice([d for d in C.DOMAINS if d != dom])
        hops = [a for a in w.assets.values()
                if a.domain == other and a.zone in ("cloud", "intranet", "thirdparty")]
        if hops:
            hop = rng.choice(hops).aid
            path.extend([hop])
    return path


def emit_campaign(w: World, em: Emitter, rng, cid: str) -> Campaign:
    gname = rng.choice(list(w.groups))
    g = w.groups[gname]
    att_ips = rng.sample(sorted(g["ips"]), k=min(2, len(g["ips"])))
    if rng.random() < 0.4:                       # first-seen fresh IP
        att_ips[0] = _ip(rng, "45.33")
    c2dom = rng.choice(sorted(g["domains"]))
    path = _campaign_path(w, rng)
    domains = sorted({w.dom_of[a] for a in path})
    dwell = g["dwell"]

    r = rng.random()
    if r < C.P_RECON_ONLY:
        trunc = "recon_only"
    elif r < C.P_RECON_ONLY + C.P_STOP_AFTER_EXPLOIT:
        trunc = "exploit_fail"
    else:
        trunc = "full"
    is_eff = trunc != "recon_only" and trunc != "exploit_fail"

    camp = Campaign(cid, gname, domains, is_eff, trunc, [], att_ips, [c2dom])
    t = int(rng.uniform(0.05, 0.9) * C.OP_SECONDS)

    def gap(lo, hi):
        return int(rng.uniform(lo, hi))

    # ---- stage: recon ----------------------------------------------------
    recon_dst = rng.choice([p for p in path] + [a.aid for a in w.assets.values()
                                                if a.domain == domains[0]][:6])
    for _ in range(rng.randint(1, 3)):
        b = em.beh(stage="recon", cid=cid, kind="scan", t0=t, t1=t + gap(120, 1800),
                   src=att_ips[0], dst=recon_dst, asset=recon_dst,
                   domain=w.dom_of.get(recon_dst), actor=att_ips[0],
                   extra=dict(rule=rng.choice(SCAN_RULES)[0], severity=0.3,
                              port=rng.choice([22, 80, 443, 3389, 9200]),
                              bytes=rng.randint(100, 2000)))
        camp.behaviors.append((b.bid, "recon"))
        em.observe(b, dict(flow=0.95, ids=0.7, honeypot=0.35))
    t += gap(600, 4 * 3600)
    if trunc == "recon_only":
        camp.behaviors.sort(key=lambda x: em_next_t(em, x[0]))
        return camp

    # ---- stage: exploit --------------------------------------------------
    entry = path[0]
    rule, sev = w.assets[entry].vuln or rng.choice(EXPLOIT_RULES)
    if trunc == "exploit_fail":
        sev *= 0.5
    b = em.beh(stage="exploit", cid=cid, kind="exploit_attempt", t0=t, t1=t + 60,
               src=att_ips[0], dst=entry, asset=entry, domain=w.dom_of[entry],
               actor=att_ips[0],
               extra=dict(rule=rule, severity=sev, port=rng.choice([80, 443, 9200, 7001]),
                          bytes=rng.randint(400, 4000), proto="tcp"))
    camp.behaviors.append((b.bid, "exploit"))
    em.observe(b, dict(flow=0.9, ids=0.85, edr=0.4))
    if trunc == "exploit_fail":
        return camp
    t += gap(120, 3600)

    # ---- stage: c2 --------------------------------------------------------
    b = em.beh(stage="c2", cid=cid, kind="c2_beacon", t0=t, t1=t + gap(3600, 8 * 3600),
               src=att_ips[-1], dst=entry, asset=entry, domain=w.dom_of[entry],
               actor=att_ips[-1],
               extra=dict(domain=c2dom, port=443, proto="tcp",
                          bytes=rng.randint(50, 800), dur=1.0))
    camp.behaviors.append((b.bid, "c2"))
    em.observe(b, dict(flow=0.8, dns=0.85, ids=0.3))
    t += (gap(6 * 3600, 72 * 3600) if dwell == "long" else gap(600, 4 * 3600))

    # ---- stage: lateral ----------------------------------------------------
    prev = entry
    for hop_i, hop in enumerate(path[1:], 1):
        b = em.beh(stage="lateral", cid=cid, kind="remote_session",
                   t0=t, t1=t + gap(60, 1800), src=prev, dst=hop, asset=hop,
                   domain=w.dom_of[hop], actor=att_ips[-1],
                   extra=dict(port=rng.choice([3389, 22, 445]), bytes=rng.randint(10000, 90000),
                              proto="tcp", dur=rng.uniform(5, 300)))
        camp.behaviors.append((b.bid, "lateral"))
        em.observe(b, dict(flow=0.9, edr=0.6, ids=0.35))
        t += gap(300, 7200)
        b = em.beh(stage="lateral", cid=cid, kind="susp_proc", t0=t, t1=t + 30,
                   src=None, dst=hop, asset=hop, domain=w.dom_of[hop],
                   actor=f"svc-{hop}",
                   extra=dict(proc=rng.choice(["psexec.exe", "ssh", "wmic.exe", "smbclient"]),
                              action="proc", user="admin"))
        camp.behaviors.append((b.bid, "lateral"))
        em.observe(b, dict(edr=0.85))
        prev = hop

    # ---- stage: privilege escalation / discovery ---------------------------
    b = em.beh(stage="priv_esc", cid=cid, kind="priv_cmd", t0=t, t1=t + 120,
               src=None, dst=prev, asset=prev, domain=w.dom_of[prev], actor=f"svc-{prev}",
               extra=dict(proc="cmd.exe",
                          cmdline=rng.choice(["whoami /priv", "net group \"Domain Admins\"",
                                              "mimikatz sekurlsa::logonpasswords"]),
                          action="cmd", user="SYSTEM"))
    camp.behaviors.append((b.bid, "priv_esc"))
    em.observe(b, dict(edr=0.9))
    t += gap(300, 3600)

    # ---- stage: exfiltration ------------------------------------------------
    exfil_ip = att_ips[-1]
    b = em.beh(stage="exfil", cid=cid, kind="data_transfer", t0=t, t1=t + gap(600, 7200),
               src=prev, dst=exfil_ip, asset=prev, domain=w.dom_of[prev],
               actor=att_ips[-1],
               extra=dict(port=443, bytes=rng.randint(5000000, 200000000), proto="tcp",
                          dur=rng.uniform(60, 3600)))
    camp.behaviors.append((b.bid, "exfil"))
    em.observe(b, dict(flow=0.9, ids=0.5, edr=0.3))
    b = em.beh(stage="exfil", cid=cid, kind="archive_staged", t0=t - 300, t1=t,
               src=None, dst=prev, asset=prev, domain=w.dom_of[prev], actor=f"svc-{prev}",
               extra=dict(proc="rar.exe", action="file",
                          cmdline="rar a -m5 staged.7z .\\docs", user="SYSTEM"))
    camp.behaviors.append((b.bid, "exfil"))
    em.observe(b, dict(edr=0.75))
    return camp


def em_next_t(em: Emitter, bid):
    for b in em.behaviors:
        if b.bid == bid:
            return b.t0
    return 0


# ----------------------------------------------------------------------- --
#  Noise emitters
# ----------------------------------------------------------------------- --
def emit_noise(w: World, em: Emitter, rng, factor: float):
    scanners = [ip for ip, d in w.ext_ips.items() if d["kind"] == "scanner"]
    cdns = [ip for ip, d in w.ext_ips.items() if d["kind"] == "cdn"]
    # ---- internet background scanning (dominant noise) --------------------
    n_burst = int(len(scanners) * factor * rng.uniform(1.2, 1.8))
    exposed = [a for a in w.assets.values() if a.exposed]
    for _ in range(n_burst):
        ip = rng.choice(scanners)
        # cross-domain benign overlap: a third of bursts hit 2-3 domains
        doms = rng.sample(C.DOMAINS, k=rng.choice([1, 1, 2, 3]))
        t = int(rng.uniform(0, C.OP_SECONDS - 7200))
        for dom in doms:
            cand = [a.aid for a in exposed if a.domain == dom] or [a.aid for a in exposed]
            tgt = rng.choice(cand)
            sev, rule = 0.3, rng.choice(SCAN_RULES)[0]
            if rng.random() < 0.08:              # scanner trips a severe rule
                sev, rule = rng.choice([(0.85, "AGGR-SCAN-EVASIVE"),
                                        (rng.uniform(0.9, 0.98), "EXPLOIT-KNOWN-CVE-PROBE")])
            b = em.beh(kind="scan", t0=t, t1=t + int(rng.uniform(60, 1800)),
                       src=ip, dst=tgt, asset=tgt, domain=dom, actor=ip,
                       extra=dict(rule=rule, severity=sev,
                                  port=rng.choice([22, 80, 443, 3389]),
                                  bytes=rng.randint(100, 1500)))
            em.observe(b, dict(flow=0.9, ids=0.5, honeypot=0.3))
    # ---- CDN / monitoring probes against honeypots ------------------------
    for ip in cdns[: int(len(cdns) * factor * 0.8)]:
        for _ in range(rng.randint(1, 3)):
            t = int(rng.uniform(0, C.OP_SECONDS))
            extra = dict(payload="GET /favicon.ico", sensor="web")
            if rng.random() < 0.06:              # crawler trips decoy alert
                extra.update(payload="GET /admin/config.bak",
                             severity=round(rng.uniform(0.8, 0.95), 2),
                             rule="DECOY-SENSITIVE-ACCESS")
            b = em.beh(kind="probe", t0=t, t1=t + 60, src=ip, dst=None, asset=None,
                       domain=rng.choice(C.DOMAINS), actor=ip, extra=extra)
            em.observe(b, dict(honeypot=0.95))
    # ---- recurring configuration-error alerts ------------------------------
    for _ in range(int(60 * factor)):
        dom = rng.choice(C.DOMAINS)
        tgt = rng.choice([a.aid for a in w.assets.values() if a.domain == dom])
        rule, sev = rng.choice(CONFIG_RULES)
        if rule == "LOGIN-LOCKOUT" and rng.random() < 0.15:
            sev = 0.8
        t0 = int(rng.uniform(0, C.OP_SECONDS * 0.5))
        for t in range(t0, C.OP_SECONDS, int(rng.uniform(6, 36) * 3600)):
            b = em.beh(kind="config_err", t0=t, t1=t + 30, src=None, dst=tgt,
                       asset=tgt, domain=dom, actor=f"dev-{tgt}",
                       extra=dict(rule=rule, severity=sev))
            em.observe(b, dict(ids=0.95, flow=0.2))
    # ---- authorised penetration test (hard negative) ------------------------
    for ip in w.pentest_ips:
        dom = rng.choice(C.DOMAINS)
        tgt = rng.choice([a.aid for a in w.assets.values()
                          if a.domain == dom and a.exposed])
        t = int(rng.uniform(0.1, 0.9) * C.OP_SECONDS)
        for stage, kind, extra in [
            ("recon", "scan", dict(rule="PORT-SCAN", severity=0.3, port=443,
                                   bytes=800, proto="tcp")),
            ("exploit", "exploit_attempt", dict(rule="SQLI-UNION", severity=0.4,
                                                port=443, bytes=2000, proto="tcp")),
        ]:
            b = em.beh(stage="pentest_" + stage, cid=None, kind=kind, t0=t, t1=t + 600,
                       src=ip, dst=tgt, asset=tgt, domain=dom, actor=ip, extra=extra)
            em.observe(b, dict(flow=0.9, ids=0.8))
            t += 1800
        # the ticket channel records the authorisation
        b = em.beh(kind="auth_ticket", t0=t, t1=t, src=ip, dst=tgt, asset=tgt,
                   domain=dom, actor="soc",
                   extra=dict(ticket=f"T{rng.randint(1000,9999)}", authorized=True))
        em.observe(b, dict(ticket=1.0))
    # ---- benign backup / sync jobs (exfil look-alikes) -----------------------
    for _ in range(int(25 * factor)):
        dom = rng.choice(C.DOMAINS)
        srcs = [a.aid for a in w.assets.values()
                if a.domain == dom and a.role in ("db", "app")]
        if not srcs:
            continue
        src_a = rng.choice(srcs)
        t0 = int(rng.uniform(0, C.OP_SECONDS * 0.4))
        for t in range(t0, C.OP_SECONDS, int(rng.uniform(12, 48) * 3600)):
            extra = dict(port=873, bytes=rng.randint(5000000, 90000000),
                         proto="tcp", dur=rng.uniform(300, 3600))
            if rng.random() < 0.20:              # backup trips exfil suspect rule
                extra.update(rule="DATA-EXFIL-SUSPECT",
                             severity=round(rng.uniform(0.85, 0.97), 2))
            b = em.beh(kind="backup_transfer", t0=t, t1=t + int(rng.uniform(600, 7200)),
                       src=src_a, dst=f"bak-{dom}", asset=src_a, domain=dom,
                       actor=f"job-{src_a}", extra=extra)
            em.observe(b, dict(flow=0.9, ids=0.25))
    # ---- periodic DNS / domain noise -----------------------------------------
    for _ in range(int(40 * factor)):
        dom = rng.choice(C.DOMAINS)
        srcs = [a.aid for a in w.assets.values() if a.domain == dom and a.zone == "dmz"]
        if not srcs:
            continue
        src_a = rng.choice(srcs)
        t0 = int(rng.uniform(0, C.OP_SECONDS * 0.5))
        d = f"cdn{rng.randint(1,99)}.provider-{rng.randint(1,8)}.com"
        for t in range(t0, C.OP_SECONDS, int(rng.uniform(2, 12) * 3600)):
            b = em.beh(kind="dns_query", t0=t, t1=t + 5, src=src_a, dst=None,
                       asset=src_a, domain=dom, actor=f"svc-{src_a}",
                       extra=dict(domain=d))
            em.observe(b, dict(dns=0.95))
    # ---- failed exploitation attempts by low-capability actors --------------
    n_attempt = int(len(scanners) * 0.02 * factor)
    for _ in range(n_attempt):
        ip = rng.choice(scanners)
        tgt = rng.choice(exposed).aid
        if not w.assets[tgt].vuln:
            continue
        t = int(rng.uniform(0, C.OP_SECONDS - 600))
        rule, sev = w.assets[tgt].vuln
        b = em.beh(kind="exploit_attempt", t0=t, t1=t + 30, src=ip, dst=tgt,
                   asset=tgt, domain=w.dom_of[tgt], actor=ip,
                   extra=dict(rule=rule, severity=sev * 0.5, port=80, bytes=900,
                              proto="tcp"))
        em.observe(b, dict(flow=0.85, ids=0.7))


# ----------------------------------------------------------------------- --
#  Dataset assembly
# ----------------------------------------------------------------------- --
@dataclass
class Dataset:
    seed: int
    scale: str
    world: World
    behaviors: list
    campaigns: dict          # cid -> Campaign
    records: list            # raw channel records

    def raw_records(self):
        out = []
        for b in self.behaviors:
            out.extend(b.records)
        return out


def generate(seed: int, scale: str) -> Dataset:
    sc = C.SCALES[scale]
    rng = random.Random(seed * 1000 + zlib.crc32(scale.encode()) % 97)
    w = World(rng, sc["n_ext"])
    em = Emitter(w, rng)
    campaigns = {}
    for i in range(sc["n_campaigns"]):
        cid = f"C{i:04d}"
        campaigns[cid] = emit_campaign(w, em, rng, cid)
    emit_noise(w, em, rng, sc["noise_factor"])
    records = []
    for b in em.behaviors:
        records.extend(b.records)
    records.sort(key=lambda r: (r["ts"], r["channel"]))
    return Dataset(seed, scale, w, sorted(em.behaviors, key=lambda b: b.t0),
                   campaigns, records)
