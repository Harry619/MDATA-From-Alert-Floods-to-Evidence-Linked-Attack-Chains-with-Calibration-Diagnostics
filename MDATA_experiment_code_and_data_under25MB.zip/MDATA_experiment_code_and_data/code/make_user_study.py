"""Enhancement item (8): analyst user-study materials.

Generates, from MEGA-Bench (S2, seed 11):
  user_study/protocol.md               -- within-subject study protocol
  user_study/cases/CASE_XX_A.md        -- control condition (headline +
                                           raw behaviour timeline only)
  user_study/cases/CASE_XX_B.md        -- treatment condition (+ evidence
                                           card, six-dimension risk, band,
                                           feature contributions)
  user_study/response_sheet.csv        -- per-case response template
  code/analyze_user_study.py is the companion analysis script.

Stratification: 8 effective / 6 recon-only / 4 exploit-fail / 2
pentest-flagged-noise-style hard negatives (ticket-authorized) taken as
campaigns allow.
"""
from __future__ import annotations

import json
import os

import config as C
import datagen
import pipeline
from run_agents import case_card

STUDY_DIR = os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "user_study")
WANT = [("full", 8), ("recon_only", 6), ("exploit_fail", 4)]


def pick_cases(ds):
    picked = []
    for trunc, n in WANT:
        picked += [c for c in ds.campaigns.values()
                   if c.truncation == trunc][:n]
    return picked[:20]


def timeline(ds, camp, meta):
    behs = {b.bid: b for b in ds.behaviors}
    lines = []
    for bid, st in camp.behaviors:
        b = behs[bid]
        ch = sorted({r["channel"] for r in b.records})
        lines.append(f"- [{st}] t={b.t0}..{b.t1} domain={b.domain} "
                     f"channels={','.join(ch)} src={b.src} dst={b.dst} "
                     f"asset={b.asset}")
    return lines


def write_case(path, cid, cond, headline, tl, extra):
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# 案例 {cid}（条件 {cond}）\n\n**告警标题**：{headline}\n\n"
                f"## 行为时间线\n" + "\n".join(tl) + "\n")
        if extra:
            f.write("\n## 系统研判辅助输出\n" + extra)
        f.write("\n\n---\n请判断:\n"
                "1. 结论(单选): A=有效攻击 / B=高风险侦察待核验 / "
                "C=疑似失败尝试 / D=授权测试或误报\n"
                "2. 置信度(1-5):\n"
                "3. 关键依据(一句话):\n")


def main():
    os.makedirs(os.path.join(STUDY_DIR, "cases"), exist_ok=True)
    ds = datagen.generate(11, "S2")
    res = pipeline.run_mdata(ds)
    camps = pick_cases(ds)
    rows = ["case_id,condition,verdict,confidence,key_evidence,"
            "start_time,end_time,analyst_id"]
    for i, camp in enumerate(camps):
        cid = f"CASE_{i:02d}_{camp.cid}"
        headline = (f"多阶段可疑活动告警:{','.join(camp.domains)} 域"
                    f"外部源主机触发多条规则")
        tl = timeline(ds, camp, res["meta"])
        write_case(os.path.join(STUDY_DIR, "cases", f"{cid}_A.md"),
                   cid, "A(仅时间线)", headline, tl, None)
        card, intel = case_card(ds, camp)
        R, U, dims = res["meta"].get(camp.behaviors[0][0], (None,)*3)
        extra = (f"**证据卡**\n```\n{card}\n```\n**外部情报**: "
                 f"{'; '.join(intel) if intel else '无'}\n\n"
                 f"**六维风险**: " +
                 ", ".join(f"{k}={v:.2f}" for k, v in dims.items()) +
                 f"\n**综合分 R={R:.2f}, 不确定区间 "
                 f"[{max(0, R - 0.2 * U):.2f}, {min(1, R + 0.2 * U):.2f}]"
                 f"**（下界≥0.70 进入高风险带）\n")
        write_case(os.path.join(STUDY_DIR, "cases", f"{cid}_B.md"),
                   cid, "B(时间线+系统研判输出)", headline, tl, extra)
        rows.append(f"{cid},A,,,,,")
        rows.append(f"{cid},B,,,,,")
    with open(os.path.join(STUDY_DIR, "response_sheet.csv"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(rows) + "\n")
    print(f"wrote {len(camps)} cases x 2 conditions to {STUDY_DIR}")
    return camps


if __name__ == "__main__":
    main()
