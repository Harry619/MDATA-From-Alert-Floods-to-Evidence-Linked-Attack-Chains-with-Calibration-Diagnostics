"""Evaluation: threshold calibration, detection / ranking / chain metrics,
stratified bootstrap CIs and paired significance tests.

Split protocol: campaigns are hashed 40/60 into calibration / test sets;
noise behaviours are split with the same ratio by behaviour id.  Every
method is calibrated (threshold only) on the calibration split and scored
on the test split, mirroring the chapter's fair-comparison requirements.

All ranking metrics break score ties by behaviour index (deterministic,
label-blind) to avoid optimistic tie-ordering.
"""
from __future__ import annotations

import hashlib

import numpy as np

import config as C

RECALL_FLOOR = 0.90          # calibration constraint of the chapter
EPS = 1e-9


# ----------------------------------------------------------------- split --
def _h(s):
    return int(hashlib.md5(s.encode()).hexdigest()[:8], 16) / 0xFFFFFFFF


def make_split(ds):
    train_c = {cid for cid in ds.campaigns if _h("c" + cid) < 0.4}
    test_c = set(ds.campaigns) - train_c
    train_b = {b.bid for b in ds.behaviors if _h("b" + b.bid) < 0.4}
    test_b = {b.bid for b in ds.behaviors if b.bid not in train_b}
    return train_c, test_c, train_b, test_b


def labels_of(ds):
    eff = {cid for cid, c in ds.campaigns.items() if c.is_effective}
    lab = {}
    for c in ds.campaigns.values():
        for bid, _ in c.behaviors:
            lab[bid] = 1 if c.cid in eff else 0
    for b in ds.behaviors:
        lab.setdefault(b.bid, 0)
    return lab, eff


# ---------------------------------------------------------- calibration --
def calibrate(scores, labels, train_bids, mode="maxf1"):
    """Primary operating point: max-F1 threshold on the calibration split.

    mode='constrained' returns the precision-maximising threshold subject
    to recall >= RECALL_FLOOR (reported as the secondary operating point).
    Cuts are only taken at distinct-score boundaries; the threshold is
    epsilon-below the boundary score so ties are included.
    """
    pairs = sorted([(scores.get(b, 0.0), labels[b]) for b in train_bids],
                   reverse=True)
    n_pos = sum(y for _, y in pairs)
    if n_pos == 0:
        return 0.5
    tp = fp = 0
    best_f1, f1_thr = -1.0, 0.5
    best_p, cons_thr = -1.0, None
    for i, (s, y) in enumerate(pairs):
        tp += y
        fp += 1 - y
        prec = tp / (tp + fp)
        rec = tp / n_pos
        f1 = 2 * prec * rec / max(1e-9, prec + rec)
        if f1 > best_f1:
            best_f1, f1_thr = f1, s - EPS
        if i + 1 < len(pairs) and pairs[i + 1][0] == s:
            continue                     # only cut at distinct-score bounds
        if rec >= RECALL_FLOOR and prec > best_p:
            best_p, cons_thr = prec, s - EPS
    return cons_thr if (mode == "constrained" and cons_thr is not None) \
        else f1_thr


# ---------------------------------------------------- vectorized metrics --
def _order(sc, lb):
    """Deterministic label-blind descending order (tie-break by index)."""
    return np.lexsort((np.arange(len(sc)), -sc))


def prf_vec(sc, lb, det):
    tp = int(np.sum(det & (lb == 1)))
    fp = int(np.sum(det & (lb == 0)))
    fn = int(np.sum(~det & (lb == 1)))
    p = tp / max(1, tp + fp)
    r = tp / max(1, tp + fn)
    return p, r, 2 * p * r / max(1e-9, p + r)


def ap_vec(sc, lb):
    n_pos = int(lb.sum())
    if n_pos == 0 or n_pos == len(lb):
        return np.nan
    o = _order(sc, lb)
    y = lb[o]
    tp_cum = np.cumsum(y)
    prec_at_hit = tp_cum[y == 1] / np.arange(1, len(y) + 1)[y == 1]
    return float(prec_at_hit.sum() / n_pos)


def ndcg_vec(sc, lb, k=50):
    o = _order(sc, lb)[:k]
    y = lb[o]
    dcg = float(np.sum(y / np.log2(np.arange(2, len(y) + 2))))
    ideal = np.sort(lb)[::-1][:k]
    idcg = float(np.sum(ideal / np.log2(np.arange(2, len(ideal) + 2))))
    return dcg / idcg if idcg > 0 else 0.0


def topk_vec(sc, lb, k=100):
    o = _order(sc, lb)[:k]
    return float(lb[o].mean()) if len(o) else 0.0


def first_hit_vec(sc, lb):
    o = _order(sc, lb)
    hits = np.nonzero(lb[o] == 1)[0]
    return int(hits[0]) + 1 if len(hits) else len(lb)


# ------------------------------------------------------------ chains ------
def _edit_distance(a, b):
    n, m = len(a), len(b)
    dp = list(range(m + 1))
    for i in range(1, n + 1):
        prev, dp[0] = dp[0], i
        for j in range(1, m + 1):
            cur = dp[j]
            dp[j] = min(dp[j] + 1, dp[j - 1] + 1,
                        prev + (a[i - 1] != b[j - 1]))
            prev = cur
    return dp[m]


def chain_metrics(ds, pred_chains, test_cids):
    """Node/edge F1, normalised stage edit distance, path completeness."""
    beh_stage = {}
    for c in ds.campaigns.values():
        for bid, st in c.behaviors:
            beh_stage[bid] = st if not str(st).startswith("pentest") else "recon"
    for b in ds.behaviors:
        beh_stage.setdefault(b.bid, "ops")
    gt = {cid: [bid for bid, _ in c.behaviors]
          for cid, c in ds.campaigns.items()
          if cid in test_cids and c.is_effective}
    pred = [list(dict.fromkeys(ch)) for ch in pred_chains if len(ch) >= 2]
    tp_n, completed, edit_ds, gt_nodes_total = 0, 0, [], 0
    for cid, gt_seq in gt.items():
        gt_set = set(gt_seq)
        gt_nodes_total += len(gt_set)
        best, best_j = None, 0.0
        for ch in pred:
            j = len(gt_set & set(ch)) / len(gt_set | set(ch))
            if j > best_j:
                best, best_j = ch, j
        if best is not None and len(gt_set & set(best)) >= 0.5 * len(gt_set):
            completed += 1
            tp_n += len(gt_set & set(best))
            gs = [beh_stage.get(b, "ops") for b in gt_seq]
            ps = [beh_stage.get(b, "ops") for b in best if b in gt_set]
            if ps:
                edit_ds.append(_edit_distance(gs, ps) / max(1, len(gs)))
    test_eff_bids = {b for c in ds.campaigns.values()
                     if c.cid in test_cids and c.is_effective
                     for b, _ in c.behaviors}
    pred_test = [ch for ch in pred if set(ch) & test_eff_bids]
    pred_nodes_all = len({b for ch in pred_test for b in ch})
    node_p = tp_n / max(1, pred_nodes_all)
    node_r = tp_n / max(1, gt_nodes_total)
    node_f1 = 2 * node_p * node_r / max(1e-9, node_p + node_r)
    gt_edges = {(a, b) for seq in gt.values() for a, b in zip(seq, seq[1:])}
    pred_edges = {(a, b) for ch in pred_test for a, b in zip(ch, ch[1:])}
    e_tp = len(gt_edges & pred_edges)
    e_p = e_tp / max(1, len(pred_edges))
    e_r = e_tp / max(1, len(gt_edges))
    e_f1 = 2 * e_p * e_r / max(1e-9, e_p + e_r)
    return dict(node_f1=node_f1, node_p=node_p, node_r=node_r,
                edge_f1=e_f1, edge_p=e_p, edge_r=e_r,
                stage_edit=float(np.mean(edit_ds)) if edit_ds else 1.0,
                completeness=completed / max(1, len(gt)),
                n_gt_chains=len(gt), n_pred_chains=len(pred_test))


# ----------------------------------------------------------- bootstrap ----
def bootstrap_ci(sc, lb, det, tm, units_idx, metric="f1", b=None, seed=0):
    """Stratified bootstrap over units (campaigns + noise chunks).

    Full-population arrays plus a test mask; each resample keeps only
    test-split behaviours before computing the metric.
    """
    rng = np.random.default_rng(seed)
    b = b or C.BOOTSTRAP_B
    vals = []
    for _ in range(b):
        pick = rng.integers(len(units_idx), size=len(units_idx))
        idx = np.unique(np.concatenate([units_idx[p] for p in pick]))
        idx = idx[tm[idx]]
        if len(idx) == 0:
            continue
        s, l, d = sc[idx], lb[idx], det[idx]
        if metric == "f1":
            vals.append(prf_vec(s, l, d)[2])
        elif metric == "precision":
            vals.append(prf_vec(s, l, d)[0])
        elif metric == "recall":
            vals.append(prf_vec(s, l, d)[1])
        elif metric == "prauc":
            v = ap_vec(s, l)
            if not np.isnan(v):
                vals.append(v)
        elif metric == "ndcg":
            vals.append(ndcg_vec(s, l, 50))
    if not vals:
        return (float("nan"), float("nan"))
    return (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5)))


def paired_wilcoxon(per_unit_a, per_unit_b):
    from scipy.stats import wilcoxon
    keys = [k for k in per_unit_a if k in per_unit_b]
    a = [per_unit_a[k] for k in keys]
    b = [per_unit_b[k] for k in keys]
    if len(keys) < 6 or all(x == y for x, y in zip(a, b)):
        return None, 1.0
    try:
        stat, p = wilcoxon(a, b, alternative="greater")
        return float(stat), float(p)
    except ValueError:
        return None, 1.0



def mcnemar_p(correct_a, correct_b):
    """Two-sided McNemar test on paired behaviour-level correctness."""
    b01 = int(np.sum(correct_a & ~correct_b))
    b10 = int(np.sum(~correct_a & correct_b))
    if b01 + b10 == 0:
        return 1.0, b01, b10
    from scipy.stats import binomtest
    p = float(binomtest(b01, b01 + b10, 0.5).pvalue)
    return p, b01, b10

def per_campaign_recall(ds, dets, test_cids):
    out = {}
    for cid, c in ds.campaigns.items():
        if cid not in test_cids or not c.is_effective:
            continue
        bids = [bid for bid, _ in c.behaviors]
        if bids:
            out[cid] = sum(1 for b in bids if b in dets) / len(bids)
    return out


# ------------------------------------------------------------- full pass --
class EvalContext:
    """Index arrays shared by all methods on one dataset."""

    def __init__(self, ds):
        self.ds = ds
        self.bids = [b.bid for b in ds.behaviors]
        self.bidx = {b: i for i, b in enumerate(self.bids)}
        labels, self.eff_c = labels_of(ds)
        self.labels = labels
        self.train_c, self.test_c, self.train_b, self.test_b = make_split(ds)
        self.lb = np.array([labels[b] for b in self.bids], dtype=np.int8)
        self.test_mask = np.array([b in self.test_b for b in self.bids])
        units, seen = [], set()
        for c in ds.campaigns.values():
            units.append([self.bidx[bid] for bid, _ in c.behaviors
                          if bid in self.bidx])
            seen.update(bid for bid, _ in c.behaviors)
        noise = [self.bidx[b.bid] for b in ds.behaviors if b.bid not in seen]
        for i in range(0, len(noise), 12):
            units.append(np.array(noise[i:i + 12]))
        self.units = [np.array(u) for u in units if len(u)]

    def evaluate(self, res):
        scores = res["scores"]
        sc = np.array([scores.get(b, 0.0) for b in self.bids])
        thr = calibrate(scores, self.labels, self.train_b)
        thr_c = calibrate(scores, self.labels, self.train_b, "constrained")
        det_all = sc >= thr
        det_c = sc >= thr_c
        m = dict(name=res.get("name", "?"), threshold=float(thr),
                 threshold_constrained=float(thr_c))
        tm = self.test_mask
        p, r, f1 = prf_vec(sc[tm], self.lb[tm], det_all[tm])
        m.update(precision=p, recall=r, f1=f1)
        pc, rc, fc = prf_vec(sc[tm], self.lb[tm], det_c[tm])
        m.update(precision_constrained=pc, recall_constrained=rc,
                 f1_constrained=fc, workload_constrained=float(det_c.mean()))
        m["prauc"] = ap_vec(sc[tm], self.lb[tm])
        m["ndcg@50"] = ndcg_vec(sc[tm], self.lb[tm], 50)
        m["topk@100"] = topk_vec(sc[tm], self.lb[tm], 100)
        m["first_hit"] = first_hit_vec(sc[tm], self.lb[tm])
        m["workload"] = float(det_all.mean())
        m.update(chain_metrics(self.ds, res["chains_by_bid"], self.test_c))
        m["f1_ci"] = bootstrap_ci(sc, self.lb, det_all, tm,
                                  self.units, "f1")
        m["prauc_ci"] = bootstrap_ci(sc, self.lb, det_all, tm,
                                     self.units, "prauc")
        m["ndcg_ci"] = bootstrap_ci(sc, self.lb, det_all, tm,
                                    self.units, "ndcg")
        dets = {b for b, i in self.bidx.items() if det_all[i]}
        m["per_campaign_recall"] = per_campaign_recall(self.ds, dets,
                                                       self.test_c)
        m["_sc"] = sc
        m["_correct_test"] = (det_all[tm] & (self.lb[tm] == 1)) |             (~det_all[tm] & (self.lb[tm] == 0))
        return m
