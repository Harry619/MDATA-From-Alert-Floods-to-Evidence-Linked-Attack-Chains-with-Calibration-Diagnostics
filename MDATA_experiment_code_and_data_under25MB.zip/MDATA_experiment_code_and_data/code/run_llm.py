"""Evidence-grounded LLM incident reporting + fabrication measurement.

Implements the chapter's LLM constraint: "when an LLM generates event
summaries or response suggestions, it must be constrained to retrieved
evidence and templated fields; the model must not fabricate IOCs, attack
conclusions or response outcomes; generated content is auxiliary
explanation, not independent evidence."

Protocol (per campaign case):
  - Build a structured evidence card from the ground-truth campaign:
    entities (IPs/domains/assets), stage timeline with channels and
    rules, TI verdicts, affected-asset criticality.
  - Two prompt modes:
      CONSTRAINED: evidence card + templated output fields + explicit
                   prohibition on introducing new IOCs/conclusions.
      UNCONSTRAINED: free-form "write an incident report" with only the
                   alert headline (simulating naive LLM usage).
  - Metrics (string-level, deterministic, no judge model):
      fabrication_rate : share of generated IOC-like tokens
                         (IPs/domains/CVE-like ids/asset ids) that do NOT
                         appear in the evidence card;
      conclusion_overreach : output asserts compromise ("compromised",
                         "breached", "exfiltrated") when the campaign is
                         recon-only / attempt-only ground truth;
      evidence_coverage : share of evidence entities actually mentioned;
      template_compliance : output contains the required fields.

Runs a local instruction model via transformers (Qwen2.5-7B-Instruct by
default); needs ~16-18 GB VRAM in bf16 (3090 fits).  Skips gracefully if
transformers/torch or the model are unavailable.
"""
from __future__ import annotations

import argparse
import json
import os
import re

import numpy as np

import config as C
import datagen

MODEL_ID = os.environ.get("MDATA_LLM", "Qwen/Qwen2.5-3B-Instruct")
IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
DOM_RE = re.compile(r"\b(?:[a-z0-9-]+\.)+(?:com|net|org|xyz|top|icu|exe)\b")
ASSET_RE = re.compile(r"\bA\d{4}\b")
COMPROMISE_WORDS = ("compromised", "breached", "exfiltrated",
                    "successfully exploited", "has infiltrated")


def evidence_card(ds, camp):
    behs = {b.bid: b for b in ds.behaviors}
    lines = []
    for bid, st in camp.behaviors:
        b = behs[bid]
        ch = sorted({r["channel"] for r in b.records})
        rules = sorted({r.get("rule") for r in b.records if r.get("rule")})
        ent = {b.src, b.dst, b.asset} - {None}
        lines.append(f"- stage={st} t={b.t0}..{b.t1} domain={b.domain} "
                     f"channels={','.join(ch)} rules={','.join(rules)} "
                     f"entities={','.join(str(x) for x in ent)}")
    intel = []
    camp_srcs = {behs[bid].src for bid, _ in camp.behaviors} - {None}
    for e in camp_srcs:
        if e and e in ds.world.intel:
            intel.append(f"{e}:{ds.world.intel[e]['verdict']}")
    return "\n".join(lines), sorted(set(intel))


def run(mode, card, intel, headline):
    card = card[:1400]
    headline = headline[:200]
    if mode == "constrained":
        sysmsg = (
            "You are a SOC analyst assistant. Using ONLY the evidence "
            "below, fill the template. Do NOT invent IPs, domains, rules, "
            "assets or conclusions not present in the evidence. If "
            "evidence is reconnaissance-only, state that no compromise is "
            "confirmed.\nTemplate: SUMMARY: ... | STAGE: ... | AFFECTED: "
            "... | CONFIDENCE: ... | RECOMMENDED_ACTION: ...")
        usr = f"Evidence:\n{card}\nTI: {intel}\nHeadline: {headline}"
    else:
        sysmsg = "You are a SOC analyst assistant. Write an incident report."
        usr = f"Headline: {headline}"
    return sysmsg, usr


def metrics(out, card, intel, is_eff):
    evidence_text = card + " " + " ".join(intel)
    gen_ips = set(IP_RE.findall(out))
    gen_doms = set(DOM_RE.findall(out)) - {"example.com"}
    gen_assets = set(ASSET_RE.findall(out))
    fab = []
    for toks, pat in ((gen_ips, IP_RE), (gen_doms, DOM_RE),
                      (gen_assets, ASSET_RE)):
        for t in toks:
            if t not in evidence_text:
                fab.append(t)
    n_gen = len(gen_ips) + len(gen_doms) + len(gen_assets)
    overreach = 0
    if not is_eff:
        overreach = int(any(w in out.lower() for w in COMPROMISE_WORDS))
    ev_ents = set(IP_RE.findall(evidence_text)) | set(DOM_RE.findall(
        evidence_text)) | set(ASSET_RE.findall(evidence_text))
    covered = sum(1 for t in ev_ents if t in out)
    fields = ("SUMMARY:", "STAGE:", "AFFECTED:", "CONFIDENCE:",
              "RECOMMENDED_ACTION:")
    return dict(
        fabrication_rate=len(fab) / max(1, n_gen),
        fabricated=", ".join(sorted(fab)[:5]),
        conclusion_overreach=overreach,
        evidence_coverage=covered / max(1, len(ev_ents)),
        template_compliance=sum(f in out for f in fields) / len(fields),
    )


def main(scale="S2", seed=11, n_cases=30, model_id=None):
    try:
        import torch
        from transformers import pipeline as hf_pipeline
    except ImportError:
        print("transformers/torch unavailable -- skipping LLM study")
        return
    model_id = model_id or MODEL_ID
    device = 0 if torch.cuda.is_available() else -1
    print(f"loading {model_id} on {'cuda' if device == 0 else 'cpu'} ...",
          flush=True)
    quant = os.environ.get("MDATA_LLM_4BIT", "1") == "1"
    from transformers import AutoModelForCausalLM, AutoTokenizer
    mkwargs = dict(torch_dtype=torch.bfloat16, device_map="auto")
    if quant:
        try:
            from transformers import BitsAndBytesConfig
            mkwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16)
            print("using 4-bit quantization", flush=True)
        except Exception as ex:
            print("4-bit unavailable, bf16 fallback:", ex, flush=True)
    model = AutoModelForCausalLM.from_pretrained(model_id, **mkwargs)
    tok = AutoTokenizer.from_pretrained(model_id)
    gen = hf_pipeline("text-generation", model=model, tokenizer=tok,
                      max_new_tokens=320)
    ds = datagen.generate(seed, scale)
    camps = [c for c in ds.campaigns.values()][:n_cases]
    rows = []
    for camp in camps:
        card, intel = evidence_card(ds, camp)
        headline = (f"Suspicious multi-stage activity from "
                    f"{camp.behaviors and 'source host'} in "
                    f"{','.join(camp.domains)}")
        for mode in ("constrained", "unconstrained"):
            sysmsg, usr = run(mode, card, intel, headline)
            msgs = [{"role": "system", "content": sysmsg},
                    {"role": "user", "content": usr}]
            out = gen(msgs, do_sample=False)[0]["generated_text"][-1][
                "content"]
            m = metrics(out, card, intel, camp.is_effective)
            m.update(cid=camp.cid, mode=mode, is_effective=camp.is_effective)
            rows.append(m)
            print(camp.cid, mode, {k: round(v, 3) for k, v in m.items()
                                   if isinstance(v, float)}, flush=True)
    with open(os.path.join(C.RESULTS, "llm_fabrication.json"), "w",
              encoding="utf-8") as f:
        json.dump(rows, f, indent=1, default=float)
    # summary
    for mode in ("constrained", "unconstrained"):
        sub = [r for r in rows if r["mode"] == mode]
        print(f"{mode:14s} fab={np.mean([r['fabrication_rate'] for r in sub]):.3f} "
              f"overreach={np.mean([r['conclusion_overreach'] for r in sub]):.3f} "
              f"coverage={np.mean([r['evidence_coverage'] for r in sub]):.3f} "
              f"template={np.mean([r['template_compliance'] for r in sub]):.3f}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--scale", default="S2")
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--cases", type=int, default=30)
    a = ap.parse_args()
    main(a.scale, a.seed, a.cases)
