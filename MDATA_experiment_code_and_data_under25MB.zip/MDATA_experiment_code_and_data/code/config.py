"""Global configuration for the MDATA benchmark experiments.

All paths, seeds and calibration anchors live here so every experiment is
reproducible from a single place.
"""
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = os.path.join(BASE, "results")
FIGURES = os.path.join(BASE, "figures")
DATA = os.path.join(BASE, "data")
for d in (RESULTS, FIGURES, DATA):
    os.makedirs(d, exist_ok=True)

# ---------------------------------------------------------------- seeds ----
MASTER_SEEDS = [11, 22, 33, 44, 55]   # 5 dataset replicas per scale
BOOTSTRAP_B = 1000                     # bootstrap resamples for 95% CIs

# ------------------------------------------------- assurance operation ----
# Calibrated to the anonymised aggregate statistics of a real 76-day
# multi-domain major-event security operation (Sec. 5.1 of the paper).
OP_DAYS = 76
OP_SECONDS = OP_DAYS * 86400

# Three monitoring domains (analogous to provincial / city / municipal).
DOMAINS = ["DOM-A", "DOM-B", "DOM-C"]

# ------------------------------------------------------- calibration -------
# Fraction of external IPs observable at honeypots that open TI marks
# malicious; ~0.116 confirmed benign (CDN / monitoring probes).
TI_MALICIOUS_RATE = 0.336
TI_BENIGN_RATE = 0.116
# Fraction of external IPs that are first-seen (no historical record).
FIRST_SEEN_RATE = 0.417          # 28,525 / 68,437

# --------------------------------------------------- dataset scales --------
# scale name -> (n_external_ips, n_campaigns, target_noise_factor)
SCALES = {
    "S1": dict(n_ext=4000, n_campaigns=60, noise_factor=1.0),
    "S2": dict(n_ext=8000, n_campaigns=120, noise_factor=2.0),
    "S3": dict(n_ext=16000, n_campaigns=240, noise_factor=4.0),
}
MAIN_SCALE = "S2"                # headline experiments run at S2

# Campaign truncation policy: share of campaigns that never pass recon
# (high-risk reconnaissance, "to be verified" -- NOT an effective attack).
P_RECON_ONLY = 0.30
P_STOP_AFTER_EXPLOIT = 0.15      # attempt observed, no success evidence

# ------------------------------------------------------------ methods ------
# MDATA hyper-parameters (expert-calibrated weights; sensitivity in RQ4).
FEATURE_WEIGHTS = {              # sum to 1
    "time": 0.20,
    "entity": 0.20,
    "reach": 0.15,
    "behavior": 0.20,
    "asset": 0.10,
    "intel": 0.10,
    "business": 0.05,
}
LAMBDA_PENALTY = 0.15            # uncertainty penalty coefficient
THETA = 0.35                     # correlation acceptance threshold
BEAM = 32                        # beam width B
MAX_PATH = 12                    # maximum chain length L
TIME_TOL = 1800                  # clock-tolerance window delta (s)

# Six-dimension threat scoring weights (sum to 1).
THREAT_WEIGHTS = dict(M=0.30, A=0.15, I=0.25, C=0.10, F=0.05, E=0.15)
KAPPA = 0.2                      # uncertainty interval width
T_HIGH = 0.70                    # high-risk threshold (lower bound must pass)
T_MED = 0.50
