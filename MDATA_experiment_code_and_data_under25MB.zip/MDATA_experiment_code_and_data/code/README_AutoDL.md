# AutoDL 3090 执行说明(LLM 部分)

## 环境
```bash
pip install -U transformers accelerate bitsandbytes
export HF_ENDPOINT=https://hf-mirror.com
```

## 跑什么(按顺序)
```bash
# 1) 本地 Qwen 智能体矩阵(60案例×4模式;7B bf16 约15GB,约2-4小时)
python run_agents_local.py --model qwen7b
# 2) 14B 用 4bit(约10GB显存)
python run_agents_local.py --model qwen14b --fourbit
# 3) 重跑 tab_llm(修复后的证据卡;30案例×2模式,约1小时)
python run_llm.py --cases 30
```

## 回传
把 results/ 下生成的 json 打包回传:
  agents_local_S2_11.json / llm_fabrication.json
```bash
zip results_back.zip results/*.json
```
