"""B5: graph-neural-network association baseline (link prediction).

Fair-comparison design following the chapter's requirement for learned
baselines (training data, feature input, parameter count, hyperparameter
search space and compute are all disclosed):

- Input: the SAME atomic events and the SAME hard-constraint candidate
  pairs as MDATA (no access to MDATA's scores or GT at inference).
- Features per event: stage, channel, action class, severity bucket,
  domain, zone, external-source flag, missing-field flag, log degree.
- Model: 2-layer GraphSAGE encoder + dot-product link scoring
  (hidden dim in {64, 128}, dropout in {0.0, 0.3}, lr in
  {1e-3, 5e-4}); trained with BCE on positive candidate pairs plus
  sampled negatives, using ONLY the calibration campaign split.
- Inference: behaviour score = max incident edge score.
- Evaluation: the shared EvalContext (identical to other baselines).

Runs on CUDA when available, otherwise CPU.
"""
from __future__ import annotations

import argparse
import json
import os

import numpy as np

import config as C
import datagen
import evaluate
import pipeline as P


def build_features(events):
    stages = sorted({e.stage for e in events})
    chans = sorted({e.channel for e in events})
    acts = sorted({e.act for e in events})
    doms = sorted({e.domain or "-" for e in events})
    zones = sorted({e.zone or "-" for e in events})
    si = {s: i for i, s in enumerate(stages)}
    ci = {s: i for i, s in enumerate(chans)}
    ai = {s: i for i, s in enumerate(acts)}
    di = {s: i for i, s in enumerate(doms)}
    zi = {s: i for i, s in enumerate(zones)}

    def onehot(i, n):
        v = np.zeros(n, dtype=np.float32)
        v[i] = 1.0
        return v

    deg = np.zeros(len(events))
    X = []
    for k, e in enumerate(events):
        x = np.concatenate([
            onehot(si[e.stage], len(si)),
            onehot(ci[e.channel], len(ci)),
            onehot(ai[e.act], len(ai)),
            onehot(di[e.domain or "-"], len(di)),
            onehot(zi[e.zone or "-"], len(zi)),
            [e.severity, e.missing,
             1.0 if (e.src and "." in str(e.src)) else 0.0,
             np.log1p(deg[k])],
        ]).astype(np.float32)
        X.append(x)
    return np.stack(X)


def main(seed=11, scale="S2", device=None):
    import torch
    import torch.nn as nn
    import torch.nn.functional as F
    from torch_geometric.nn import SAGEConv
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(seed)
    ds = datagen.generate(seed, scale)
    events = P.normalize(ds)
    ctx = evaluate.EvalContext(ds)
    labels, _ = evaluate.labels_of(ds)
    cands = [p for p, _ in P.gen_candidates(events)]
    beh_cid = {b.bid: b.cid for b in ds.behaviors}
    ev_bid = [e.bid for e in events]
    X = torch.tensor(build_features(events), device=device)

    # edges split by campaign split (labels never leak across)
    train_c, test_c, _, _ = evaluate.make_split(ds)

    def edge_ok_train(i, j):
        ci_ = beh_cid.get(ev_bid[i])
        cj_ = beh_cid.get(ev_bid[j])
        if ci_ is None or cj_ is None:
            return True                       # noise edges usable in train
        return (ci_ in train_c) and (cj_ in train_c)

    cand_set = set(cands)
    is_pos = [labels.get(b, 0) == 1 for b in ev_bid]
    # positives: candidate pairs inside the calibration split whose two
    # behaviours are both effective-attack members
    pos = [(i, j) for (i, j) in cands
           if edge_ok_train(i, j) and is_pos[i] and is_pos[j]]
    # negatives: random non-candidate pairs and candidate pairs that mix
    # effective with non-effective behaviours (train split only)
    rng = np.random.default_rng(seed)
    neg = []
    guard = 0
    while len(neg) < len(pos) and guard < 50 * len(pos) + 1000:
        guard += 1
        i, j = rng.integers(len(events), size=2)
        i, j = int(i), int(j)
        if i == j or (i, j) in cand_set or (j, i) in cand_set:
            continue
        if not edge_ok_train(i, j):
            continue
        neg.append((i, j))
    ei = torch.tensor([e[0] for e in pos] + [e[0] for e in neg], device=device)
    ej = torch.tensor([e[1] for e in pos] + [e[1] for e in neg], device=device)
    y = torch.tensor([1.0] * len(pos) + [0.0] * len(neg), device=device)
    edge_index = torch.stack([ei, ej], dim=0)
    # inference over ALL candidate pairs (test campaigns included)
    all_i = torch.tensor([i for i, _ in cands], device=device)
    all_j = torch.tensor([j for _, j in cands], device=device)

    class SAGE(nn.Module):
        def __init__(self, din, dh):
            super().__init__()
            self.c1 = SAGEConv(din, dh)
            self.c2 = SAGEConv(dh, dh)

        def forward(self, x, ei_):
            return self.c2(F.relu(self.c1(x, ei_)), ei_)

    results = []
    for dh in (64, 128):
        for drop in (0.0, 0.3):
            for lr in (1e-3, 5e-4):
                model = SAGE(X.shape[1], dh).to(device)
                opt = torch.optim.Adam(model.parameters(), lr=lr)
                for ep in range(30):
                    model.train()
                    z = model(X, edge_index)
                    F.dropout(z, drop, training=True)
                    sc = (z[ei] * z[ej]).sum(-1)
                    loss = F.binary_cross_entropy_with_logits(sc, y)
                    opt.zero_grad()
                    loss.backward()
                    opt.step()
                model.eval()
                with torch.no_grad():
                    z = model(X, edge_index)
                    sc_all = (z[all_i] * z[all_j]).sum(-1)
                    sc_np = torch.sigmoid(sc_all).cpu().numpy()
                scores = {}
                for (i, j), s in zip(cands, sc_np):
                    for b in (ev_bid[i], ev_bid[j]):
                        scores[b] = max(scores.get(b, 0.0), float(s))
                res = dict(name="B5", hidden=dh, dropout=drop, lr=lr,
                           params=sum(p.numel() for p in model.parameters()))
                m = ctx.evaluate(dict(scores=scores, chains_by_bid=[]))
                m.pop("_sc", None)
                m.pop("dets", None)
                m.pop("per_campaign_recall", None)
                res.update({k: v for k, v in m.items()
                            if isinstance(v, (int, float))})
                results.append(res)
                print(f"h={dh} drop={drop} lr={lr}: F1={m['f1']:.3f} "
                      f"PR-AUC={m['prauc']:.3f} NDCG={m['ndcg@50']:.3f} "
                      f"params={res['params']}", flush=True)
    best = max(results, key=lambda r: r["f1"])
    best["device"] = device
    best["torch"] = torch.__version__
    with open(os.path.join(C.RESULTS, f"gnn_{scale}_seed{seed}.json"),
              "w", encoding="utf-8") as f:
        json.dump(dict(all=results, best=best), f, indent=1, default=float)
    print("best:", {k: best[k] for k in ("hidden", "dropout", "lr", "f1",
                                         "prauc")})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--scale", default="S2")
    a = ap.parse_args()
    main(a.seed, a.scale)
