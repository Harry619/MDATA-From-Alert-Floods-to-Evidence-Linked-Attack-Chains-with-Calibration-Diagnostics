"""MDATA pipeline: normalisation, seven-dimension correlation scoring,
constraint-guided beam-search chain reconstruction and six-dimension
threat assessment.

Ablation switches follow the chapter's ablation design:
  A1 use_asset=False    -- remove asset & business-dependency features
  A2 use_intel=False    -- remove TI / honeypot evidence
  A3 use_time=False     -- remove temporal constraints
  A4 use_evidence=False -- remove evidence sufficiency & uncertainty penalty
"""
from __future__ import annotations

import math
from collections import defaultdict

import config as C
from datagen import STAGE_NEXT, ZONE_REACH

# --------------------------------------------------------------------------- #
#  Action ontology: raw kinds -> action class -> ATT&CK-style stage tag
# --------------------------------------------------------------------------- #
ACTION_CLASS = {
    "scan": ("scan", "recon"), "probe": ("probe", "recon"),
    "exploit_attempt": ("exploit", "exploit"),
    "c2_beacon": ("c2", "c2"),
    "remote_session": ("lateral", "lateral"), "susp_proc": ("lateral", "lateral"),
    "priv_cmd": ("priv_esc", "priv_esc"),
    "data_transfer": ("exfil", "exfil"), "archive_staged": ("exfil", "exfil"),
    "config_err": ("ops", "ops"), "backup_transfer": ("ops", "ops"),
    "dns_query": ("ops", "ops"), "auth_ticket": ("ticket", "ops"),
}
CLASS_SEVERITY = {
    "scan": 0.30, "probe": 0.30, "exploit": 0.85, "c2": 0.80, "lateral": 0.90,
    "priv_esc": 0.85, "exfil": 1.00, "ops": 0.25, "ticket": 0.10,
}
OPS_CLASSES = {"ops", "ticket"}

# sigma_b (s) per forward stage pair -- "reasonable interval per behaviour pair"
SIGMA_B = {
    ("recon", "exploit"): 1800, ("exploit", "c2"): 3600,
    ("exploit", "lateral"): 3600, ("exploit", "priv_esc"): 3600,
    ("c2", "lateral"): 8 * 3600, ("c2", "priv_esc"): 8 * 3600,
    ("c2", "exfil"): 24 * 3600, ("lateral", "lateral"): 3600,
    ("lateral", "priv_esc"): 1800, ("lateral", "exfil"): 4 * 3600,
    ("priv_esc", "exfil"): 4 * 3600, ("priv_esc", "lateral"): 4 * 3600,
}
DEFAULT_SIGMA = 3600
MAX_PAIR_WINDOW = 48 * 3600        # generous hard-constraint time bound
SAME_ACT_WINDOW = 1800             # same-burst multi-sensor window
REPETITIVE_ACTS = {"scan", "probe"}   # high-volume repetitive actions
STAGE_ORDER = {s: i for i, s in enumerate(
    ["ops", "recon", "exploit", "c2", "lateral", "priv_esc", "exfil"])}


# --------------------------------------------------------------------------- #
#  Stage 1: single-channel analysis -> atomic events (unified ten-tuple)
# --------------------------------------------------------------------------- #
class AtomicEvent:
    __slots__ = ("eid", "bid", "channel", "t0", "t1", "clock_conf", "src", "dst",
                 "sub", "obj", "act", "stage", "domain", "zone", "severity",
                 "missing", "records", "kind", "extra")

    def __init__(self, eid, bid, channel, t0, t1, clock_conf, src, dst, sub,
                 obj, act, stage, domain, zone, severity, missing, records,
                 kind, extra):
        self.eid, self.bid, self.channel = eid, bid, channel
        self.t0, self.t1, self.clock_conf = t0, t1, clock_conf
        self.src, self.dst, self.sub, self.obj = src, dst, sub, obj
        self.act, self.stage, self.domain, self.zone = act, stage, domain, zone
        self.severity, self.missing = severity, missing
        self.records, self.kind, self.extra = records, kind, extra

    @property
    def mid(self):
        return (self.t0 + self.t1) / 2


def normalize(ds, use_intel=True, use_time=True):
    """Parse / dedup / aggregate raw records into atomic events.

    Aggregation groups records of one behaviour inside one channel (sliding
    window dedup of identical subjects/objects/rules), preserving a
    reversible link to every raw record.
    """
    by_bc = defaultdict(list)
    for r in ds.records:
        by_bc[(r["bid"], r["channel"])].append(r)
    events = []
    eid = 0
    for (bid, ch), recs in sorted(by_bc.items()):
        beh = _beh_of(ds, bid)
        recs.sort(key=lambda r: r["ts"])
        act, stage = ACTION_CLASS.get(beh.kind, ("other", "ops"))
        # clock confidence: channel skew reliability of the worst record
        cc = min(r.get("clock_conf", 1.0) for r in recs)
        missing = sum(1 for r in recs if _has_missing(r))
        has_rule_sev = any(r.get("severity") is not None for r in recs)
        if has_rule_sev:
            sev = max(r.get("severity") for r in recs if r.get("severity") is not None)
        else:
            sev = CLASS_SEVERITY.get(act, 0.3)
        eid += 1
        events.append(AtomicEvent(
            f"E{eid:07d}", bid, ch, recs[0]["ts"], recs[-1]["ts"], cc,
            recs[0].get("src"), recs[0].get("dst"),
            recs[0].get("user") or beh.actor, beh.asset, act, stage,
            beh.domain,
            ds.world.zone_of.get(beh.asset) if beh.asset else None,
            min(1.0, sev), missing / max(1, len(recs)), recs, beh.kind,
            dict(rules={r.get("rule") for r in recs if r.get("rule")},
                 domain=recs[0].get("domain") if ch == "dns" else None,
                 bytes=max((r.get("bytes_") or 0) for r in recs) if recs else 0,
                 authorized=any(r.get("authorized") for r in recs
                                if ch == "ticket"),
                 channel_sev=sev)))
    return events


def _beh_of(ds, bid):
    return _beh_cache(ds)[bid]


_beh_cache_store = {}


def _beh_cache(ds):
    key = id(ds)
    if key not in _beh_cache_store:
        _beh_cache_store[key] = {b.bid: b for b in ds.behaviors}
    return _beh_cache_store[key]


def _has_missing(r):
    if r["channel"] in ("flow", "ids"):
        return r.get("src") is None or r.get("dst") is None
    if r["channel"] == "edr":
        return r.get("asset") is None
    return False


# --------------------------------------------------------------------------- #
#  Stage 2: hard-constraint candidate generation (indexed, not O(n^2))
# --------------------------------------------------------------------------- #
def _slash24(ip):
    return ".".join(ip.split(".")[:3]) if ip else None


def gen_candidates(events, use_asset=True, use_time=True, window=None):
    """Iterate sparse candidate pairs (i, j) satisfying hard constraints.

    Entity inverted index + time-locality bounds.  High-volume repetitive
    actions (scans, probes, operational classes) only pair cross-channel
    within the same-burst window (multi-sensor corroboration of one
    behaviour); cross-action pairs use the full stage-pair window.
    This keeps pair generation near-linear in dense noise and is the
    index-level realisation of the "no stage progression" hard constraint.
    """
    win = window or (MAX_PAIR_WINDOW if use_time else 72 * 3600)

    def repetitive(e):
        return e.act in REPETITIVE_ACTS or e.stage in OPS_CLASSES

    def emit(a_list, b_list, win_ab, cross_only, same_act):
        """Two-pointer pair enumeration between two time-sorted lists.

        For each anchor in a_list, scans the windowed slice of b_list via
        an advancing start pointer -- O(n + pairs) per list pair.
        """
        j_start = 0
        for x in range(len(a_list)):
            ia = a_list[x]
            e1 = events[ia]
            mx = e1.mid
            while j_start < len(b_list) and                     events[b_list[j_start]].mid < mx - win_ab:
                j_start += 1
            j = j_start
            while j < len(b_list) and events[b_list[j]].mid <= mx + win_ab:
                ib = b_list[j]
                j += 1
                if ib == ia:
                    continue
                e2 = events[ib]
                if cross_only and e1.channel == e2.channel:
                    continue
                if same_act and e1.act != e2.act:
                    continue
                p = (ia, ib) if ia < ib else (ib, ia)
                yield p

    ev_by_key = defaultdict(list)
    for i, e in enumerate(events):
        if e.src:
            ev_by_key[("src", e.src)].append(i)
            ev_by_key[("net", _slash24(e.src))].append(i)
        if e.dst and not str(e.dst).startswith("bak-"):
            ev_by_key[("dst", e.dst)].append(i)
        if e.obj:
            ev_by_key[("obj", e.obj)].append(i)
        if e.sub and e.sub != "-":
            ev_by_key[("sub", e.sub)].append(i)
        if e.extra.get("domain"):
            ev_by_key[("dom", e.extra["domain"])].append(i)
    seen = set()
    for key, idxs in ev_by_key.items():
        if len(idxs) < 2:
            continue
        idxs = sorted(set(idxs), key=lambda i: events[i].mid)
        rep = [i for i in idxs if repetitive(events[i])]
        oth = [i for i in idxs if not repetitive(events[i])]
        # repetitive x repetitive: same-burst cross-channel only
        for p in emit(rep, rep, SAME_ACT_WINDOW, True, True):
            if p not in seen:
                seen.add(p)
                yield p, True
        # repetitive x other and other x other: full window
        for p in emit(rep, oth, win, False, False):
            if p not in seen:
                seen.add(p)
                yield p, False
        for p in emit(oth, oth, win, False, False):
            if p not in seen:
                seen.add(p)
                # stage-order + scope constraints for attack-stage pairs
                e1, e2 = events[p[0]], events[p[1]]
                if STAGE_ORDER.get(e2.stage, 0) < STAGE_ORDER.get(e1.stage, 0):
                    e1, e2 = e2, e1
                if e1.domain and e2.domain and e1.domain != e2.domain:
                    z1 = e1.zone or "dmz"
                    z2 = e2.zone or "dmz"
                    if use_asset and z2 not in ZONE_REACH.get(z1, set()) and                        z1 not in ZONE_REACH.get(z2, set()):
                        continue
                yield p, False
        if len(seen) > 3_000_000:
            seen.clear()
    return


def gen_scored_edges(events, scorer, now, use_asset=True, use_time=True,
                     keep=0.35, window=None):
    """Fused candidate generation + scoring.

    Streams candidate pairs, scores them, and keeps only edges with
    S >= keep (edges below 0.8*theta can never enter clusters or accepted
    paths), which bounds memory and keeps scoring output small.
    """
    edges = []
    n_cand = 0
    for (i, j), _ in gen_candidates(events, use_asset=use_asset,
                                    use_time=use_time, window=window):
        n_cand += 1
        s = scorer.score(events[i], events[j], now)
        if s >= keep:
            edges.append((i, j, s))
    return edges, n_cand


# --------------------------------------------------------------------------- #
#  Stage 3: seven-dimension correlation scoring
# --------------------------------------------------------------------------- #
class Scorer:
    def __init__(self, ds, weights=None, lam=None, use_asset=True,
                 use_intel=True, use_time=True, use_evidence=True):
        self.w = dict(weights or C.FEATURE_WEIGHTS)
        self.lam = lam if lam is not None else C.LAMBDA_PENALTY
        self.use_asset, self.use_intel = use_asset, use_intel
        self.use_time, self.use_evidence = use_time, use_evidence
        self.intel = ds.world.intel
        self.assets = ds.world.assets
        self.zone_of = ds.world.zone_of
        # renormalise weights over active features only
        active = dict(self.w)
        if not use_asset:
            active["asset"] = active["business"] = 0.0
        if not use_intel:
            active["intel"] = 0.0
        if not use_time:
            active["time"] = 0.0
        tot = sum(active.values()) or 1.0
        self.wa = {k: v / tot for k, v in active.items()}
        self._pair_cache = {}

    # -- feature: time proximity -------------------------------------------
    def f_time(self, e1, e2):
        pair = tuple(sorted([e1.stage, e2.stage]))
        sig = SIGMA_B.get(pair, DEFAULT_SIGMA) if e1.stage != e2.stage else DEFAULT_SIGMA
        cc = min(e1.clock_conf, e2.clock_conf, 1.0)
        sig = sig / max(0.5, cc)
        return math.exp(-abs(e1.mid - e2.mid) / sig)

    # -- feature: entity consistency ----------------------------------------
    def f_entity(self, e1, e2):
        if e1.src and e1.src == e2.src:
            return 1.0
        if (e1.dst and e1.dst == e2.src) or (e2.dst and e2.dst == e1.src):
            return 1.0                                  # chain flow continuity
        if e1.sub and e1.sub == e2.sub and e1.sub != "-":
            return 1.0
        if e1.extra.get("domain") and e1.extra["domain"] == e2.extra.get("domain"):
            return 0.6
        if e1.src and e2.src and _slash24(e1.src) == _slash24(e2.src):
            return 0.5                                  # infrastructure reuse
        if e1.obj and e1.obj == e2.obj:
            return 0.25                              # shared target, weak
        return 0.0

    # -- feature: network reachability ---------------------------------------
    def f_reach(self, e1, e2):
        z1 = e1.zone or (self.zone_of.get(e1.dst) if e1.dst else None)
        z2 = e2.zone or (self.zone_of.get(e2.dst) if e2.dst else None)
        if not z1 or not z2:
            return 0.5                                  # unknown -> partial
        if z1 == z2:
            return 0.75
        if z2 in ZONE_REACH.get(z1, set()):
            return 1.0
        # indirect: one intermediate zone (cloud / thirdparty hop)
        for zm in ZONE_REACH.get(z1, set()):
            if z2 in ZONE_REACH.get(zm, set()):
                return 0.5
        return 0.0

    # -- feature: behavioural complementarity -------------------------------
    def f_behavior(self, e1, e2):
        if e1.stage == e2.stage:
            return 0.5 if e1.channel != e2.channel else 0.3
        if e2.stage in STAGE_NEXT.get(e1.stage, set()):
            return 1.0
        return 0.0

    # -- feature: asset / business dependency --------------------------------
    def f_asset(self, e1, e2):
        o1, o2 = e1.obj, e2.obj
        if o1 and o1 == o2:
            a = self.assets.get(o1)
            base = 0.8
            if a and a.criticality >= 0.7:
                base = 0.9
            return base
        if o1 and o2 and o2 in (self.assets.get(o1).deps if self.assets.get(o1) else []):
            return 0.7
        if o1 and o2 and self.assets.get(o1) and self.assets.get(o2) and \
           set(self.assets[o1].deps) & set(self.assets[o2].deps):
            return 0.5
        z1, z2 = e1.zone, e2.zone
        if z1 and z1 == z2:
            return 0.3
        return 0.0

    def f_business(self, e1, e2):
        c1 = self.assets[e1.obj].criticality if e1.obj in self.assets else 0.0
        c2 = self.assets[e2.obj].criticality if e2.obj in self.assets else 0.0
        if c1 >= 0.7 and c2 >= 0.7:
            return 1.0
        if max(c1, c2) >= 0.7:
            return 0.6
        if max(c1, c2) > 0:
            return 0.4
        return 0.0

    # -- feature: intelligence consistency ------------------------------------
    def f_intel(self, e1, e2, now):
        """Intelligence CONSISTENCY: rewards agreement between the two
        sides' intel verdicts; one-sided malicious tags score half (a
        lone tag is weak evidence); conflicts and stale entries feed the
        uncertainty term, never the score."""
        verdicts, confs = [], []
        conflict = 0.0
        for e in (e1, e2):
            ent = e.src if e.src and not str(e.src).startswith("A") else None
            if e.extra.get("domain"):
                ent = e.extra["domain"]
            if not ent:
                verdicts.append("absent")
                confs.append(0.0)
                continue
            rec = self.intel.get(ent)
            if not rec:
                verdicts.append("absent")
                confs.append(0.0)
                continue
            expired = rec["expiry"] < (e.mid or now)
            if expired:
                conflict = max(conflict, 0.25)          # stale intel
                verdicts.append("absent")
                confs.append(0.0)
            elif rec["verdict"] == "malicious":
                verdicts.append("mal")
                confs.append(rec["confidence"] * rec["src_w"])
            elif rec["verdict"] == "benign":
                verdicts.append("ben")
                confs.append(rec["confidence"] * rec["src_w"])
            else:
                verdicts.append("unknown")
                confs.append(0.0)
        if "ben" in verdicts and "mal" in verdicts:
            conflict = max(conflict, 0.5)
            return 0.0
        if verdicts.count("mal") == 2:
            return max(confs)
        if verdicts.count("mal") == 1:
            return 0.5 * max(confs)                     # one-sided tag
        return 0.0

    # -- uncertainty ----------------------------------------------------------
    def uncertainty(self, e1, e2):
        if not self.use_evidence:
            return 0.0
        miss = (e1.missing + e2.missing) / 2
        clock = 1 - min(e1.clock_conf, e2.clock_conf)
        return min(1.0, 0.6 * miss + 0.4 * clock)

    def explain(self, e1, e2, now):
        """Feature-wise contribution of one pair (explainability output)."""
        phi = dict(
            time=self.f_time(e1, e2) if self.use_time else 0.5,
            entity=self.f_entity(e1, e2),
            reach=self.f_reach(e1, e2),
            behavior=self.f_behavior(e1, e2),
            asset=self.f_asset(e1, e2) if self.use_asset else 0.0,
            business=self.f_business(e1, e2) if self.use_asset else 0.0,
            intel=self.f_intel(e1, e2, now) if self.use_intel else 0.0,
        )
        contrib = {k: round(self.wa[k] * v, 3) for k, v in phi.items()}
        s = sum(contrib.values()) - self.lam * self.uncertainty(e1, e2)
        return dict(score=round(max(0.0, min(1.0, s)), 3), phi=phi,
                    contribution=contrib,
                    uncertainty=round(self.uncertainty(e1, e2), 3))

    def score(self, e1, e2, now):
        key = (e1.eid, e2.eid, now)
        if key in self._pair_cache:
            return self._pair_cache[key]
        phi = dict(
            time=self.f_time(e1, e2) if self.use_time else 0.5,
            entity=self.f_entity(e1, e2),
            reach=self.f_reach(e1, e2),
            behavior=self.f_behavior(e1, e2),
            asset=self.f_asset(e1, e2) if self.use_asset else 0.0,
            business=self.f_business(e1, e2) if self.use_asset else 0.0,
            intel=self.f_intel(e1, e2, now) if self.use_intel else 0.0,
        )
        s = sum(self.wa[k] * v for k, v in phi.items())
        s -= self.lam * self.uncertainty(e1, e2)
        s = max(0.0, min(1.0, s))
        self._pair_cache[key] = s
        return s


# --------------------------------------------------------------------------- #
#  Stage 4: constrained beam-search chain reconstruction (Algorithm 4-1)
# --------------------------------------------------------------------------- #
def beam_search(events, edges, scorer, theta=None, beam=None, max_len=None,
                use_time=True, seeds=None):
    """Constrained beam search (Algorithm 1).

    Each high-confidence seed grows its own local beam under temporal,
    reachability and stage-transition constraints; a backward pass then
    prepends reconnaissance evidence.  Paths are finally merged and
    de-duplicated globally.
    """
    theta = C.THETA if theta is None else theta
    beam = C.BEAM if beam is None else beam
    max_len = C.MAX_PATH if max_len is None else max_len
    adj = defaultdict(list)
    for i, j, s in edges:
        adj[i].append((j, s))
        adj[j].append((i, s))

    def pscore(p):
        tot, n = 0.0, 0
        for a, b in zip(p, p[1:]):
            for (j, s) in adj[a]:
                if j == b:
                    tot += s
                    n += 1
                    break
        edge_avg = tot / max(1, n)
        risk = sum(events[i].severity for i in p) / len(p)
        return 0.7 * edge_avg + 0.3 * risk

    def forward_ok(cur, nxt):
        e_end, e_nxt = events[cur], events[nxt]
        if e_nxt.stage in OPS_CLASSES or e_end.stage in OPS_CLASSES:
            return False
        if use_time and e_nxt.mid < e_end.mid - 1:
            return False
        if STAGE_ORDER.get(e_nxt.stage, 0) < STAGE_ORDER.get(e_end.stage, 0):
            return False
        return True

    finished = []
    for si in seeds:
        states = [[si]]
        rounds = 0
        while states and rounds < max_len:
            rounds += 1
            new_states, stagnant = [], []
            for path in states:
                ext = False
                if len(path) < max_len:
                    for (nxt, s) in adj[path[-1]]:
                        if nxt in path:
                            continue
                        if forward_ok(path[-1], nxt):
                            new_states.append(path + [nxt])
                            ext = True
                if not ext and len(path) >= 2:
                    stagnant.append(path)
            finished.extend(stagnant)
            if not new_states:
                break
            new_states.sort(key=pscore, reverse=True)
            seen_sig = set()
            dedup = []
            for p in new_states[:beam]:
                sig = frozenset(p)
                if sig not in seen_sig:
                    seen_sig.add(sig)
                    dedup.append(p)
            states = dedup
        finished.extend(p for p in states if len(p) >= 2)

    # backward pass: prepend reconnaissance / precursor evidence
    expanded = []
    for p in finished:
        while len(p) < max_len:
            head = p[0]
            best, best_s = None, 0.0
            for (prv, s) in adj[head]:
                if prv in p:
                    continue
                e = events[prv]
                if e.stage != "recon":
                    continue
                if use_time and e.mid > events[head].mid:
                    continue
                if s > best_s:
                    best, best_s = prv, s
            if best is None or best_s < theta * 0.8:
                break
            p = [best] + p
        expanded.append(p)

    out, used = [], set()
    expanded.sort(key=lambda p: (-len(p), -pscore(p)))
    for p in expanded:
        if pscore(p) < theta * 0.8:
            continue
        if any(i in used for i in p):
            continue
        used.update(p)
        out.append(p)
    return out


def pick_seeds(events, intel, use_intel=True):
    seeds = []
    for i, e in enumerate(events):
        if e.stage in OPS_CLASSES:
            continue
        if e.severity >= 0.8:
            seeds.append(i)
        elif use_intel and e.src:
            rec = intel.get(e.src)
            if rec and rec["verdict"] == "malicious" and rec["confidence"] >= 0.75 \
               and e.severity >= 0.3 and e.act in ("exploit", "c2", "lateral"):
                seeds.append(i)
    return seeds


# --------------------------------------------------------------------------- #
#  Stage 5: clustering + six-dimension threat scoring
# --------------------------------------------------------------------------- #
def clusters_from_edges(n, edges, theta, theta_core=0.60, attach=0.55):
    """Cluster criterion of the chapter: internally strong, externally weak.

    Cores are connected components over strong edges (>= theta_core);
    remaining edges (>= theta) are aggregated per component pair, and a
    small component attaches to a core when the mean edge score reaches
    `attach`.  Everything else stays singletons.
    """
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    agg = {}                       # (ri, rj) -> [sum, cnt]
    for i, j, s in edges:
        if s >= theta_core:
            parent[find(i)] = find(j)
        elif s >= theta:
            ri, rj = find(i), find(j)
            if ri != rj:
                k1 = (ri, rj) if ri < rj else (rj, ri)
                rec = agg.get(k1)
                if rec is None:
                    agg[k1] = [s, 1]
                else:
                    rec[0] += s
                    rec[1] += 1
    size = defaultdict(int)
    for k in range(n):
        size[find(k)] += 1
    # attach small components to cores by aggregated mean edge score
    order = sorted(agg.items(), key=lambda kv: -(kv[1][0] / kv[1][1]))
    for (ri, rj), (ssum, cnt) in order:
        ri, rj = find(ri), find(rj)
        if ri == rj:
            continue
        mean_s = ssum / cnt
        if mean_s >= attach and min(size[ri], size[rj]) <= 2:
            if size[ri] <= size[rj]:
                parent[ri] = rj
                size[rj] += size.pop(ri)
            else:
                parent[rj] = ri
                size[ri] += size.pop(rj)
    groups = defaultdict(list)
    for i in range(n):
        groups[find(i)].append(i)
    return list(groups.values())


def threat_scores(ds, events, clusters, chains, use_intel=True,
                  use_evidence=True, now=None, kappa=None, weights=None):
    """Six-dimension calibrated threat scoring per behaviour.

    Returns (behaviour score dict, behaviour -> (R, U, dims) dict).
    """
    aw = dict(weights or C.THREAT_WEIGHTS)
    if not use_evidence:
        aw["E"] = 0.0
        tot = sum(aw.values())
        aw = {k: v / tot for k, v in aw.items()}
    kappa = C.KAPPA if kappa is None else kappa
    now = now if now is not None else C.OP_SECONDS
    beh = _beh_cache(ds)
    bid_of = {e.eid: e for e in events}
    eid_to_idx = {e.eid: i for i, e in enumerate(events)}
    cl_of = {}
    for ci, cl in enumerate(clusters):
        for i in cl:
            cl_of[i] = ci
    chain_members = {i for p in chains for i in p}

    def dims_for(eids):
        evs = [events[i] for i in eids]
        stages = {e.stage for e in evs}
        acts = {e.act for e in evs}
        assets = {e.obj for e in evs if e.obj and e.obj in ds.world.assets}
        authorized = any(e.extra.get("authorized") for e in evs)
        # M -- behaviour malice
        post = bool(stages & {"c2", "lateral", "priv_esc", "exfil"})
        if authorized:
            M = 0.15
        elif "exploit" in acts and post:
            M = 0.95
        elif "exploit" in acts:
            M = 0.55
        elif post:
            M = 0.85
        else:
            M = max((e.severity for e in evs), default=0.2) * 0.5
        # A -- attack reachability from outside into protected zones
        ext = any(e.src and not str(e.src).startswith("A") and
                  "." in str(e.src) and e.src not in ds.world.assets for e in evs)
        internal = any(e.zone in ("intranet", "cloud") for e in evs)
        A = 1.0 if (ext and internal) else (0.7 if internal else (0.6 if ext else 0.3))
        # I -- asset impact
        I = max((ds.world.assets[a].criticality for a in assets), default=0.2)
        # C -- intelligence confidence (expiry-aware)
        Cc = 0.2
        if use_intel:
            best = 0.0
            for e in evs:
                for ent in (e.src, e.extra.get("domain")):
                    if not ent:
                        continue
                    rec = ds.world.intel.get(ent)
                    if rec and rec["verdict"] == "malicious" and rec["expiry"] >= (e.mid or 0):
                        best = max(best, rec["confidence"] * rec["src_w"])
            Cc = best if best > 0 else 0.2
        # F -- timeliness decay
        t_last = max((e.t1 for e in evs), default=0)
        F = math.exp(-max(0, now - t_last) / (72 * 3600))
        # E -- evidence sufficiency
        if use_evidence:
            chs = len({e.channel for e in evs})
            provenance = all(e.records for e in evs)
            miss = 1 - sum(e.missing for e in evs) / max(1, len(evs))
            E = min(1.0, (chs / 3.0)) * (0.5 + 0.5 * miss) * (1.0 if provenance else 0.5)
        else:
            E = 0.0
        d = dict(M=M, A=A, I=I, C=Cc, F=F, E=E)
        R = sum(aw[k] * v for k, v in d.items())
        U = 0.0
        if use_evidence:
            U = min(1.0, sum(e.missing for e in evs) / max(1, len(evs)) * 0.6 +
                    (1 - min(e.clock_conf for e in evs)) * 0.4)
        return R, U, d

    scores, meta = defaultdict(float), {}
    for ci, cl in enumerate(clusters):
        R, U, d = dims_for(cl)
        # clusters linked to a beam-search chain get a chain bonus via M/A
        if any(i in chain_members for i in cl):
            R = min(1.0, R + 0.05)
        for i in cl:
            b = events[i].bid
            if R > scores[b]:
                scores[b] = R
                meta[b] = (R, U, d)
    # singleton events keep their own score (isolated high-severity alerts)
    for i, e in enumerate(events):
        b = e.bid
        if b not in scores:
            R, U, d = dims_for([i])
            scores[b] = R
            meta[b] = (R, U, d)
    return scores, meta


# --------------------------------------------------------------------------- #
#  Full MDATA run
# --------------------------------------------------------------------------- #
def run_mdata(ds, *, use_asset=True, use_intel=True, use_time=True,
              use_evidence=True, theta=None, beam=None, max_len=None,
              weights=None, lam=None, timing=None):
    """Run the full pipeline; returns dict with behaviour scores / chains."""
    import time as _t
    timing = timing if timing is not None else {}
    t0 = _t.perf_counter()
    events = normalize(ds, use_intel=use_intel, use_time=use_time)
    t1 = _t.perf_counter()
    scorer = Scorer(ds, weights=weights, lam=lam, use_asset=use_asset,
                    use_intel=use_intel, use_time=use_time,
                    use_evidence=use_evidence)
    now = C.OP_SECONDS
    theta_eff = C.THETA if theta is None else theta
    edges, n_cand = gen_scored_edges(events, scorer, now,
                                     use_asset=use_asset, use_time=use_time,
                                     keep=theta_eff)
    t2 = t3 = _t.perf_counter()
    clusters = clusters_from_edges(len(events), edges, theta_eff)
    seeds = pick_seeds(events, ds.world.intel, use_intel=use_intel)
    chains = beam_search(events, edges, scorer, theta=theta_eff, beam=beam,
                         max_len=max_len, use_time=use_time, seeds=seeds)
    t4 = _t.perf_counter()
    scores, meta = threat_scores(ds, events, clusters, chains,
                                 use_intel=use_intel, use_evidence=use_evidence)
    t5 = _t.perf_counter()
    timing.update(dict(normalize=t1 - t0, candidates=t2 - t1,
                           scoring=t3 - t2, cluster_search=t4 - t3,
                           threat=t5 - t4, total=t5 - t0,
                           n_events=len(events), n_edges=len(edges),
                           n_candidates=n_cand))
    chains_by_bid = []
    for path in chains:
        seq, last = [], None
        for i in path:
            b = events[i].bid
            if b != last:
                seq.append(b)
                last = b
        if len(seq) >= 2:
            chains_by_bid.append(seq)
    return dict(events=events, edges=edges, clusters=clusters, chains=chains,
                chains_by_bid=chains_by_bid, scores=scores, meta=meta,
                scorer=scorer, timing=timing)
