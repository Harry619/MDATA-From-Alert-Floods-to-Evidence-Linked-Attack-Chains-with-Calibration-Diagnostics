"""Baselines B1-B4 of the chapter's comparison design.

B1  single-channel rule-severity ranking (traditional SOC workflow)
B2  time + source-IP/account heuristic correlation
B3  graph association without asset / business relations
B4  reduced MDATA without spatio-temporal traceability & evidence sufficiency

All methods consume the SAME atomic events produced by the same
normalisation layer (fair-input requirement of the chapter).
"""
from __future__ import annotations

from collections import defaultdict

import config as C
import pipeline as P
from pipeline import normalize, STAGE_ORDER, OPS_CLASSES


# ------------------------------------------------------------------ B1 ----
def run_b1(ds):
    events = normalize(ds)
    scores = {}
    for e in events:
        scores[e.bid] = max(scores.get(e.bid, 0.0), e.severity)
    return dict(scores=scores, chains_by_bid=[], events=events,
                name="B1")


# ------------------------------------------------------------------ B2 ----
def run_b2(ds, window=24 * 3600):
    events = normalize(ds)
    by_actor = defaultdict(list)
    for i, e in enumerate(events):
        key = e.src or e.sub or e.dst or "-"
        if key == "-":
            continue
        by_actor[key].append(i)
    scores = {}
    chains = []
    for key, idxs in by_actor.items():
        idxs.sort(key=lambda i: events[i].mid)
        group, last_mid = [], None
        subgroups = []
        for i in idxs:
            if last_mid is not None and events[i].mid - last_mid > window:
                subgroups.append(group)
                group = []
            group.append(i)
            last_mid = events[i].mid
        if group:
            subgroups.append(group)
        for g in subgroups:
            if not g:
                continue
            max_sev = max(events[i].severity for i in g)
            cnt = min(len(g) / 8.0, 1.0)
            bids, seen = [], set()
            for i in g:
                own = 0.7 * events[i].severity + 0.3 * cnt
                scores[events[i].bid] = max(scores.get(events[i].bid, 0.0), own)
                if events[i].bid not in seen:
                    seen.add(events[i].bid)
                    bids.append(events[i].bid)
            if len(bids) >= 2 and max_sev >= 0.5:
                chains.append(bids)
    return dict(scores=scores, chains_by_bid=chains, events=events, name="B2")


# ------------------------------------------------------------------ B3 ----
def run_b3(ds, **kw):
    """Graph association without asset / business relations.

    Same pipeline and clustering as MDATA with the asset/business features
    and the asset-reachability hard constraint removed; identical to
    ablation A1 and listed in both tables as the chapter prescribes."""
    res = P.run_mdata(ds, use_asset=False, **kw)
    res["name"] = "B3"
    return res


# ------------------------------------------------------------------ B4 ----
def run_b4(ds, theta=None, beam=None, max_len=None):
    """Reduced MDATA: no temporal constraints (loose index window, no time
    feature, no ordering in search), no network-reachability feature, and
    no evidence sufficiency / uncertainty penalty."""
    weights = dict(C.FEATURE_WEIGHTS)
    weights["time"] = 0.0
    weights["reach"] = 0.0
    res = P.run_mdata(ds, use_asset=True, use_intel=True, use_time=False,
                      use_evidence=False, weights=weights, theta=theta,
                      beam=beam, max_len=max_len)
    res["name"] = "B4"
    return res


def run_mdata_full(ds, **kw):
    res = P.run_mdata(ds, **kw)
    res["name"] = "MDATA"
    return res
