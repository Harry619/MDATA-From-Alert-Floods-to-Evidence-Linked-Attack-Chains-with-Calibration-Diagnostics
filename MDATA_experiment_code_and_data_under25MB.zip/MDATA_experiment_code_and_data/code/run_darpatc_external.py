"""Enhancement item (5): external validation on DARPA TC E3 (THEIA).

Runs on the CLOUD SERVER (see EXTERNAL_VALIDATION_PLAN.md); this machine
only hosts the skeleton.  Consumes a PIDSMaker-built graph plus orthrus
ground-truth CSVs, maps provenance subjects/objects into the MDATA
ten-tuple through a pseudo-Dataset, and evaluates attack-chain
reconstruction with the paper's protocol (no re-tuning).

TODO(server): adjust column names after inspecting the built graph CSVs
(look at pidsmaker output for exact headers).
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import defaultdict
from types import SimpleNamespace

import config as C
import evaluate
import pipeline

# ---------------------------------------------------------------- inputs --
# PIDSMaker graph CSV columns (TODO: verify on server)
#   expected: src_uuid, dst_uuid, action, ts, src_type, dst_type, object
GT_COLS = ("uuid", "labels", "count")          # orthrus per-attack CSV


def load_graph(path_csv):
    """PIDSMaker edge list -> list of pseudo records."""
    records = []
    with open(path_csv, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            # TODO(server): map actual columns
            records.append(dict(
                channel="edr",                     # single provenance source
                ts=int(float(row["ts"])),
                src=row.get("src_uuid"),
                dst=row.get("dst_uuid"),
                rule=row.get("action"),
                severity=None,
                bid=None,                          # assigned in build_ds
                clock_conf=1.0,
                kind=row.get("action"),
                extra=dict(object=row.get("object"),
                           src_type=row.get("src_type"),
                           dst_type=row.get("dst_type"))))
    return records


def classify(rec, heur):
    """Edge type -> action class / stage (heuristics of the plan)."""
    act, obj_t = rec["rule"], rec["extra"].get("dst_type", "")
    if "NETWORK" in act or "CONNECT" in act:
        return "c2_beacon", "c2"
    if "EXECUTE" in act or "EXECVE" in act:
        return "susp_proc", "lateral"
    if "WRITE" in act:
        return "archive_staged", "exfil" if heur.is_staging(
            rec["extra"].get("object")) else "ops"
    return "probe", "recon"


class Staging:
    def __init__(self, keywords=("/tmp", "drakon", "payload", ".so")):
        self.keywords = keywords

    def is_staging(self, obj):
        obj = str(obj or "").lower()
        return any(k in obj for k in self.keywords)


def build_ds(records, window=60):
    """Aggregate records into behaviours + a pseudo-Dataset compatible
    with pipeline.normalize / threat machinery."""
    # behaviour = same subject within `window` seconds
    behs, by_sub = [], defaultdict(list)
    records = sorted(records, key=lambda r: r["ts"])
    cur, last_t, last_sub = None, -1, None
    for r in records:
        if r["src"] != last_sub or r["ts"] - last_t > window:
            cur = dict(bid=f"X{len(behs):06d}", src=r["src"], records=[])
            behs.append(cur)
            last_sub, last_t = r["src"], r["ts"]
        cur["records"].append(r)
        r["bid"] = cur["bid"]
        last_t = max(last_t, r["ts"])
    assets, zone_of, intel = {}, {}, {}
    # TODO(server): asset registry heuristics (system dirs -> 0.7)
    world = SimpleNamespace(assets=assets, zone_of=zone_of, intel=intel,
                            groups={}, ext_ips={})
    beh_objs = []
    heur = Staging()
    for b in behs:
        kinds = [r["kind"] for r in b["records"]]
        act, stage = classify(b["records"][0], heur)
        beh_objs.append(SimpleNamespace(
            bid=b["bid"], channel="edr", stage=stage, cid=None,
            actor=b["src"], kind=act,
            t0=b["records"][0]["ts"], t1=b["records"][-1]["ts"],
            src=b["src"], dst=b["records"][0]["dst"],
            asset=b["records"][0]["extra"].get("object"),
            domain="EXT", extra={}, records=b["records"]))
    campaigns = {}                       # single pseudo-campaign, eval only
    ds = SimpleNamespace(
        records=[r for b in behs for r in b["records"]],
        behaviors=beh_objs, campaigns=campaigns, world=world,
        seed=0, scale="EXT")
    return ds, behs


def load_gt(gt_dir):
    """orthrus per-attack CSVs -> {attack: set(uuid)}."""
    out = {}
    for fn in sorted(os.listdir(gt_dir)):
        if not fn.endswith(".csv"):
            continue
        with open(os.path.join(gt_dir, fn), newline="",
                  encoding="utf-8") as f:
            rdr = csv.DictReader(f)
            out[fn[:-4]] = {r[GT_COLS[0]] for r in rdr}
    return out


def main(graph_csv, gt_dir):
    records = load_graph(graph_csv)
    ds, behs = build_ds(records)
    res = pipeline.run_mdata(ds)
    gt = load_gt(gt_dir)
    # TODO(server): uuid<->behaviour bridge: PIDSMaker graph node uuids
    # map to behaviour records' dst objects; compute node/edge F1 and
    # completeness per attack with the same code path as evaluate.
    print(json.dumps(dict(n_records=len(ds.records),
                          n_behaviours=len(ds.behaviors),
                          n_chains=len(res["chains"]),
                          n_attacks=len(gt)), indent=1))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--graph", required=True)
    ap.add_argument("--gt", required=True)
    a = ap.parse_args()
    main(a.graph, a.gt)
