"""B1/B2/B3 baselines on DARPA TC E3 THEIA (companion to
run_darpatc_external / parse_theia): same cached ds, same orthrus +
reapr per-node ground truths, same touch rule.  Protocol: for methods
with chains (B3) the chain-based predicted set of theia_eval.json;
for score-only methods (B1, B2) the behaviour set scoring at least
0.5.  Result JSON feeds one sentence of section 6.10.

Usage: python run_baselines_theia.py --ds-cache .../theia_ds.pkl \
  --gt-orthrus .../orthrus/E3-THEIA --gt-reapr .../reapr/E3-THEIA
"""
from __future__ import annotations

import argparse
import json
import os
import pickle
from collections import defaultdict

import config as C
import baselines as B
import pipeline as P
from run_gnn_theia import load_gt


def touch_map(ds, idmap, gt_sets):
    inv = {v: k for k, v in idmap.items()}
    touch = defaultdict(set)
    for b in ds.behaviors:
        su = inv.get(b.src)
        objs = {inv.get(r.get("dst")) for r in b.records} - {None}
        for name, uu in gt_sets.items():
            if su in uu or (objs & uu):
                touch[b.bid].add(name)
    return touch


def evaluate(res, touch, gt_sets, chain_based):
    out = {}
    if chain_based and res.get("chains_by_bid"):
        pred = set()
        for ch in res["chains_by_bid"]:
            pred.update(ch)
    else:
        pred = {b for b, s in res["scores"].items() if s >= 0.5}
    for name in gt_sets:
        gt_b = {b for b, ns in touch.items() if name in ns}
        inter = len(pred & gt_b)
        prec = inter / max(1, len(pred))
        rec = inter / max(1, len(gt_b))
        f1 = 2 * prec * rec / max(1e-9, prec + rec)
        out[name] = dict(gt_behaviours=len(gt_b), pred=len(pred),
                         precision=round(prec, 3), recall=round(rec, 3),
                         f1=round(f1, 3))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds-cache", required=True)
    ap.add_argument("--gt-orthrus", required=True)
    ap.add_argument("--gt-reapr", required=True)
    a = ap.parse_args()

    with open(a.ds_cache, "rb") as f:
        ds, idmap = pickle.load(f)
    print(f"behaviours {len(ds.behaviors)}", flush=True)
    gt_o = load_gt(a.gt_orthrus)
    gt_r = load_gt(a.gt_reapr)

    final = {}
    for name, fn, chain_based in [
            ("B1", lambda: B.run_b1(ds), False),
            ("B2", lambda: B.run_b2(ds), False),
            ("B3", lambda: B.run_b3(ds), True)]:
        print(f"running {name} ...", flush=True)
        res = fn()
        touch = touch_map(ds, idmap, gt_o)
        orth = evaluate(res, touch, gt_o, chain_based)
        touch = touch_map(ds, idmap, gt_r)
        rapr = evaluate(res, touch, gt_r, chain_based)
        final[name] = dict(orthrus=orth, reapr=rapr)
        print(name, "orthrus", {k: v["f1"] for k, v in orth.items()},
              "reapr", {k: v["f1"] for k, v in rapr.items()}, flush=True)

    path = os.path.join(C.RESULTS, "baselines_theia.json")
    os.makedirs(C.RESULTS, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(dict(protocol="chains for B3; score>=0.5 for B1/B2; "
                        "touch rule identical to theia_eval.json",
                       results=final), f, indent=1)
    print("saved", path, flush=True)


if __name__ == "__main__":
    main()
