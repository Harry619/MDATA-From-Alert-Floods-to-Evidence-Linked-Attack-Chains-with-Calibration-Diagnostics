"""Enhancement item (2) of ENHANCEMENT_ROADMAP.md: learned correlation and
threat weights vs expert Delphi weights.

Learns, on the calibration split only (no test-campaign leakage):
  * the seven association weights w_k and the penalty coefficient lambda by
    class-weighted logistic ranking over candidate event pairs
    (positive := both events belong to the same campaign),
  * the six threat weights alpha by class-weighted logistic regression on
    behaviour dimensions (positive := behaviour belongs to an effective
    campaign),
both constrained to the simplex so the score semantics of the paper are
preserved.

Reports expert vs learned F1 / PR-AUC / workload / ECE across seeds,
behaviour-level McNemar tests (also versus B1, fixing roadmap item P0),
and the learned weight values.

Outputs: results/learned_weights_S2.json, manuscript/numbers_learned.tex
"""
from __future__ import annotations

import json
import os

import numpy as np

import baselines
import config as C
import datagen
import evaluate
import pipeline
from run_calibration_analysis import reliability

FEATURES = ["time", "entity", "reach", "behavior", "asset", "business", "intel"]
TDIMS = ["M", "A", "I", "C", "F", "E"]
MAX_PAIRS = 150_000
NEG_RATIO = 3.0


def sigmoid(z):
    return np.where(z >= 0, 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30))),
                    np.exp(np.clip(z, -30, 30)) /
                    (1.0 + np.exp(np.clip(z, -30, 30))))


def project_simplex(v):
    u = np.sort(v)[::-1]
    css = np.cumsum(u)
    rho = np.nonzero(u * np.arange(1, len(v) + 1) > (css - 1))[0][-1]
    theta = (css[rho] - 1) / (rho + 1)
    return np.maximum(v - theta, 0.0)


# ------------------------------------------------------------ pair data --
def pair_dataset(ds, fit_bids, seed, neg_cap=100_000):
    """Candidate pairs over fit-set behaviours; positives (same campaign)
    all kept, negatives reservoir-sampled so memory stays bounded and phi
    is only computed for kept rows."""
    events = pipeline.normalize(ds)
    scorer = pipeline.Scorer(ds)
    bid2cid = {bid: cid for cid, c in ds.campaigns.items()
               for bid, _ in c.behaviors}
    now = C.OP_SECONDS
    rng = np.random.default_rng(seed)
    pos, neg = [], []
    n_seen_neg = 0

    def phi_of(ei, ej):
        return ([scorer.f_time(ei, ej), scorer.f_entity(ei, ej),
                 scorer.f_reach(ei, ej), scorer.f_behavior(ei, ej),
                 scorer.f_asset(ei, ej), scorer.f_business(ei, ej),
                 scorer.f_intel(ei, ej, now)], scorer.uncertainty(ei, ej))

    for (i, j), _ in pipeline.gen_candidates(events):
        ei, ej = events[i], events[j]
        if ei.bid not in fit_bids or ej.bid not in fit_bids:
            continue
        ci, cj = bid2cid.get(ei.bid), bid2cid.get(ej.bid)
        if ci is not None and ci == cj:
            pos.append(phi_of(ei, ej))
        else:
            n_seen_neg += 1
            if len(neg) < neg_cap:
                neg.append(phi_of(ei, ej))
            else:
                k = int(rng.integers(n_seen_neg))
                if k < neg_cap:
                    neg[k] = phi_of(ei, ej)
    n_neg = min(len(neg), int(NEG_RATIO * len(pos)),
                MAX_PAIRS - len(pos))
    if n_neg < len(neg):
        neg = [neg[k] for k in rng.choice(len(neg), n_neg, replace=False)]
    rows = pos + neg
    phi = np.array([r[0] for r in rows], float)
    u = np.array([r[1] for r in rows], float)
    y = np.array([1.0] * len(pos) + [0.0] * len(neg))
    return phi, u, y, len(pos), n_neg


def train_weights(phi, u, y, w0, lam0, iters=400, lr=0.05):
    w, lam = np.array(w0, float), float(lam0)
    n_pos, n_neg = max(1.0, y.sum()), max(1.0, (1 - y).sum())
    sw = np.where(y == 1, 0.5 / n_pos, 0.5 / n_neg)
    for _ in range(iters):
        z = phi @ w - lam * u
        p = sigmoid(z)
        g = p - y
        gw = (phi * (sw * g)[:, None]).sum(axis=0) / sw.sum()
        gl = np.sum(sw * g * (-u)) / sw.sum()
        w -= lr * gw
        lam = min(1.0, max(0.0, lam - lr * gl))
        w = project_simplex(w)
    return w, lam


def behaviour_dims(ds, res, bids):
    """Behaviour -> 6-dim threat feature vector from pipeline meta."""
    _, meta = pipeline.threat_scores(
        ds, res["events"], res["clusters"], res["chains"])
    X = np.array([[meta[b][2][k] for k in TDIMS] if b in meta
                  else np.zeros(len(TDIMS)) for b in bids])
    return X


def train_alpha(X, y, fit_mask, a0, iters=600, lr=0.1):
    a = np.array(a0, float)
    xf, yf = X[fit_mask], y[fit_mask]
    n_pos, n_neg = max(1.0, yf.sum()), max(1.0, (1 - yf).sum())
    sw = np.where(yf == 1, 0.5 / n_pos, 0.5 / n_neg)
    for _ in range(iters):
        p = sigmoid(xf @ a)
        ga = (xf * (sw * (p - yf))[:, None]).sum(axis=0) / sw.sum()
        a = project_simplex(a - lr * ga)
    return a


# ------------------------------------------------------------------ run --
def run(scale="S2"):
    per_seed, w_hist, a_hist = [], [], []
    for seed in C.MASTER_SEEDS:
        ds = datagen.generate(seed, scale)
        ctx = evaluate.EvalContext(ds)
        bids = ctx.bids
        lb = ctx.lb.astype(float)
        bid2cid = {bid: cid for cid, c in ds.campaigns.items()
                   for bid, _ in c.behaviors}
        fit_bids = {b for b in bids
                    if (b in bid2cid and bid2cid[b] in ctx.train_c)
                    or (b not in bid2cid and b in ctx.train_b)}
        fit_mask = np.array([b in fit_bids for b in bids])

        # ---- learn w, lambda on calibration pairs --------------------------
        phi, u, y, n_pos, n_neg = pair_dataset(ds, fit_bids, seed)
        w0 = np.array([C.FEATURE_WEIGHTS[k] for k in FEATURES])
        w_l, lam_l = train_weights(phi, u, y, w0, C.LAMBDA_PENALTY)
        w_hist.append(dict(zip(FEATURES, w_l.round(4).tolist())) |
                      dict(lam=round(float(lam_l), 4)))
        print(f"seed {seed}: pairs pos {n_pos} neg {n_neg}; "
              f"learned w {dict((k, round(float(v),3)) for k,v in zip(FEATURES,w_l))} "
              f"lam {lam_l:.3f}", flush=True)

        # ---- expert run -----------------------------------------------------
        a0 = np.array([C.THREAT_WEIGHTS[k] for k in TDIMS])
        res_e = pipeline.run_mdata(ds)
        m_e = ctx.evaluate(res_e)

        # ---- learned-w run (same alpha semantics as expert) -----------------
        res_w = pipeline.run_mdata(ds, weights={k: float(v) for k, v in
                                                zip(FEATURES, w_l)},
                                   lam=float(lam_l))
        m_w = ctx.evaluate(res_w)

        # ---- learned alpha on EXPERT structure (aligned objective) ---------
        X_e = behaviour_dims(ds, res_e, bids)
        a_le = train_alpha(X_e, lb, fit_mask, a0)
        scores_ae, _ = pipeline.threat_scores(
            ds, res_e["events"], res_e["clusters"], res_e["chains"],
            weights={k: float(v) for k, v in zip(TDIMS, a_le)})
        res_ae = dict(scores=scores_ae, chains_by_bid=res_e["chains_by_bid"])
        m_ae = ctx.evaluate(res_ae)

        # ---- learned alpha on top of learned-w structure --------------------
        X = behaviour_dims(ds, res_w, bids)
        a_l = train_alpha(X, lb, fit_mask, a0)
        a_hist.append(dict(zip(TDIMS, a_l.round(4).tolist())))
        scores_a, meta_a = pipeline.threat_scores(
            ds, res_w["events"], res_w["clusters"], res_w["chains"],
            weights={k: float(v) for k, v in zip(TDIMS, a_l)})
        res_a = dict(scores=scores_a, chains_by_bid=res_w["chains_by_bid"])
        m_a = ctx.evaluate(res_a)

        # ---- B1 for the significance fix (roadmap P0) -----------------------
        m_b1 = ctx.evaluate(baselines.run_b1(ds))
        mc_e_b1 = evaluate.mcnemar_p(m_e["_correct_test"], m_b1["_correct_test"])
        mc_w_b1 = evaluate.mcnemar_p(m_w["_correct_test"], m_b1["_correct_test"])
        mc_a_e = evaluate.mcnemar_p(m_a["_correct_test"], m_e["_correct_test"])
        # B1 score-constancy diagnostic (NDCG=1.0 anomaly, roadmap P0)
        b1_unique = len({round(float(v), 6)
                         for b in ctx.bids
                         for v in [baselines_run_cache_scores(m_b1, ctx, b)]})

        def ece_of(m):
            te = ctx.test_mask
            rows, ece, _ = reliability(m["_sc"][te], lb[te])
            return ece

        mc_ae_e = evaluate.mcnemar_p(m_ae["_correct_test"], m_e["_correct_test"])
        per_seed.append(dict(
            seed=seed,
            expert=dict(f1=m_e["f1"], prauc=m_e["prauc"], workload=m_e["workload"],
                        ece=ece_of(m_e)),
            learned_w=dict(f1=m_w["f1"], prauc=m_w["prauc"],
                           workload=m_w["workload"], ece=ece_of(m_w)),
            learned_alpha=dict(f1=m_ae["f1"], prauc=m_ae["prauc"],
                               workload=m_ae["workload"], ece=ece_of(m_ae)),
            learned_all=dict(f1=m_a["f1"], prauc=m_a["prauc"],
                             workload=m_a["workload"], ece=ece_of(m_a)),
            b1=dict(f1=m_b1["f1"], prauc=m_b1["prauc"]),
            mcnemar=dict(expert_vs_b1=mc_e_b1, learned_w_vs_b1=mc_w_b1,
                         learned_all_vs_expert=mc_a_e,
                         learned_alpha_vs_expert=mc_ae_e),
            learned_alpha_weights=dict(zip(TDIMS, a_le.round(4).tolist())),
            b1_unique_scores=b1_unique))
        print(f"seed {seed}: F1 expert {m_e['f1']:.3f} / learned_w {m_w['f1']:.3f}"
              f" / learned_all {m_a['f1']:.3f}; B1 {m_b1['f1']:.3f}; "
              f"McNemar expert-vs-B1 p={mc_e_b1[0]:.2e}", flush=True)

    def agg(name, fields):
        return {f: dict(mean=float(np.mean([s[name][f] for s in per_seed])),
                        std=float(np.std([s[name][f] for s in per_seed])))
                for f in fields}

    out = dict(
        scale=scale,
        agg=dict(expert=agg("expert", ["f1", "prauc", "workload", "ece"]),
                 learned_w=agg("learned_w", ["f1", "prauc", "workload", "ece"]),
                 learned_alpha=agg("learned_alpha",
                                   ["f1", "prauc", "workload", "ece"]),
                 learned_all=agg("learned_all", ["f1", "prauc", "workload", "ece"]),
                 b1=agg("b1", ["f1", "prauc"])),
        learned_w_hist=w_hist, learned_alpha_hist=a_hist, per_seed=per_seed)
    path = os.path.join(C.RESULTS, f"learned_weights_{scale}.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=1, default=float)
    print("saved", path, flush=True)

    a = out["agg"]
    lines = [
        f"\\newcommand\\nLwExpertF{{{100*a['expert']['f1']['mean']:.1f}}}",
        f"\\newcommand\\nLwLearnedF{{{100*a['learned_w']['f1']['mean']:.1f}}}",
        f"\\newcommand\\nLwAllF{{{100*a['learned_all']['f1']['mean']:.1f}}}",
        f"\\newcommand\\nLwExpertPRAUC{{{100*a['expert']['prauc']['mean']:.1f}}}",
        f"\\newcommand\\nLwLearnedPRAUC{{{100*a['learned_w']['prauc']['mean']:.1f}}}",
        f"\\newcommand\\nLwAllPRAUC{{{100*a['learned_all']['prauc']['mean']:.1f}}}",
        f"\\newcommand\\nLwExpertECE{{{a['expert']['ece']['mean']:.3f}}}",
        f"\\newcommand\\nLwAllECE{{{a['learned_all']['ece']['mean']:.3f}}}",
        f"\\newcommand\\nLwAlphaF{{{100*a['learned_alpha']['f1']['mean']:.1f}}}",
        f"\\newcommand\\nLwAlphaPRAUC{{{100*a['learned_alpha']['prauc']['mean']:.1f}}}",
        f"\\newcommand\\nLwAlphaECE{{{a['learned_alpha']['ece']['mean']:.3f}}}",
    ]
    p = os.path.join(C.BASE, "manuscript", "numbers_learned.tex")
    with open(p, "w") as f:
        f.write("\n".join(lines) + "\n")
    print("saved", p, flush=True)
    return out


def baselines_run_cache_scores(m, ctx, b):
    """B1 score lookup from the evaluate output vector."""
    i = ctx.bidx[b]
    return m["_sc"][i]


if __name__ == "__main__":
    run("S2")
