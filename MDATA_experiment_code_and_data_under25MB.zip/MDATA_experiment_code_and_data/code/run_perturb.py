"""RQ4-RQ5: sensitivity (theta / delta / B / L) and robustness
(field masking, timestamp jitter, stale intel, infra rotation).

Robustness perturbations are applied to the ATOMIC EVENT view (i.e., to
what the consuming pipeline can see), simulating degraded data quality
after normalisation, and also to the raw-record level where noted.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import time
from concurrent.futures import ProcessPoolExecutor

import numpy as np

import config as C
import datagen
import baselines
import evaluate
import pipeline as P


# --------------------------------------------------------------------- --
#  Sensitivity
# --------------------------------------------------------------------- --
def _one_sens(args):
    seed, scale, param, value = args
    ds = datagen.generate(seed, scale)
    ctx = evaluate.EvalContext(ds)
    kw = {}
    saved_sigma, saved_win = dict(P.SIGMA_B), P.MAX_PAIR_WINDOW
    try:
        if param == "theta":
            kw["theta"] = value
        elif param == "beam":
            kw["beam"] = value
        elif param == "max_len":
            kw["max_len"] = value
        elif param == "time_tol":
            # scale all stage-pair sigma by value / baseline
            P.SIGMA_B.update({k: int(v * value / C.TIME_TOL)
                              for k, v in saved_sigma.items()})
            P.MAX_PAIR_WINDOW = int(saved_win * value / C.TIME_TOL)
        t0 = time.time()
        res = baselines.run_mdata_full(ds, **kw)
        m = ctx.evaluate(res)
    finally:
        P.SIGMA_B.clear()
        P.SIGMA_B.update(saved_sigma)
        P.MAX_PAIR_WINDOW = saved_win
    m.pop("_sc", None)
    m.pop("dets", None)
    m.pop("per_campaign_recall", None)
    m["runtime_s"] = time.time() - t0
    m["param"], m["value"] = param, value
    return m


def run_sensitivity(scale, seeds, out_path):
    grid = {
        "theta": [0.25, 0.30, 0.35, 0.40, 0.45],
        "beam": [16, 32, 64],
        "max_len": [6, 8, 12],
        "time_tol": [600, 1800, 3600],
    }
    tasks = [(s, scale, p, v) for p, vs in grid.items() for v in vs
             for s in seeds]
    with ProcessPoolExecutor(max_workers=min(10, os.cpu_count() - 2)) as ex:
        results = list(ex.map(_one_sens, tasks))
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dict(scale=scale, seeds=seeds, results=results), f,
                  indent=1, default=float)
    print(f"wrote {out_path} ({len(results)} runs)")


# --------------------------------------------------------------------- --
#  Robustness
# --------------------------------------------------------------------- --
def perturb_dataset(ds, mode, level, rng):
    """Apply the perturbation to the dataset itself so every method sees
    exactly the same degraded view."""
    if mode == "mask":
        behs = rng.sample(ds.behaviors, int(len(ds.behaviors) * level))
        for b in behs:
            if rng.random() < 0.6:                 # lose source entity
                b.src = None
                for r in b.records:
                    if "src" in r:
                        r["src"] = None
            else:                                  # lose asset mapping
                b.asset = None
                for r in b.records:
                    if r.get("asset"):
                        r["asset"] = None
    elif mode == "jitter":
        for b in ds.behaviors:
            d0 = rng.gauss(0, level)
            b.t0 = max(0, int(b.t0 + d0))
            b.t1 = max(b.t0, int(b.t1 + rng.gauss(0, level)))
            for r in b.records:
                r["ts"] = max(0, int(r["ts"] + rng.gauss(0, level)))
        ds.records.sort(key=lambda r: r["ts"])
        ds.behaviors.sort(key=lambda b: b.t0)


def _one_rob(args):
    seed, scale, mode, level = args
    ds = datagen.generate(seed, scale)
    if mode == "stale_intel":
        # a `level` fraction of malicious TI entries are expired but still
        # consumed at face value by methods that ignore validity periods
        rng = random.Random(seed * 77 + int(level * 100))
        for rec in ds.world.intel.values():
            if rec["verdict"] == "malicious" and rng.random() < level:
                rec["expiry"] = int(rng.uniform(0, 0.2 * C.OP_SECONDS))
    if mode == "infra_rotation":
        # adversary rotates infrastructure between stages: rewrite the src
        # of post-exploit behaviours to fresh IPs per stage
        rng = random.Random(seed * 99 + int(level * 100))
        behs = {b.bid: b for b in ds.behaviors}
        for c in ds.campaigns.values():
            if not c.is_effective:
                continue
            for i, (bid, st) in enumerate(c.behaviors):
                b = behs[bid]
                if st != "recon" and rng.random() < level:
                    new_ip = datagen._ip(rng, "45.33")
                    b.src = new_ip
                    for r in b.records:
                        if r.get("src") and "." in str(r["src"]):
                            r["src"] = new_ip
    if mode in ("mask", "jitter"):
        rng = random.Random(seed * 31 + int(level * 1000))
        perturb_dataset(ds, mode, level, rng)
    ctx = evaluate.EvalContext(ds)
    out = dict(seed=seed, mode=mode, level=level, methods={})
    for name, fn in [("MDATA", baselines.run_mdata_full),
                     ("B2", baselines.run_b2),
                     ("B1", baselines.run_b1)]:
        res = fn(ds)
        m = ctx.evaluate(res)
        m.pop("_sc", None)
        m.pop("dets", None)
        m.pop("per_campaign_recall", None)
        out["methods"][name] = m
    return out


def run_robustness(scale, seeds, out_path):
    levels = dict(mask=[0.1, 0.3, 0.5],
                  jitter=[300, 900, 3600],
                  stale_intel=[0.2, 0.4, 0.6],
                  infra_rotation=[0.3, 0.6, 1.0])
    tasks = [(s, scale, mode, lv) for mode, lvs in levels.items()
             for lv in lvs for s in seeds]
    with ProcessPoolExecutor(max_workers=min(10, os.cpu_count() - 2)) as ex:
        results = list(ex.map(_one_rob, tasks))
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(dict(scale=scale, seeds=seeds, results=results), f,
                  indent=1, default=float)
    print(f"wrote {out_path} ({len(results)} runs)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--which", choices=["sens", "rob"], required=True)
    ap.add_argument("--scale", default="S1")   # perturbation studies at S1
    ap.add_argument("--seeds", type=int, nargs="*", default=[11, 22, 33])
    args = ap.parse_args()
    if args.which == "sens":
        run_sensitivity(args.scale, args.seeds,
                        os.path.join(C.RESULTS, f"sensitivity_{args.scale}.json"))
    else:
        run_robustness(args.scale, args.seeds,
                       os.path.join(C.RESULTS, f"robustness_{args.scale}.json"))
