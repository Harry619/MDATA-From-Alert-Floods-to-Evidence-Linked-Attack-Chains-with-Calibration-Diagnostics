"""Calibration study: what evidence sufficiency and uncertainty
intervals buy beyond raw detection F1.

Compares the full MDATA (interval-gated risk bands) against A4 (same
pipeline without evidence sufficiency / uncertainty penalty) and B1
(rule severity) on:
  - high-band precision: share of the high-risk band (lower bound
    R - kappa*U >= T_high) that are true effective-attack behaviours;
  - high-band coverage: recall of effective behaviours into the band;
  - false-claim rate: share of recon-only campaign behaviours that land
    in the high band (crying "intrusion" on reconnaissance);
  - verification-queue precision: precision of the middle band
    (T_med <= lower bound < T_high), the human-review queue;
  - single-source share: fraction of high-band items backed by <2
    channels of evidence (risky to act on).
"""
from __future__ import annotations

import json
import os

import numpy as np

import config as C
import datagen
import baselines
import evaluate
import pipeline as P


def behaviour_channels(ds):
    out = {}
    for b in ds.behaviors:
        out[b.bid] = len({r["channel"] for r in b.records})
    return out


def band_metrics(ds, res, use_interval, thr_hi=None, thr_med=None):
    thr_hi = C.T_HIGH if thr_hi is None else thr_hi
    thr_med = C.T_MED if thr_med is None else thr_med
    labels, _ = evaluate.labels_of(ds)
    _, _, _, test_b = evaluate.make_split(ds)
    scores = res["scores"]
    meta = res.get("meta", {})
    nch = behaviour_channels(ds)
    recon_only = {bid for c in ds.campaigns.values()
                  if c.truncation == "recon_only" for bid, _ in c.behaviors}
    high, mid = [], []
    for b in test_b:
        R = scores.get(b, 0.0)
        if use_interval and b in meta:
            U = meta[b][1]
            lb = max(0.0, R - C.KAPPA * U)
        else:
            lb = R
        if lb >= thr_hi:
            high.append(b)
        elif lb >= thr_med:
            mid.append(b)
    eff = lambda b: labels.get(b, 0) == 1
    out = dict(
        high_n=len(high),
        high_precision=float(np.mean([eff(b) for b in high])) if high else float("nan"),
        high_coverage=float(np.sum([eff(b) for b in high]) /
                            max(1, np.sum([labels.get(b, 0) for b in test_b]))),
        false_claim_rate=float(np.mean([b in recon_only for b in high]))
        if high else float("nan"),
        mid_n=len(mid),
        mid_precision=float(np.mean([eff(b) for b in mid])) if mid else float("nan"),
        high_single_source=float(np.mean([nch.get(b, 0) < 2 for b in high]))
        if high else float("nan"),
    )
    return out


def main(seeds=(11, 22, 33), scale="S2", degraded=None):
    import random
    rows = []
    for seed in seeds:
        ds = datagen.generate(seed, scale)
        if degraded == "mask30":
            rng = random.Random(seed * 31 + 3000)
            from run_perturb import perturb_dataset
            perturb_dataset(ds, "mask", 0.3, rng)
        for name, runner, use_interval in [
                ("MDATA", baselines.run_mdata_full, True),
                ("A4_no_evidence", lambda d: baselines.run_mdata_full(
                    d, use_evidence=False), False),
                ("B1", baselines.run_b1, False)]:
            res = runner(ds)
            m = band_metrics(ds, res, use_interval)
            m.update(seed=seed, method=name,
                     degraded=degraded or "clean")
            rows.append(m)
            print(name, seed, {k: round(v, 3) for k, v in m.items()
                               if isinstance(v, float)}, flush=True)
    suffix = "" if not degraded else "_" + degraded
    with open(os.path.join(C.RESULTS, "calibration" + suffix + ".json"),
              "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=1, default=float)
    print("wrote calibration" + suffix + ".json")
    # summary
    for name in ("MDATA", "A4_no_evidence", "B1"):
        sub = [r for r in rows if r["method"] == name]
        print(f"{name:14s} highP={np.nanmean([r['high_precision'] for r in sub]):.3f} "
              f"highCov={np.nanmean([r['high_coverage'] for r in sub]):.3f} "
              f"falseClaim={np.nanmean([r['false_claim_rate'] for r in sub]):.3f} "
              f"midP={np.nanmean([r['mid_precision'] for r in sub]):.3f} "
              f"singleSrc={np.nanmean([r['high_single_source'] for r in sub]):.3f}")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--degraded", choices=[None, "mask30"], default=None)
    a = ap.parse_args()
    main(degraded=a.degraded)
