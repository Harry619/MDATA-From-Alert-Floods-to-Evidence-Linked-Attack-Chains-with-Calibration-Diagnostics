"""Memory-bounded THEIA adapter ablation on identical parsed events.

The original and generic adapters are classified together, externally sorted
with DuckDB, and evaluated sequentially. Compact behaviours retain every
field used by MDATA scoring plus the complete UUID sets used by ground-truth
matching. Raw per-event dictionaries are not retained in memory.

Example:
  python run_theia_compact.py --json ../data/theia_raw/*.json* \
    --gt ../bundles/PIDSMaker/Ground_Truth/orthrus/E3-THEIA \
    --work ../data/theia_compact --out ../results/theia_adapter_ablation.json
"""
from __future__ import annotations

import argparse
import gc
import glob
import json
import os
import pickle
import re
import sys
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from types import SimpleNamespace

import duckdb

import parse_theia as T
import pipeline as P


def natural_key(path):
    base = os.path.basename(path)
    m = re.search(r"official-([0-9]+[rm]?)\.json(?:\.([0-9]+))?$", base)
    if not m:
        return (99, 99, base)
    order = {"1r": 0, "6r": 1, "3": 2, "5m": 3}
    return (order.get(m.group(1), 98), int(m.group(2) or -1), base)


def parse_shard(path, work):
    """Parse one raw file and persist classified events and file metadata."""
    stem = os.path.basename(path)
    event_path = os.path.join(work, stem + ".events.pkl")
    meta_path = os.path.join(work, stem + ".files.pkl")
    if os.path.exists(event_path) and os.path.exists(meta_path):
        return path, event_path, meta_path, -1
    _, subjects, files_o, flows, events = T._parse_one(path)
    classified = []
    for ts, et, s, po in events:
        if s is None:
            continue
        cmd = subjects.get(s, "")
        obj = files_o.get(po, "")
        flow = flows.get(po, "")
        oa, os_, ov = T.act_of(et, cmd, obj, flow, False)
        ga, gs, gv = T.act_of(et, cmd, obj, flow, True)
        classified.append((ts, et, s, po, oa, os_, ov, ga, gs, gv))
    with open(event_path, "wb") as f:
        pickle.dump(classified, f, protocol=4)
    with open(meta_path, "wb") as f:
        pickle.dump(files_o, f, protocol=4)
    n = len(classified)
    del classified, events, subjects, files_o, flows
    return path, event_path, meta_path, n


def ingest(con, files, work, workers, append=False):
    if not append:
        con.execute("DROP TABLE IF EXISTS events")
        con.execute("""CREATE TABLE events(
            seq BIGINT, ts BIGINT, et VARCHAR, s VARCHAR, po VARCHAR,
            oact VARCHAR, ostage VARCHAR, osev DOUBLE,
            gact VARCHAR, gstage VARCHAR, gsev DOUBLE)""")
        seq = 0
    else:
        seq = con.execute("SELECT coalesce(max(seq) + 1, 0) FROM events").fetchone()[0]
    os.makedirs(work, exist_ok=True)
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futures = [ex.submit(parse_shard, p, work) for p in files]
        for fut in futures:
            path, event_path, _, n = fut.result()
            with open(event_path, "rb") as f:
                rows = pickle.load(f)
            if n >= 0:
                print(f"parsed {os.path.basename(path)}: {n} events", flush=True)
            else:
                print(f"reusing {os.path.basename(event_path)}", flush=True)
            chunk = []
            columns = ["seq", "ts", "et", "s", "po", "oact", "ostage",
                       "osev", "gact", "gstage", "gsev"]
            for row in rows:
                chunk.append((seq,) + row)
                seq += 1
                if len(chunk) >= 100000:
                    import pandas as pd
                    con.append("events", pd.DataFrame(chunk, columns=columns))
                    chunk.clear()
            if chunk:
                import pandas as pd
                con.append("events", pd.DataFrame(chunk, columns=columns))
            del rows, chunk
    if not append:
        con.execute("CREATE INDEX events_seq ON events(seq)")
    print(f"ingested through sequence {seq}", flush=True)
    return seq


def shorten(uuid, table):
    return table.setdefault(uuid, f"U{len(table):07d}")


def build_compact_ds(con, files, work, generic=False):
    prefix = "g" if generic else "o"
    act = prefix + "act"
    stage = prefix + "stage"
    sev = prefix + "sev"
    con.execute("DROP TABLE IF EXISTS groups_ordered")
    con.execute("DROP TABLE IF EXISTS groups_raw")
    con.execute(f"""CREATE TABLE groups_raw AS
        SELECT s, {act} AS act, min(seq) AS first_seq
        FROM events GROUP BY s, {act}""")
    con.execute("""CREATE TABLE groups_ordered AS
        SELECT row_number() OVER (ORDER BY first_seq) - 1 AS gid, s, act
        FROM groups_raw""")
    query = f"""SELECT e.ts,e.et,e.po,e.{sev},e.{stage},g.gid,e.seq
        FROM events e JOIN groups_ordered g
          ON e.s=g.s AND e.{act}=g.act
        ORDER BY g.gid,e.ts,e.et,e.po,e.{stage},e.{sev},e.seq"""
    cur = con.cursor()
    cur.execute(query)

    idmap = {}
    behaviours, records = [], []
    current_gid = None
    run = []

    def flush_run():
        if not run:
            return
        count = len(run)
        max_sev = max(r[3] for r in run)
        if count < 2 and max_sev < 0.5:
            return
        first, last = run[0], run[-1]
        bid = f"X{len(behaviours) + 1:06d}"
        src_uuid = run_src
        sub = shorten(src_uuid, idmap)
        objs = {shorten(r[2], idmap) for r in run if r[2]}
        dst = next(iter(objs), None)

        def rec(row):
            return dict(channel="edr", ts=row[0], bid=bid, src=sub,
                        dst=shorten(row[2], idmap) if row[2] else None,
                        rule=row[1], severity=max_sev, user="-",
                        clock_conf=1.0)

        compact_records = [rec(first)] if count == 1 else [rec(first), rec(last)]
        b = SimpleNamespace(
            bid=bid, channel="edr", stage=first[4], cid=None, actor=sub,
            kind=run_act, t0=first[0], t1=last[0], src=sub, dst=dst,
            asset=dst, domain="DOM-EXT", extra={}, records=compact_records,
            _src_uuid=src_uuid,
            _object_uuids={r[2] for r in run if r[2]})
        behaviours.append(b)
        records.extend(compact_records)

    while True:
        rows = cur.fetchmany(10000)
        if not rows:
            break
        for ts, et, po, severity, stage_, gid, seq in rows:
            if current_gid is None or gid != current_gid:
                flush_run()
                run = []
                current_gid = gid
                run_src, run_act = gid_sub_act[(gid)] if False else (None, None)
            if not run:
                # The join key is recovered with a scalar lookup only once per
                # run group; values are cached in dictionaries below.
                run_src = gid_sub[gid]
                run_act = gid_act[gid]
            if run and ts - run[-1][0] > 3600:
                flush_run()
                run = []
            run.append((ts, et, po, severity, stage_))
    flush_run()
    cur.close()

    assets, zone_of = {}, {}
    for path in files:
        meta_path = os.path.join(work, os.path.basename(path) + ".files.pkl")
        with open(meta_path, "rb") as f:
            files_o = pickle.load(f)
        for path_uuid, file_path in files_o.items():
            aid = shorten(path_uuid, idmap)
            crit = 0.6 if file_path.startswith(("/usr", "/etc", "/bin")) else 0.35
            if aid not in assets:
                assets[aid] = SimpleNamespace(
                    aid=aid, domain="DOM-EXT", zone="intranet", role="host",
                    criticality=crit, exposed=False, vuln=None, deps=[])
                zone_of[aid] = "intranet"
        del files_o
    world = SimpleNamespace(assets=assets, zone_of=zone_of, intel={},
                            groups={}, ext_ips={})
    ds = SimpleNamespace(records=records,
                         behaviors=sorted(behaviours, key=lambda b: b.t0),
                         campaigns={}, world=world, seed=0, scale="THEIA")
    return ds


def prepare_group_maps(con):
    """Small group-id maps avoid carrying join keys through the sorter."""
    global gid_sub, gid_act
    gid_sub, gid_act = {}, {}
    for gid, s, act in con.execute("SELECT gid,s,act FROM groups_ordered").fetchall():
        gid_sub[gid], gid_act[gid] = s, act


class StreamingScorer(P.Scorer):
    """Identical score function without an unbounded pair-score cache."""
    def score(self, e1, e2, now):
        phi = dict(
            time=self.f_time(e1, e2) if self.use_time else 0.5,
            entity=self.f_entity(e1, e2), reach=self.f_reach(e1, e2),
            behavior=self.f_behavior(e1, e2),
            asset=self.f_asset(e1, e2) if self.use_asset else 0.0,
            business=self.f_business(e1, e2) if self.use_asset else 0.0,
            intel=self.f_intel(e1, e2, now) if self.use_intel else 0.0)
        s = sum(self.wa[k] * v for k, v in phi.items())
        s -= self.lam * self.uncertainty(e1, e2)
        return max(0.0, min(1.0, s))


from array import array


class PackedEdges:
    """Tuple-compatible edge iteration with compact primitive storage."""
    def __init__(self):
        self.left = array("I")
        self.right = array("I")
        self.score = array("d")

    def append(self, edge):
        i, j, s = edge
        self.left.append(i)
        self.right.append(j)
        self.score.append(s)

    def __len__(self):
        return len(self.score)

    def __iter__(self):
        for i, j, s in zip(self.left, self.right, self.score):
            yield i, j, s


def gen_packed_edges(events, scorer, now, use_asset=True, use_time=True,
                     keep=0.35, window=None):
    """Same candidates and scores as pipeline.gen_scored_edges."""
    edges = PackedEdges()
    n_cand = 0
    for (i, j), _ in P.gen_candidates(events, use_asset=use_asset,
                                      use_time=use_time, window=window):
        n_cand += 1
        s = scorer.score(events[i], events[j], now)
        if s >= keep:
            edges.append((i, j, s))
        if n_cand % 5_000_000 == 0:
            print(f"scored candidates {n_cand}; retained {len(edges)}",
                  flush=True)
    return edges, n_cand


class PackedAdjacency:
    """CSR adjacency preserving the insertion order of pipeline.beam_search."""
    def __init__(self, n, edges):
        self.offset = array("Q", [0]) * (n + 1)
        for i, j, _ in edges:
            self.offset[i + 1] += 1
            self.offset[j + 1] += 1
        for i in range(n):
            self.offset[i + 1] += self.offset[i]
        m = 2 * len(edges)
        self.neighbor = array("I", [0]) * m
        self.score = array("d", [0.0]) * m
        cursor = array("Q", self.offset[:-1])
        for i, j, s in edges:
            p = cursor[i]
            self.neighbor[p], self.score[p] = j, s
            cursor[i] = p + 1
            p = cursor[j]
            self.neighbor[p], self.score[p] = i, s
            cursor[j] = p + 1

    def iter_node(self, i):
        for p in range(self.offset[i], self.offset[i + 1]):
            yield self.neighbor[p], self.score[p]


def beam_search_packed(events, edges, scorer, theta=None, beam=None,
                       max_len=None, use_time=True, seeds=None):
    """Memory-bounded equivalent of pipeline.beam_search."""
    theta = P.C.THETA if theta is None else theta
    beam = P.C.BEAM if beam is None else beam
    max_len = P.C.MAX_PATH if max_len is None else max_len
    adj = PackedAdjacency(len(events), edges)

    def pscore(p):
        tot, n = 0.0, 0
        for a, b in zip(p, p[1:]):
            for j, s in adj.iter_node(a):
                if j == b:
                    tot += s
                    n += 1
                    break
        edge_avg = tot / max(1, n)
        risk = sum(events[i].severity for i in p) / len(p)
        return 0.7 * edge_avg + 0.3 * risk

    def forward_ok(cur, nxt):
        e_end, e_nxt = events[cur], events[nxt]
        if e_nxt.stage in P.OPS_CLASSES or e_end.stage in P.OPS_CLASSES:
            return False
        if use_time and e_nxt.mid < e_end.mid - 1:
            return False
        if P.STAGE_ORDER.get(e_nxt.stage, 0) < P.STAGE_ORDER.get(e_end.stage, 0):
            return False
        return True

    finished = []
    for si in seeds:
        states = [[si]]
        rounds = 0
        while states and rounds < max_len:
            rounds += 1
            new_states, stagnant = [], []
            for path in states:
                ext = False
                if len(path) < max_len:
                    for nxt, s in adj.iter_node(path[-1]):
                        if nxt in path:
                            continue
                        if forward_ok(path[-1], nxt):
                            new_states.append(path + [nxt])
                            ext = True
                if not ext and len(path) >= 2:
                    stagnant.append(path)
            finished.extend(stagnant)
            if not new_states:
                break
            new_states.sort(key=pscore, reverse=True)
            seen_sig = set()
            dedup = []
            for p in new_states[:beam]:
                sig = frozenset(p)
                if sig not in seen_sig:
                    seen_sig.add(sig)
                    dedup.append(p)
            states = dedup
        finished.extend(p for p in states if len(p) >= 2)

    expanded = []
    for p in finished:
        while len(p) < max_len:
            head = p[0]
            best, best_s = None, 0.0
            for prv, s in adj.iter_node(head):
                if prv in p:
                    continue
                e = events[prv]
                if e.stage != "recon":
                    continue
                if use_time and e.mid > events[head].mid:
                    continue
                if s > best_s:
                    best, best_s = prv, s
            if best is None or best_s < theta * 0.8:
                break
            p = [best] + p
        expanded.append(p)

    out, used = [], set()
    expanded.sort(key=lambda p: (-len(p), -pscore(p)))
    for p in expanded:
        if pscore(p) < theta * 0.8:
            continue
        if any(i in used for i in p):
            continue
        used.update(p)
        out.append(p)
    return out


def evaluate(ds, res, gt_dir):
    gt_sets = T.load_gt(gt_dir)
    touch = defaultdict(set)
    for b in ds.behaviors:
        for name, uuids in gt_sets.items():
            if b._src_uuid in uuids or (b._object_uuids & uuids):
                touch[b.bid].add(name)
    out = {"n_behaviours": len(ds.behaviors), "n_chains": len(res["chains"]),
           "n_candidates": res["timing"]["n_candidates"],
           "timing": res["timing"], "attacks": {}}
    for name in gt_sets:
        gt_bids = {b for b, names in touch.items() if name in names}
        pred_bids = set()
        for chain in res["chains_by_bid"]:
            if set(chain) & gt_bids:
                pred_bids.update(chain)
        inter = len(pred_bids & gt_bids)
        precision = inter / max(1, len(pred_bids))
        recall = inter / max(1, len(gt_bids))
        f1 = 2 * precision * recall / max(1e-9, precision + recall)
        out["attacks"][name] = dict(
            gt_behaviours=len(gt_bids), pred=len(pred_bids),
            precision=round(precision, 3), recall=round(recall, 3),
            f1=round(f1, 3), complete=recall >= 0.5)
        print(name, out["attacks"][name], flush=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", nargs="+", required=True)
    ap.add_argument("--gt", required=True)
    ap.add_argument("--work", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--adapter", choices=("original", "generic"), required=True)
    ap.add_argument("--reingest", action="store_true")
    ap.add_argument("--append", action="store_true",
                    help="append only the supplied shards to an existing event table")
    a = ap.parse_args()
    files = sorted(a.json, key=natural_key)
    os.makedirs(a.work, exist_ok=True)
    db = os.path.join(a.work, "events.duckdb")
    con = duckdb.connect(db)
    con.execute("PRAGMA threads=4")
    con.execute("PRAGMA memory_limit='2GB'")
    con.execute(f"PRAGMA temp_directory='{os.path.abspath(a.work)}'")
    if a.append:
        ingest(con, files, a.work, a.workers, append=True)
        print("events after append", con.execute("SELECT count(*) FROM events").fetchone()[0],
              flush=True)
        con.close()
        return
    elif a.reingest or not os.path.exists(db) or not con.execute(
            "SELECT count(*) FROM information_schema.tables WHERE table_name='events'").fetchone()[0]:
        ingest(con, files, a.work, a.workers)
    prepare_group_maps_placeholder = None
    # Build groups before loading their small id map, then stream behaviours.
    prefix = "g" if a.adapter == "generic" else "o"
    act = prefix + "act"
    con.execute("DROP TABLE IF EXISTS groups_ordered")
    con.execute("DROP TABLE IF EXISTS groups_raw")
    con.execute(f"""CREATE TABLE groups_raw AS
        SELECT s, {act} AS act, min(seq) AS first_seq
        FROM events GROUP BY s, {act}""")
    con.execute("""CREATE TABLE groups_ordered AS
        SELECT row_number() OVER (ORDER BY first_seq) - 1 AS gid, s, act
        FROM groups_raw""")
    prepare_group_maps(con)
    # Groups already exist; build_compact_ds recreates the identical tables.
    ds = build_compact_ds(con, files, a.work, generic=a.adapter == "generic")
    print(f"behaviours {len(ds.behaviors)}", flush=True)
    con.close()
    gc.collect()
    original_scorer = P.Scorer
    original_gen = P.gen_scored_edges
    original_beam = P.beam_search
    P.Scorer = StreamingScorer
    P.gen_scored_edges = gen_packed_edges
    P.beam_search = beam_search_packed
    try:
        res = P.run_mdata(ds)
    finally:
        P.Scorer = original_scorer
        P.gen_scored_edges = original_gen
        P.beam_search = original_beam
    print(f"chains {len(res['chains'])}; candidates {res['timing']['n_candidates']}", flush=True)
    out = evaluate(ds, res, a.gt)
    out["adapter"] = a.adapter
    out["protocol"] = ("compact lossless scoring fields; no pair cache; packed edges "
                       "and CSR adjacency; same candidates, scores, weights and "
                       "operating point")
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    print("saved", a.out, flush=True)


if __name__ == "__main__":
    main()
