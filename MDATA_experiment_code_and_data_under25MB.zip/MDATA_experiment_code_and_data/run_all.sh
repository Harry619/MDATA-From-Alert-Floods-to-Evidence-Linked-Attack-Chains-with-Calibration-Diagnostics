#!/usr/bin/env bash
# Full experiment suite for the MDATA paper.
# CPU stages: ~1-1.5 h on 16 cores.  GPU stages (9-10) need an RTX 3090
# (or any >=16GB CUDA card) and requirements-gpu.txt; they skip gracefully
# when torch/transformers are missing.
set -e
source .venv/bin/activate
cd code
JOBS=${JOBS:-$(python3 -c "import os;print(min(10, max(4, os.cpu_count()-2)))")}
echo "== [1/10] Main comparison + ablations (S2, 5 seeds, jobs=$JOBS) =="
python run_main.py --scale S2 --methods B1 B2 B3 B4 MDATA A1_no_asset A2_no_intel A3_no_time A4_no_evidence --jobs "$JOBS"
echo "== [2/10] Sensitivity (S1) =="
python run_perturb.py --which sens --scale S1 --seeds 11 22 33
echo "== [3/10] Robustness (S1) =="
python run_perturb.py --which rob --scale S1 --seeds 11 22 33
echo "== [4/10] Engineering performance (S1-S3) =="
python run_engineering.py --scales S1 S2 S3
echo "== [5/10] Score dumps for PR figure (S2, seed 11) =="
python dump_scores.py
echo "== [6/10] Case study =="
python case_study.py
echo "== [7/10] Calibration study =="
python run_calibration.py
echo "== [8/10] Tables + figures =="
python make_tables.py
python make_figures.py
echo "== [9/10] GPU: B5 GNN link-prediction baseline (2 seeds) =="
python run_gnn.py --seed 11 --scale S2 && python run_gnn.py --seed 22 --scale S2 || echo "GNN stage skipped (no torch/torch_geometric)"
echo "== [10/10] GPU: LLM evidence-grounding study (optional) =="
python run_llm.py --seed 11 --scale S2 --cases 30 || echo "LLM stage skipped (no transformers/model)"
cd ..
rm -f mdata_results.zip
zip -r mdata_results.zip results figures manuscript/numbers.tex
echo "ALL DONE -> mdata_results.zip (download this file)"
